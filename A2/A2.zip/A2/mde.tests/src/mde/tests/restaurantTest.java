/**
 */
package mde.tests;

import junit.framework.TestCase;

import junit.textui.TestRunner;

import mde.MdeFactory;
import mde.restaurant;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>restaurant</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class restaurantTest extends TestCase {

	/**
	 * The fixture for this restaurant test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected restaurant fixture = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(restaurantTest.class);
	}

	/**
	 * Constructs a new restaurant test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public restaurantTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this restaurant test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(restaurant fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this restaurant test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected restaurant getFixture() {
		return fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(MdeFactory.eINSTANCE.createrestaurant());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //restaurantTest
