/**
 */
package mde.tests;

import junit.textui.TestRunner;

import mde.ClothingStore;
import mde.MdeFactory;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Clothing Store</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class ClothingStoreTest extends AbstractDepartmentTest {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(ClothingStoreTest.class);
	}

	/**
	 * Constructs a new Clothing Store test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ClothingStoreTest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this Clothing Store test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected ClothingStore getFixture() {
		return (ClothingStore)fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(MdeFactory.eINSTANCE.createClothingStore());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //ClothingStoreTest
