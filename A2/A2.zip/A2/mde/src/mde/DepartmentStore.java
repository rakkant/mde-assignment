/**
 */
package mde;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Department Store</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link mde.DepartmentStore#getOwner <em>Owner</em>}</li>
 *   <li>{@link mde.DepartmentStore#getLocation <em>Location</em>}</li>
 *   <li>{@link mde.DepartmentStore#getDepartments <em>Departments</em>}</li>
 *   <li>{@link mde.DepartmentStore#getTotalDepartments <em>Total Departments</em>}</li>
 *   <li>{@link mde.DepartmentStore#getName <em>Name</em>}</li>
 * </ul>
 *
 * @see mde.MdePackage#getDepartmentStore()
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='name'"
 * @generated
 */
public interface DepartmentStore extends EObject {
	/**
	 * Returns the value of the '<em><b>Owner</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Owner</em>' attribute.
	 * @see #setOwner(String)
	 * @see mde.MdePackage#getDepartmentStore_Owner()
	 * @model
	 * @generated
	 */
	String getOwner();

	/**
	 * Sets the value of the '{@link mde.DepartmentStore#getOwner <em>Owner</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Owner</em>' attribute.
	 * @see #getOwner()
	 * @generated
	 */
	void setOwner(String value);

	/**
	 * Returns the value of the '<em><b>Location</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Location</em>' attribute.
	 * @see #setLocation(String)
	 * @see mde.MdePackage#getDepartmentStore_Location()
	 * @model
	 * @generated
	 */
	String getLocation();

	/**
	 * Sets the value of the '{@link mde.DepartmentStore#getLocation <em>Location</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Location</em>' attribute.
	 * @see #getLocation()
	 * @generated
	 */
	void setLocation(String value);

	/**
	 * Returns the value of the '<em><b>Departments</b></em>' containment reference list.
	 * The list contents are of type {@link mde.Department}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Departments</em>' containment reference list.
	 * @see mde.MdePackage#getDepartmentStore_Departments()
	 * @model containment="true" required="true" ordered="false"
	 * @generated
	 */
	EList<Department> getDepartments();

	/**
	 * Returns the value of the '<em><b>Total Departments</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Total Departments</em>' attribute.
	 * @see #setTotalDepartments(int)
	 * @see mde.MdePackage#getDepartmentStore_TotalDepartments()
	 * @model annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot derivation='Department'"
	 * @generated
	 */
	int getTotalDepartments();

	/**
	 * Sets the value of the '{@link mde.DepartmentStore#getTotalDepartments <em>Total Departments</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Total Departments</em>' attribute.
	 * @see #getTotalDepartments()
	 * @generated
	 */
	void setTotalDepartments(int value);

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see mde.MdePackage#getDepartmentStore_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link mde.DepartmentStore#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model nameRequired="true"
	 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot body='name != null'"
	 * @generated
	 */
	Boolean isNameNotEmpty(String name);

} // DepartmentStore
