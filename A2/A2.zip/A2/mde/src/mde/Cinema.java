/**
 */
package mde;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Cinema</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link mde.Cinema#getFloor <em>Floor</em>}</li>
 *   <li>{@link mde.Cinema#getTheaterAmount <em>Theater Amount</em>}</li>
 * </ul>
 *
 * @see mde.MdePackage#getCinema()
 * @model
 * @generated
 */
public interface Cinema extends AbstractDepartment {
	/**
	 * Returns the value of the '<em><b>Floor</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Floor</em>' attribute.
	 * @see #setFloor(int)
	 * @see mde.MdePackage#getCinema_Floor()
	 * @model
	 * @generated
	 */
	int getFloor();

	/**
	 * Sets the value of the '{@link mde.Cinema#getFloor <em>Floor</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Floor</em>' attribute.
	 * @see #getFloor()
	 * @generated
	 */
	void setFloor(int value);

	/**
	 * Returns the value of the '<em><b>Theater Amount</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Theater Amount</em>' attribute.
	 * @see #setTheaterAmount(int)
	 * @see mde.MdePackage#getCinema_TheaterAmount()
	 * @model
	 * @generated
	 */
	int getTheaterAmount();

	/**
	 * Sets the value of the '{@link mde.Cinema#getTheaterAmount <em>Theater Amount</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Theater Amount</em>' attribute.
	 * @see #getTheaterAmount()
	 * @generated
	 */
	void setTheaterAmount(int value);

} // Cinema
