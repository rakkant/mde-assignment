/**
 */
package mde2;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see mde2.Mde2Factory
 * @model kind="package"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore conversionDelegates='http:///org/eclipse/emf/ecore/util/DateConversionDelegate' invocationDelegates='http://www.eclipse.org/emf/2002/Ecore/OCL' validationDelegates='http://www.eclipse.org/emf/2002/Ecore/OCL'"
 * @generated
 */
public interface Mde2Package extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "mde2";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.example.org/mde2";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "mde2";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	Mde2Package eINSTANCE = mde2.impl.Mde2PackageImpl.init();

	/**
	 * The meta object id for the '{@link mde2.impl.ShoppingMallImpl <em>Shopping Mall</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mde2.impl.ShoppingMallImpl
	 * @see mde2.impl.Mde2PackageImpl#getShoppingMall()
	 * @generated
	 */
	int SHOPPING_MALL = 0;

	/**
	 * The feature id for the '<em><b>Company Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHOPPING_MALL__COMPANY_NAME = 0;

	/**
	 * The feature id for the '<em><b>Ceo</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHOPPING_MALL__CEO = 1;

	/**
	 * The feature id for the '<em><b>Location</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHOPPING_MALL__LOCATION = 2;

	/**
	 * The feature id for the '<em><b>Shops</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHOPPING_MALL__SHOPS = 3;

	/**
	 * The number of structural features of the '<em>Shopping Mall</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHOPPING_MALL_FEATURE_COUNT = 4;

	/**
	 * The operation id for the '<em>Is Name Not Empty</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHOPPING_MALL___IS_NAME_NOT_EMPTY__STRING = 0;

	/**
	 * The number of operations of the '<em>Shopping Mall</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHOPPING_MALL_OPERATION_COUNT = 1;

	/**
	 * The meta object id for the '{@link mde2.impl.AbstractShopImpl <em>Abstract Shop</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mde2.impl.AbstractShopImpl
	 * @see mde2.impl.Mde2PackageImpl#getAbstractShop()
	 * @generated
	 */
	int ABSTRACT_SHOP = 5;

	/**
	 * The feature id for the '<em><b>Supervisor Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_SHOP__SUPERVISOR_NAME = 0;

	/**
	 * The feature id for the '<em><b>Employee Amount</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_SHOP__EMPLOYEE_AMOUNT = 1;

	/**
	 * The feature id for the '<em><b>Manager Amount</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_SHOP__MANAGER_AMOUNT = 2;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_SHOP__NAME = 3;

	/**
	 * The feature id for the '<em><b>Floor Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_SHOP__FLOOR_NUMBER = 4;

	/**
	 * The number of structural features of the '<em>Abstract Shop</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_SHOP_FEATURE_COUNT = 5;

	/**
	 * The operation id for the '<em>Is Floor Number More Than1</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_SHOP___IS_FLOOR_NUMBER_MORE_THAN1__INT = 0;

	/**
	 * The number of operations of the '<em>Abstract Shop</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_SHOP_OPERATION_COUNT = 1;

	/**
	 * The meta object id for the '{@link mde2.impl.SupermarketImpl <em>Supermarket</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mde2.impl.SupermarketImpl
	 * @see mde2.impl.Mde2PackageImpl#getSupermarket()
	 * @generated
	 */
	int SUPERMARKET = 1;

	/**
	 * The feature id for the '<em><b>Supervisor Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPERMARKET__SUPERVISOR_NAME = ABSTRACT_SHOP__SUPERVISOR_NAME;

	/**
	 * The feature id for the '<em><b>Employee Amount</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPERMARKET__EMPLOYEE_AMOUNT = ABSTRACT_SHOP__EMPLOYEE_AMOUNT;

	/**
	 * The feature id for the '<em><b>Manager Amount</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPERMARKET__MANAGER_AMOUNT = ABSTRACT_SHOP__MANAGER_AMOUNT;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPERMARKET__NAME = ABSTRACT_SHOP__NAME;

	/**
	 * The feature id for the '<em><b>Floor Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPERMARKET__FLOOR_NUMBER = ABSTRACT_SHOP__FLOOR_NUMBER;

	/**
	 * The feature id for the '<em><b>Opening Time</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPERMARKET__OPENING_TIME = ABSTRACT_SHOP_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Closing Time</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPERMARKET__CLOSING_TIME = ABSTRACT_SHOP_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Sections</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPERMARKET__SECTIONS = ABSTRACT_SHOP_FEATURE_COUNT + 2;

	/**
	 * The number of structural features of the '<em>Supermarket</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPERMARKET_FEATURE_COUNT = ABSTRACT_SHOP_FEATURE_COUNT + 3;

	/**
	 * The operation id for the '<em>Is Floor Number More Than1</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPERMARKET___IS_FLOOR_NUMBER_MORE_THAN1__INT = ABSTRACT_SHOP___IS_FLOOR_NUMBER_MORE_THAN1__INT;

	/**
	 * The operation id for the '<em>Is Closing Time Later Than Opening Time</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPERMARKET___IS_CLOSING_TIME_LATER_THAN_OPENING_TIME__STRING_STRING = ABSTRACT_SHOP_OPERATION_COUNT + 0;

	/**
	 * The number of operations of the '<em>Supermarket</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPERMARKET_OPERATION_COUNT = ABSTRACT_SHOP_OPERATION_COUNT + 1;

	/**
	 * The meta object id for the '{@link mde2.impl.SectionImpl <em>Section</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mde2.impl.SectionImpl
	 * @see mde2.impl.Mde2PackageImpl#getSection()
	 * @generated
	 */
	int SECTION = 2;

	/**
	 * The feature id for the '<em><b>Sections</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SECTION__SECTIONS = 0;

	/**
	 * The number of structural features of the '<em>Section</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SECTION_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Section</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SECTION_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link mde2.impl.ShopImpl <em>Shop</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mde2.impl.ShopImpl
	 * @see mde2.impl.Mde2PackageImpl#getShop()
	 * @generated
	 */
	int SHOP = 3;

	/**
	 * The feature id for the '<em><b>Supermarket</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHOP__SUPERMARKET = 0;

	/**
	 * The feature id for the '<em><b>Clothing Stores</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHOP__CLOTHING_STORES = 1;

	/**
	 * The number of structural features of the '<em>Shop</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHOP_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Shop</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHOP_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link mde2.impl.ClothingStoreImpl <em>Clothing Store</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mde2.impl.ClothingStoreImpl
	 * @see mde2.impl.Mde2PackageImpl#getClothingStore()
	 * @generated
	 */
	int CLOTHING_STORE = 4;

	/**
	 * The feature id for the '<em><b>Supervisor Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOTHING_STORE__SUPERVISOR_NAME = ABSTRACT_SHOP__SUPERVISOR_NAME;

	/**
	 * The feature id for the '<em><b>Employee Amount</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOTHING_STORE__EMPLOYEE_AMOUNT = ABSTRACT_SHOP__EMPLOYEE_AMOUNT;

	/**
	 * The feature id for the '<em><b>Manager Amount</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOTHING_STORE__MANAGER_AMOUNT = ABSTRACT_SHOP__MANAGER_AMOUNT;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOTHING_STORE__NAME = ABSTRACT_SHOP__NAME;

	/**
	 * The feature id for the '<em><b>Floor Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOTHING_STORE__FLOOR_NUMBER = ABSTRACT_SHOP__FLOOR_NUMBER;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOTHING_STORE__TYPE = ABSTRACT_SHOP_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Clothing Store</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOTHING_STORE_FEATURE_COUNT = ABSTRACT_SHOP_FEATURE_COUNT + 1;

	/**
	 * The operation id for the '<em>Is Floor Number More Than1</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOTHING_STORE___IS_FLOOR_NUMBER_MORE_THAN1__INT = ABSTRACT_SHOP___IS_FLOOR_NUMBER_MORE_THAN1__INT;

	/**
	 * The number of operations of the '<em>Clothing Store</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOTHING_STORE_OPERATION_COUNT = ABSTRACT_SHOP_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link mde2.sectionType <em>section Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mde2.sectionType
	 * @see mde2.impl.Mde2PackageImpl#getsectionType()
	 * @generated
	 */
	int SECTION_TYPE = 6;

	/**
	 * The meta object id for the '{@link mde2.clothingType <em>clothing Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mde2.clothingType
	 * @see mde2.impl.Mde2PackageImpl#getclothingType()
	 * @generated
	 */
	int CLOTHING_TYPE = 7;

	/**
	 * Returns the meta object for class '{@link mde2.ShoppingMall <em>Shopping Mall</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Shopping Mall</em>'.
	 * @see mde2.ShoppingMall
	 * @generated
	 */
	EClass getShoppingMall();

	/**
	 * Returns the meta object for the attribute '{@link mde2.ShoppingMall#getCompanyName <em>Company Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Company Name</em>'.
	 * @see mde2.ShoppingMall#getCompanyName()
	 * @see #getShoppingMall()
	 * @generated
	 */
	EAttribute getShoppingMall_CompanyName();

	/**
	 * Returns the meta object for the attribute '{@link mde2.ShoppingMall#getCeo <em>Ceo</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Ceo</em>'.
	 * @see mde2.ShoppingMall#getCeo()
	 * @see #getShoppingMall()
	 * @generated
	 */
	EAttribute getShoppingMall_Ceo();

	/**
	 * Returns the meta object for the attribute '{@link mde2.ShoppingMall#getLocation <em>Location</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Location</em>'.
	 * @see mde2.ShoppingMall#getLocation()
	 * @see #getShoppingMall()
	 * @generated
	 */
	EAttribute getShoppingMall_Location();

	/**
	 * Returns the meta object for the containment reference list '{@link mde2.ShoppingMall#getShops <em>Shops</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Shops</em>'.
	 * @see mde2.ShoppingMall#getShops()
	 * @see #getShoppingMall()
	 * @generated
	 */
	EReference getShoppingMall_Shops();

	/**
	 * Returns the meta object for the '{@link mde2.ShoppingMall#isNameNotEmpty(java.lang.String) <em>Is Name Not Empty</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Name Not Empty</em>' operation.
	 * @see mde2.ShoppingMall#isNameNotEmpty(java.lang.String)
	 * @generated
	 */
	EOperation getShoppingMall__IsNameNotEmpty__String();

	/**
	 * Returns the meta object for class '{@link mde2.Supermarket <em>Supermarket</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Supermarket</em>'.
	 * @see mde2.Supermarket
	 * @generated
	 */
	EClass getSupermarket();

	/**
	 * Returns the meta object for the attribute '{@link mde2.Supermarket#getOpeningTime <em>Opening Time</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Opening Time</em>'.
	 * @see mde2.Supermarket#getOpeningTime()
	 * @see #getSupermarket()
	 * @generated
	 */
	EAttribute getSupermarket_OpeningTime();

	/**
	 * Returns the meta object for the attribute '{@link mde2.Supermarket#getClosingTime <em>Closing Time</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Closing Time</em>'.
	 * @see mde2.Supermarket#getClosingTime()
	 * @see #getSupermarket()
	 * @generated
	 */
	EAttribute getSupermarket_ClosingTime();

	/**
	 * Returns the meta object for the containment reference list '{@link mde2.Supermarket#getSections <em>Sections</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Sections</em>'.
	 * @see mde2.Supermarket#getSections()
	 * @see #getSupermarket()
	 * @generated
	 */
	EReference getSupermarket_Sections();

	/**
	 * Returns the meta object for the '{@link mde2.Supermarket#isClosingTimeLaterThanOpeningTime(java.lang.String, java.lang.String) <em>Is Closing Time Later Than Opening Time</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Closing Time Later Than Opening Time</em>' operation.
	 * @see mde2.Supermarket#isClosingTimeLaterThanOpeningTime(java.lang.String, java.lang.String)
	 * @generated
	 */
	EOperation getSupermarket__IsClosingTimeLaterThanOpeningTime__String_String();

	/**
	 * Returns the meta object for class '{@link mde2.Section <em>Section</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Section</em>'.
	 * @see mde2.Section
	 * @generated
	 */
	EClass getSection();

	/**
	 * Returns the meta object for the attribute '{@link mde2.Section#getSections <em>Sections</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Sections</em>'.
	 * @see mde2.Section#getSections()
	 * @see #getSection()
	 * @generated
	 */
	EAttribute getSection_Sections();

	/**
	 * Returns the meta object for class '{@link mde2.Shop <em>Shop</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Shop</em>'.
	 * @see mde2.Shop
	 * @generated
	 */
	EClass getShop();

	/**
	 * Returns the meta object for the containment reference '{@link mde2.Shop#getSupermarket <em>Supermarket</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Supermarket</em>'.
	 * @see mde2.Shop#getSupermarket()
	 * @see #getShop()
	 * @generated
	 */
	EReference getShop_Supermarket();

	/**
	 * Returns the meta object for the containment reference list '{@link mde2.Shop#getClothingStores <em>Clothing Stores</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Clothing Stores</em>'.
	 * @see mde2.Shop#getClothingStores()
	 * @see #getShop()
	 * @generated
	 */
	EReference getShop_ClothingStores();

	/**
	 * Returns the meta object for class '{@link mde2.ClothingStore <em>Clothing Store</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Clothing Store</em>'.
	 * @see mde2.ClothingStore
	 * @generated
	 */
	EClass getClothingStore();

	/**
	 * Returns the meta object for the attribute '{@link mde2.ClothingStore#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see mde2.ClothingStore#getType()
	 * @see #getClothingStore()
	 * @generated
	 */
	EAttribute getClothingStore_Type();

	/**
	 * Returns the meta object for class '{@link mde2.AbstractShop <em>Abstract Shop</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Abstract Shop</em>'.
	 * @see mde2.AbstractShop
	 * @generated
	 */
	EClass getAbstractShop();

	/**
	 * Returns the meta object for the attribute '{@link mde2.AbstractShop#getSupervisorName <em>Supervisor Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Supervisor Name</em>'.
	 * @see mde2.AbstractShop#getSupervisorName()
	 * @see #getAbstractShop()
	 * @generated
	 */
	EAttribute getAbstractShop_SupervisorName();

	/**
	 * Returns the meta object for the attribute '{@link mde2.AbstractShop#getEmployeeAmount <em>Employee Amount</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Employee Amount</em>'.
	 * @see mde2.AbstractShop#getEmployeeAmount()
	 * @see #getAbstractShop()
	 * @generated
	 */
	EAttribute getAbstractShop_EmployeeAmount();

	/**
	 * Returns the meta object for the attribute '{@link mde2.AbstractShop#getManagerAmount <em>Manager Amount</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Manager Amount</em>'.
	 * @see mde2.AbstractShop#getManagerAmount()
	 * @see #getAbstractShop()
	 * @generated
	 */
	EAttribute getAbstractShop_ManagerAmount();

	/**
	 * Returns the meta object for the attribute '{@link mde2.AbstractShop#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see mde2.AbstractShop#getName()
	 * @see #getAbstractShop()
	 * @generated
	 */
	EAttribute getAbstractShop_Name();

	/**
	 * Returns the meta object for the attribute '{@link mde2.AbstractShop#getFloorNumber <em>Floor Number</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Floor Number</em>'.
	 * @see mde2.AbstractShop#getFloorNumber()
	 * @see #getAbstractShop()
	 * @generated
	 */
	EAttribute getAbstractShop_FloorNumber();

	/**
	 * Returns the meta object for the '{@link mde2.AbstractShop#isFloorNumberMoreThan1(int) <em>Is Floor Number More Than1</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Floor Number More Than1</em>' operation.
	 * @see mde2.AbstractShop#isFloorNumberMoreThan1(int)
	 * @generated
	 */
	EOperation getAbstractShop__IsFloorNumberMoreThan1__int();

	/**
	 * Returns the meta object for enum '{@link mde2.sectionType <em>section Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>section Type</em>'.
	 * @see mde2.sectionType
	 * @generated
	 */
	EEnum getsectionType();

	/**
	 * Returns the meta object for enum '{@link mde2.clothingType <em>clothing Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>clothing Type</em>'.
	 * @see mde2.clothingType
	 * @generated
	 */
	EEnum getclothingType();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	Mde2Factory getMde2Factory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link mde2.impl.ShoppingMallImpl <em>Shopping Mall</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mde2.impl.ShoppingMallImpl
		 * @see mde2.impl.Mde2PackageImpl#getShoppingMall()
		 * @generated
		 */
		EClass SHOPPING_MALL = eINSTANCE.getShoppingMall();

		/**
		 * The meta object literal for the '<em><b>Company Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SHOPPING_MALL__COMPANY_NAME = eINSTANCE.getShoppingMall_CompanyName();

		/**
		 * The meta object literal for the '<em><b>Ceo</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SHOPPING_MALL__CEO = eINSTANCE.getShoppingMall_Ceo();

		/**
		 * The meta object literal for the '<em><b>Location</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SHOPPING_MALL__LOCATION = eINSTANCE.getShoppingMall_Location();

		/**
		 * The meta object literal for the '<em><b>Shops</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SHOPPING_MALL__SHOPS = eINSTANCE.getShoppingMall_Shops();

		/**
		 * The meta object literal for the '<em><b>Is Name Not Empty</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation SHOPPING_MALL___IS_NAME_NOT_EMPTY__STRING = eINSTANCE.getShoppingMall__IsNameNotEmpty__String();

		/**
		 * The meta object literal for the '{@link mde2.impl.SupermarketImpl <em>Supermarket</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mde2.impl.SupermarketImpl
		 * @see mde2.impl.Mde2PackageImpl#getSupermarket()
		 * @generated
		 */
		EClass SUPERMARKET = eINSTANCE.getSupermarket();

		/**
		 * The meta object literal for the '<em><b>Opening Time</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SUPERMARKET__OPENING_TIME = eINSTANCE.getSupermarket_OpeningTime();

		/**
		 * The meta object literal for the '<em><b>Closing Time</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SUPERMARKET__CLOSING_TIME = eINSTANCE.getSupermarket_ClosingTime();

		/**
		 * The meta object literal for the '<em><b>Sections</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SUPERMARKET__SECTIONS = eINSTANCE.getSupermarket_Sections();

		/**
		 * The meta object literal for the '<em><b>Is Closing Time Later Than Opening Time</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation SUPERMARKET___IS_CLOSING_TIME_LATER_THAN_OPENING_TIME__STRING_STRING = eINSTANCE
				.getSupermarket__IsClosingTimeLaterThanOpeningTime__String_String();

		/**
		 * The meta object literal for the '{@link mde2.impl.SectionImpl <em>Section</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mde2.impl.SectionImpl
		 * @see mde2.impl.Mde2PackageImpl#getSection()
		 * @generated
		 */
		EClass SECTION = eINSTANCE.getSection();

		/**
		 * The meta object literal for the '<em><b>Sections</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SECTION__SECTIONS = eINSTANCE.getSection_Sections();

		/**
		 * The meta object literal for the '{@link mde2.impl.ShopImpl <em>Shop</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mde2.impl.ShopImpl
		 * @see mde2.impl.Mde2PackageImpl#getShop()
		 * @generated
		 */
		EClass SHOP = eINSTANCE.getShop();

		/**
		 * The meta object literal for the '<em><b>Supermarket</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SHOP__SUPERMARKET = eINSTANCE.getShop_Supermarket();

		/**
		 * The meta object literal for the '<em><b>Clothing Stores</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SHOP__CLOTHING_STORES = eINSTANCE.getShop_ClothingStores();

		/**
		 * The meta object literal for the '{@link mde2.impl.ClothingStoreImpl <em>Clothing Store</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mde2.impl.ClothingStoreImpl
		 * @see mde2.impl.Mde2PackageImpl#getClothingStore()
		 * @generated
		 */
		EClass CLOTHING_STORE = eINSTANCE.getClothingStore();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CLOTHING_STORE__TYPE = eINSTANCE.getClothingStore_Type();

		/**
		 * The meta object literal for the '{@link mde2.impl.AbstractShopImpl <em>Abstract Shop</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mde2.impl.AbstractShopImpl
		 * @see mde2.impl.Mde2PackageImpl#getAbstractShop()
		 * @generated
		 */
		EClass ABSTRACT_SHOP = eINSTANCE.getAbstractShop();

		/**
		 * The meta object literal for the '<em><b>Supervisor Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ABSTRACT_SHOP__SUPERVISOR_NAME = eINSTANCE.getAbstractShop_SupervisorName();

		/**
		 * The meta object literal for the '<em><b>Employee Amount</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ABSTRACT_SHOP__EMPLOYEE_AMOUNT = eINSTANCE.getAbstractShop_EmployeeAmount();

		/**
		 * The meta object literal for the '<em><b>Manager Amount</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ABSTRACT_SHOP__MANAGER_AMOUNT = eINSTANCE.getAbstractShop_ManagerAmount();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ABSTRACT_SHOP__NAME = eINSTANCE.getAbstractShop_Name();

		/**
		 * The meta object literal for the '<em><b>Floor Number</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ABSTRACT_SHOP__FLOOR_NUMBER = eINSTANCE.getAbstractShop_FloorNumber();

		/**
		 * The meta object literal for the '<em><b>Is Floor Number More Than1</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ABSTRACT_SHOP___IS_FLOOR_NUMBER_MORE_THAN1__INT = eINSTANCE
				.getAbstractShop__IsFloorNumberMoreThan1__int();

		/**
		 * The meta object literal for the '{@link mde2.sectionType <em>section Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mde2.sectionType
		 * @see mde2.impl.Mde2PackageImpl#getsectionType()
		 * @generated
		 */
		EEnum SECTION_TYPE = eINSTANCE.getsectionType();

		/**
		 * The meta object literal for the '{@link mde2.clothingType <em>clothing Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mde2.clothingType
		 * @see mde2.impl.Mde2PackageImpl#getclothingType()
		 * @generated
		 */
		EEnum CLOTHING_TYPE = eINSTANCE.getclothingType();

	}

} //Mde2Package
