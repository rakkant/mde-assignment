/**
 */
package mde2;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.Enumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>section Type</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * @see mde2.Mde2Package#getsectionType()
 * @model
 * @generated
 */
public enum sectionType implements Enumerator {
	/**
	 * The '<em><b>Fresh Produce</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #FRESH_PRODUCE_VALUE
	 * @generated
	 * @ordered
	 */
	FRESH_PRODUCE(0, "freshProduce", "freshProduce"),

	/**
	 * The '<em><b>Fresh Vegetables And Fruits</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #FRESH_VEGETABLES_AND_FRUITS_VALUE
	 * @generated
	 * @ordered
	 */
	FRESH_VEGETABLES_AND_FRUITS(1, "freshVegetablesAndFruits", "freshVegetablesAndFruits"),

	/**
	 * The '<em><b>Kitchen Ware</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #KITCHEN_WARE_VALUE
	 * @generated
	 * @ordered
	 */
	KITCHEN_WARE(2, "kitchenWare", "kitchenWare"),

	/**
	 * The '<em><b>Household Cleaners</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #HOUSEHOLD_CLEANERS_VALUE
	 * @generated
	 * @ordered
	 */
	HOUSEHOLD_CLEANERS(3, "householdCleaners", "householdCleaners");

	/**
	 * The '<em><b>Fresh Produce</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #FRESH_PRODUCE
	 * @model name="freshProduce"
	 * @generated
	 * @ordered
	 */
	public static final int FRESH_PRODUCE_VALUE = 0;

	/**
	 * The '<em><b>Fresh Vegetables And Fruits</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #FRESH_VEGETABLES_AND_FRUITS
	 * @model name="freshVegetablesAndFruits"
	 * @generated
	 * @ordered
	 */
	public static final int FRESH_VEGETABLES_AND_FRUITS_VALUE = 1;

	/**
	 * The '<em><b>Kitchen Ware</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #KITCHEN_WARE
	 * @model name="kitchenWare"
	 * @generated
	 * @ordered
	 */
	public static final int KITCHEN_WARE_VALUE = 2;

	/**
	 * The '<em><b>Household Cleaners</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #HOUSEHOLD_CLEANERS
	 * @model name="householdCleaners"
	 * @generated
	 * @ordered
	 */
	public static final int HOUSEHOLD_CLEANERS_VALUE = 3;

	/**
	 * An array of all the '<em><b>section Type</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final sectionType[] VALUES_ARRAY = new sectionType[] { FRESH_PRODUCE, FRESH_VEGETABLES_AND_FRUITS,
			KITCHEN_WARE, HOUSEHOLD_CLEANERS, };

	/**
	 * A public read-only list of all the '<em><b>section Type</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final List<sectionType> VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	/**
	 * Returns the '<em><b>section Type</b></em>' literal with the specified literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param literal the literal.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static sectionType get(String literal) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			sectionType result = VALUES_ARRAY[i];
			if (result.toString().equals(literal)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>section Type</b></em>' literal with the specified name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param name the name.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static sectionType getByName(String name) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			sectionType result = VALUES_ARRAY[i];
			if (result.getName().equals(name)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>section Type</b></em>' literal with the specified integer value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the integer value.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static sectionType get(int value) {
		switch (value) {
		case FRESH_PRODUCE_VALUE:
			return FRESH_PRODUCE;
		case FRESH_VEGETABLES_AND_FRUITS_VALUE:
			return FRESH_VEGETABLES_AND_FRUITS;
		case KITCHEN_WARE_VALUE:
			return KITCHEN_WARE;
		case HOUSEHOLD_CLEANERS_VALUE:
			return HOUSEHOLD_CLEANERS;
		}
		return null;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final int value;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String name;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String literal;

	/**
	 * Only this class can construct instances.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private sectionType(int value, String name, String literal) {
		this.value = value;
		this.name = name;
		this.literal = literal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getValue() {
		return value;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLiteral() {
		return literal;
	}

	/**
	 * Returns the literal value of the enumerator, which is its string representation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		return literal;
	}

} //sectionType
