/**
 */
package mde2;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Shop</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link mde2.Shop#getSupermarket <em>Supermarket</em>}</li>
 *   <li>{@link mde2.Shop#getClothingStores <em>Clothing Stores</em>}</li>
 * </ul>
 *
 * @see mde2.Mde2Package#getShop()
 * @model
 * @generated
 */
public interface Shop extends EObject {
	/**
	 * Returns the value of the '<em><b>Supermarket</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Supermarket</em>' containment reference.
	 * @see #setSupermarket(Supermarket)
	 * @see mde2.Mde2Package#getShop_Supermarket()
	 * @model containment="true" required="true"
	 * @generated
	 */
	Supermarket getSupermarket();

	/**
	 * Sets the value of the '{@link mde2.Shop#getSupermarket <em>Supermarket</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Supermarket</em>' containment reference.
	 * @see #getSupermarket()
	 * @generated
	 */
	void setSupermarket(Supermarket value);

	/**
	 * Returns the value of the '<em><b>Clothing Stores</b></em>' containment reference list.
	 * The list contents are of type {@link mde2.ClothingStore}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Clothing Stores</em>' containment reference list.
	 * @see mde2.Mde2Package#getShop_ClothingStores()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<ClothingStore> getClothingStores();

} // Shop
