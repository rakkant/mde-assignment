/**
 */
package mde2.impl;

import java.lang.reflect.InvocationTargetException;

import java.util.Collection;

import mde2.Mde2Package;
import mde2.Shop;
import mde2.ShoppingMall;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Shopping Mall</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link mde2.impl.ShoppingMallImpl#getCompanyName <em>Company Name</em>}</li>
 *   <li>{@link mde2.impl.ShoppingMallImpl#getCeo <em>Ceo</em>}</li>
 *   <li>{@link mde2.impl.ShoppingMallImpl#getLocation <em>Location</em>}</li>
 *   <li>{@link mde2.impl.ShoppingMallImpl#getShops <em>Shops</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ShoppingMallImpl extends MinimalEObjectImpl.Container implements ShoppingMall {
	/**
	 * The default value of the '{@link #getCompanyName() <em>Company Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCompanyName()
	 * @generated
	 * @ordered
	 */
	protected static final String COMPANY_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getCompanyName() <em>Company Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCompanyName()
	 * @generated
	 * @ordered
	 */
	protected String companyName = COMPANY_NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getCeo() <em>Ceo</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCeo()
	 * @generated
	 * @ordered
	 */
	protected static final String CEO_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getCeo() <em>Ceo</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCeo()
	 * @generated
	 * @ordered
	 */
	protected String ceo = CEO_EDEFAULT;

	/**
	 * The default value of the '{@link #getLocation() <em>Location</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLocation()
	 * @generated
	 * @ordered
	 */
	protected static final String LOCATION_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getLocation() <em>Location</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLocation()
	 * @generated
	 * @ordered
	 */
	protected String location = LOCATION_EDEFAULT;

	/**
	 * The cached value of the '{@link #getShops() <em>Shops</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getShops()
	 * @generated
	 * @ordered
	 */
	protected EList<Shop> shops;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ShoppingMallImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Mde2Package.Literals.SHOPPING_MALL;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getCompanyName() {
		return companyName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCompanyName(String newCompanyName) {
		String oldCompanyName = companyName;
		companyName = newCompanyName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Mde2Package.SHOPPING_MALL__COMPANY_NAME,
					oldCompanyName, companyName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getCeo() {
		return ceo;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCeo(String newCeo) {
		String oldCeo = ceo;
		ceo = newCeo;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Mde2Package.SHOPPING_MALL__CEO, oldCeo, ceo));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLocation() {
		return location;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setLocation(String newLocation) {
		String oldLocation = location;
		location = newLocation;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Mde2Package.SHOPPING_MALL__LOCATION, oldLocation,
					location));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Shop> getShops() {
		if (shops == null) {
			shops = new EObjectContainmentEList<Shop>(Shop.class, this, Mde2Package.SHOPPING_MALL__SHOPS);
		}
		return shops;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Boolean isNameNotEmpty(String name) {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Mde2Package.SHOPPING_MALL__SHOPS:
			return ((InternalEList<?>) getShops()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Mde2Package.SHOPPING_MALL__COMPANY_NAME:
			return getCompanyName();
		case Mde2Package.SHOPPING_MALL__CEO:
			return getCeo();
		case Mde2Package.SHOPPING_MALL__LOCATION:
			return getLocation();
		case Mde2Package.SHOPPING_MALL__SHOPS:
			return getShops();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Mde2Package.SHOPPING_MALL__COMPANY_NAME:
			setCompanyName((String) newValue);
			return;
		case Mde2Package.SHOPPING_MALL__CEO:
			setCeo((String) newValue);
			return;
		case Mde2Package.SHOPPING_MALL__LOCATION:
			setLocation((String) newValue);
			return;
		case Mde2Package.SHOPPING_MALL__SHOPS:
			getShops().clear();
			getShops().addAll((Collection<? extends Shop>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Mde2Package.SHOPPING_MALL__COMPANY_NAME:
			setCompanyName(COMPANY_NAME_EDEFAULT);
			return;
		case Mde2Package.SHOPPING_MALL__CEO:
			setCeo(CEO_EDEFAULT);
			return;
		case Mde2Package.SHOPPING_MALL__LOCATION:
			setLocation(LOCATION_EDEFAULT);
			return;
		case Mde2Package.SHOPPING_MALL__SHOPS:
			getShops().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Mde2Package.SHOPPING_MALL__COMPANY_NAME:
			return COMPANY_NAME_EDEFAULT == null ? companyName != null : !COMPANY_NAME_EDEFAULT.equals(companyName);
		case Mde2Package.SHOPPING_MALL__CEO:
			return CEO_EDEFAULT == null ? ceo != null : !CEO_EDEFAULT.equals(ceo);
		case Mde2Package.SHOPPING_MALL__LOCATION:
			return LOCATION_EDEFAULT == null ? location != null : !LOCATION_EDEFAULT.equals(location);
		case Mde2Package.SHOPPING_MALL__SHOPS:
			return shops != null && !shops.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
		case Mde2Package.SHOPPING_MALL___IS_NAME_NOT_EMPTY__STRING:
			return isNameNotEmpty((String) arguments.get(0));
		}
		return super.eInvoke(operationID, arguments);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (companyName: ");
		result.append(companyName);
		result.append(", ceo: ");
		result.append(ceo);
		result.append(", location: ");
		result.append(location);
		result.append(')');
		return result.toString();
	}

} //ShoppingMallImpl
