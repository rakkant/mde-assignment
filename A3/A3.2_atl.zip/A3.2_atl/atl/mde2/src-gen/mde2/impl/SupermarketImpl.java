/**
 */
package mde2.impl;

import java.lang.reflect.InvocationTargetException;

import java.util.Collection;

import mde2.Mde2Package;
import mde2.Section;
import mde2.Supermarket;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Supermarket</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link mde2.impl.SupermarketImpl#getOpeningTime <em>Opening Time</em>}</li>
 *   <li>{@link mde2.impl.SupermarketImpl#getClosingTime <em>Closing Time</em>}</li>
 *   <li>{@link mde2.impl.SupermarketImpl#getSections <em>Sections</em>}</li>
 * </ul>
 *
 * @generated
 */
public class SupermarketImpl extends AbstractShopImpl implements Supermarket {
	/**
	 * The default value of the '{@link #getOpeningTime() <em>Opening Time</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOpeningTime()
	 * @generated
	 * @ordered
	 */
	protected static final String OPENING_TIME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getOpeningTime() <em>Opening Time</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOpeningTime()
	 * @generated
	 * @ordered
	 */
	protected String openingTime = OPENING_TIME_EDEFAULT;

	/**
	 * The default value of the '{@link #getClosingTime() <em>Closing Time</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getClosingTime()
	 * @generated
	 * @ordered
	 */
	protected static final String CLOSING_TIME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getClosingTime() <em>Closing Time</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getClosingTime()
	 * @generated
	 * @ordered
	 */
	protected String closingTime = CLOSING_TIME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getSections() <em>Sections</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSections()
	 * @generated
	 * @ordered
	 */
	protected EList<Section> sections;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SupermarketImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Mde2Package.Literals.SUPERMARKET;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getOpeningTime() {
		return openingTime;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setOpeningTime(String newOpeningTime) {
		String oldOpeningTime = openingTime;
		openingTime = newOpeningTime;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Mde2Package.SUPERMARKET__OPENING_TIME, oldOpeningTime,
					openingTime));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getClosingTime() {
		return closingTime;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setClosingTime(String newClosingTime) {
		String oldClosingTime = closingTime;
		closingTime = newClosingTime;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Mde2Package.SUPERMARKET__CLOSING_TIME, oldClosingTime,
					closingTime));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Section> getSections() {
		if (sections == null) {
			sections = new EObjectContainmentEList<Section>(Section.class, this, Mde2Package.SUPERMARKET__SECTIONS);
		}
		return sections;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Boolean isClosingTimeLaterThanOpeningTime(String closingtime, String openingTime) {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Mde2Package.SUPERMARKET__SECTIONS:
			return ((InternalEList<?>) getSections()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Mde2Package.SUPERMARKET__OPENING_TIME:
			return getOpeningTime();
		case Mde2Package.SUPERMARKET__CLOSING_TIME:
			return getClosingTime();
		case Mde2Package.SUPERMARKET__SECTIONS:
			return getSections();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Mde2Package.SUPERMARKET__OPENING_TIME:
			setOpeningTime((String) newValue);
			return;
		case Mde2Package.SUPERMARKET__CLOSING_TIME:
			setClosingTime((String) newValue);
			return;
		case Mde2Package.SUPERMARKET__SECTIONS:
			getSections().clear();
			getSections().addAll((Collection<? extends Section>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Mde2Package.SUPERMARKET__OPENING_TIME:
			setOpeningTime(OPENING_TIME_EDEFAULT);
			return;
		case Mde2Package.SUPERMARKET__CLOSING_TIME:
			setClosingTime(CLOSING_TIME_EDEFAULT);
			return;
		case Mde2Package.SUPERMARKET__SECTIONS:
			getSections().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Mde2Package.SUPERMARKET__OPENING_TIME:
			return OPENING_TIME_EDEFAULT == null ? openingTime != null : !OPENING_TIME_EDEFAULT.equals(openingTime);
		case Mde2Package.SUPERMARKET__CLOSING_TIME:
			return CLOSING_TIME_EDEFAULT == null ? closingTime != null : !CLOSING_TIME_EDEFAULT.equals(closingTime);
		case Mde2Package.SUPERMARKET__SECTIONS:
			return sections != null && !sections.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
		case Mde2Package.SUPERMARKET___IS_CLOSING_TIME_LATER_THAN_OPENING_TIME__STRING_STRING:
			return isClosingTimeLaterThanOpeningTime((String) arguments.get(0), (String) arguments.get(1));
		}
		return super.eInvoke(operationID, arguments);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (openingTime: ");
		result.append(openingTime);
		result.append(", closingTime: ");
		result.append(closingTime);
		result.append(')');
		return result.toString();
	}

} //SupermarketImpl
