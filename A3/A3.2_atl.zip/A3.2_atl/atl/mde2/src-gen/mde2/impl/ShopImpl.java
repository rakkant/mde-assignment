/**
 */
package mde2.impl;

import java.util.Collection;

import mde2.ClothingStore;
import mde2.Mde2Package;
import mde2.Shop;
import mde2.Supermarket;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Shop</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link mde2.impl.ShopImpl#getSupermarket <em>Supermarket</em>}</li>
 *   <li>{@link mde2.impl.ShopImpl#getClothingStores <em>Clothing Stores</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ShopImpl extends MinimalEObjectImpl.Container implements Shop {
	/**
	 * The cached value of the '{@link #getSupermarket() <em>Supermarket</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSupermarket()
	 * @generated
	 * @ordered
	 */
	protected Supermarket supermarket;

	/**
	 * The cached value of the '{@link #getClothingStores() <em>Clothing Stores</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getClothingStores()
	 * @generated
	 * @ordered
	 */
	protected EList<ClothingStore> clothingStores;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ShopImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Mde2Package.Literals.SHOP;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Supermarket getSupermarket() {
		return supermarket;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetSupermarket(Supermarket newSupermarket, NotificationChain msgs) {
		Supermarket oldSupermarket = supermarket;
		supermarket = newSupermarket;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					Mde2Package.SHOP__SUPERMARKET, oldSupermarket, newSupermarket);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSupermarket(Supermarket newSupermarket) {
		if (newSupermarket != supermarket) {
			NotificationChain msgs = null;
			if (supermarket != null)
				msgs = ((InternalEObject) supermarket).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - Mde2Package.SHOP__SUPERMARKET, null, msgs);
			if (newSupermarket != null)
				msgs = ((InternalEObject) newSupermarket).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - Mde2Package.SHOP__SUPERMARKET, null, msgs);
			msgs = basicSetSupermarket(newSupermarket, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Mde2Package.SHOP__SUPERMARKET, newSupermarket,
					newSupermarket));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<ClothingStore> getClothingStores() {
		if (clothingStores == null) {
			clothingStores = new EObjectContainmentEList<ClothingStore>(ClothingStore.class, this,
					Mde2Package.SHOP__CLOTHING_STORES);
		}
		return clothingStores;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Mde2Package.SHOP__SUPERMARKET:
			return basicSetSupermarket(null, msgs);
		case Mde2Package.SHOP__CLOTHING_STORES:
			return ((InternalEList<?>) getClothingStores()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Mde2Package.SHOP__SUPERMARKET:
			return getSupermarket();
		case Mde2Package.SHOP__CLOTHING_STORES:
			return getClothingStores();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Mde2Package.SHOP__SUPERMARKET:
			setSupermarket((Supermarket) newValue);
			return;
		case Mde2Package.SHOP__CLOTHING_STORES:
			getClothingStores().clear();
			getClothingStores().addAll((Collection<? extends ClothingStore>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Mde2Package.SHOP__SUPERMARKET:
			setSupermarket((Supermarket) null);
			return;
		case Mde2Package.SHOP__CLOTHING_STORES:
			getClothingStores().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Mde2Package.SHOP__SUPERMARKET:
			return supermarket != null;
		case Mde2Package.SHOP__CLOTHING_STORES:
			return clothingStores != null && !clothingStores.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //ShopImpl
