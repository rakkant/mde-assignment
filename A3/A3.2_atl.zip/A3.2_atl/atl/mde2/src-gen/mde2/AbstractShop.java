/**
 */
package mde2;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Abstract Shop</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link mde2.AbstractShop#getSupervisorName <em>Supervisor Name</em>}</li>
 *   <li>{@link mde2.AbstractShop#getEmployeeAmount <em>Employee Amount</em>}</li>
 *   <li>{@link mde2.AbstractShop#getManagerAmount <em>Manager Amount</em>}</li>
 *   <li>{@link mde2.AbstractShop#getName <em>Name</em>}</li>
 *   <li>{@link mde2.AbstractShop#getFloorNumber <em>Floor Number</em>}</li>
 * </ul>
 *
 * @see mde2.Mde2Package#getAbstractShop()
 * @model abstract="true"
 * @generated
 */
public interface AbstractShop extends EObject {
	/**
	 * Returns the value of the '<em><b>Supervisor Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Supervisor Name</em>' attribute.
	 * @see #setSupervisorName(String)
	 * @see mde2.Mde2Package#getAbstractShop_SupervisorName()
	 * @model
	 * @generated
	 */
	String getSupervisorName();

	/**
	 * Sets the value of the '{@link mde2.AbstractShop#getSupervisorName <em>Supervisor Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Supervisor Name</em>' attribute.
	 * @see #getSupervisorName()
	 * @generated
	 */
	void setSupervisorName(String value);

	/**
	 * Returns the value of the '<em><b>Employee Amount</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Employee Amount</em>' attribute.
	 * @see #setEmployeeAmount(int)
	 * @see mde2.Mde2Package#getAbstractShop_EmployeeAmount()
	 * @model
	 * @generated
	 */
	int getEmployeeAmount();

	/**
	 * Sets the value of the '{@link mde2.AbstractShop#getEmployeeAmount <em>Employee Amount</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Employee Amount</em>' attribute.
	 * @see #getEmployeeAmount()
	 * @generated
	 */
	void setEmployeeAmount(int value);

	/**
	 * Returns the value of the '<em><b>Manager Amount</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Manager Amount</em>' attribute.
	 * @see #setManagerAmount(int)
	 * @see mde2.Mde2Package#getAbstractShop_ManagerAmount()
	 * @model
	 * @generated
	 */
	int getManagerAmount();

	/**
	 * Sets the value of the '{@link mde2.AbstractShop#getManagerAmount <em>Manager Amount</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Manager Amount</em>' attribute.
	 * @see #getManagerAmount()
	 * @generated
	 */
	void setManagerAmount(int value);

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see mde2.Mde2Package#getAbstractShop_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link mde2.AbstractShop#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Floor Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Floor Number</em>' attribute.
	 * @see #setFloorNumber(int)
	 * @see mde2.Mde2Package#getAbstractShop_FloorNumber()
	 * @model
	 * @generated
	 */
	int getFloorNumber();

	/**
	 * Sets the value of the '{@link mde2.AbstractShop#getFloorNumber <em>Floor Number</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Floor Number</em>' attribute.
	 * @see #getFloorNumber()
	 * @generated
	 */
	void setFloorNumber(int value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot body='floorNumber &gt; 1'"
	 * @generated
	 */
	Boolean isFloorNumberMoreThan1(int floorNumber);

} // AbstractShop
