/**
 */
package mde.tests;

import junit.framework.TestCase;

import mde.AbstractDepartment;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Abstract Department</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following operations are tested:
 * <ul>
 *   <li>{@link mde.AbstractDepartment#isManagerAmountLessThanEmployeeAmount(int, int) <em>Is Manager Amount Less Than Employee Amount</em>}</li>
 *   <li>{@link mde.AbstractDepartment#isCapacityGreaterThanTotalDepartmentsMultiplyBy20(int, int) <em>Is Capacity Greater Than Total Departments Multiply By20</em>}</li>
 * </ul>
 * </p>
 * @generated
 */
public abstract class AbstractDepartmentTest extends TestCase {

	/**
	 * The fixture for this Abstract Department test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AbstractDepartment fixture = null;

	/**
	 * Constructs a new Abstract Department test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AbstractDepartmentTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this Abstract Department test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(AbstractDepartment fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this Abstract Department test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AbstractDepartment getFixture() {
		return fixture;
	}

	/**
	 * Tests the '{@link mde.AbstractDepartment#isManagerAmountLessThanEmployeeAmount(int, int) <em>Is Manager Amount Less Than Employee Amount</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mde.AbstractDepartment#isManagerAmountLessThanEmployeeAmount(int, int)
	 * @generated
	 */
	public void testIsManagerAmountLessThanEmployeeAmount__int_int() {
		// TODO: implement this operation test method
		// Ensure that you remove @generated or mark it @generated NOT
		fail();
	}

	/**
	 * Tests the '{@link mde.AbstractDepartment#isCapacityGreaterThanTotalDepartmentsMultiplyBy20(int, int) <em>Is Capacity Greater Than Total Departments Multiply By20</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mde.AbstractDepartment#isCapacityGreaterThanTotalDepartmentsMultiplyBy20(int, int)
	 * @generated
	 */
	public void testIsCapacityGreaterThanTotalDepartmentsMultiplyBy20__int_int() {
		// TODO: implement this operation test method
		// Ensure that you remove @generated or mark it @generated NOT
		fail();
	}

} //AbstractDepartmentTest
