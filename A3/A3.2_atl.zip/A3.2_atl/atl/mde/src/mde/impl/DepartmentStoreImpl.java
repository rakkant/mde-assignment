/**
 */
package mde.impl;

import java.lang.reflect.InvocationTargetException;

import java.util.Collection;

import mde.Department;
import mde.DepartmentStore;
import mde.MdePackage;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Department Store</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link mde.impl.DepartmentStoreImpl#getOwner <em>Owner</em>}</li>
 *   <li>{@link mde.impl.DepartmentStoreImpl#getLocation <em>Location</em>}</li>
 *   <li>{@link mde.impl.DepartmentStoreImpl#getDepartments <em>Departments</em>}</li>
 *   <li>{@link mde.impl.DepartmentStoreImpl#getTotalDepartments <em>Total Departments</em>}</li>
 *   <li>{@link mde.impl.DepartmentStoreImpl#getName <em>Name</em>}</li>
 * </ul>
 *
 * @generated
 */
public class DepartmentStoreImpl extends MinimalEObjectImpl.Container implements DepartmentStore {
	/**
	 * The default value of the '{@link #getOwner() <em>Owner</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOwner()
	 * @generated
	 * @ordered
	 */
	protected static final String OWNER_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getOwner() <em>Owner</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOwner()
	 * @generated
	 * @ordered
	 */
	protected String owner = OWNER_EDEFAULT;

	/**
	 * The default value of the '{@link #getLocation() <em>Location</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLocation()
	 * @generated
	 * @ordered
	 */
	protected static final String LOCATION_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getLocation() <em>Location</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLocation()
	 * @generated
	 * @ordered
	 */
	protected String location = LOCATION_EDEFAULT;

	/**
	 * The cached value of the '{@link #getDepartments() <em>Departments</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDepartments()
	 * @generated
	 * @ordered
	 */
	protected EList<Department> departments;

	/**
	 * The default value of the '{@link #getTotalDepartments() <em>Total Departments</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTotalDepartments()
	 * @generated
	 * @ordered
	 */
	protected static final int TOTAL_DEPARTMENTS_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getTotalDepartments() <em>Total Departments</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTotalDepartments()
	 * @generated
	 * @ordered
	 */
	protected int totalDepartments = TOTAL_DEPARTMENTS_EDEFAULT;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DepartmentStoreImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MdePackage.Literals.DEPARTMENT_STORE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getOwner() {
		return owner;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setOwner(String newOwner) {
		String oldOwner = owner;
		owner = newOwner;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MdePackage.DEPARTMENT_STORE__OWNER, oldOwner, owner));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLocation() {
		return location;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setLocation(String newLocation) {
		String oldLocation = location;
		location = newLocation;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MdePackage.DEPARTMENT_STORE__LOCATION, oldLocation, location));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Department> getDepartments() {
		if (departments == null) {
			departments = new EObjectContainmentEList<Department>(Department.class, this, MdePackage.DEPARTMENT_STORE__DEPARTMENTS);
		}
		return departments;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getTotalDepartments() {
		return totalDepartments;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTotalDepartments(int newTotalDepartments) {
		int oldTotalDepartments = totalDepartments;
		totalDepartments = newTotalDepartments;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MdePackage.DEPARTMENT_STORE__TOTAL_DEPARTMENTS, oldTotalDepartments, totalDepartments));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MdePackage.DEPARTMENT_STORE__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Boolean isNameNotEmpty(String name) {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case MdePackage.DEPARTMENT_STORE__DEPARTMENTS:
				return ((InternalEList<?>)getDepartments()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case MdePackage.DEPARTMENT_STORE__OWNER:
				return getOwner();
			case MdePackage.DEPARTMENT_STORE__LOCATION:
				return getLocation();
			case MdePackage.DEPARTMENT_STORE__DEPARTMENTS:
				return getDepartments();
			case MdePackage.DEPARTMENT_STORE__TOTAL_DEPARTMENTS:
				return getTotalDepartments();
			case MdePackage.DEPARTMENT_STORE__NAME:
				return getName();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case MdePackage.DEPARTMENT_STORE__OWNER:
				setOwner((String)newValue);
				return;
			case MdePackage.DEPARTMENT_STORE__LOCATION:
				setLocation((String)newValue);
				return;
			case MdePackage.DEPARTMENT_STORE__DEPARTMENTS:
				getDepartments().clear();
				getDepartments().addAll((Collection<? extends Department>)newValue);
				return;
			case MdePackage.DEPARTMENT_STORE__TOTAL_DEPARTMENTS:
				setTotalDepartments((Integer)newValue);
				return;
			case MdePackage.DEPARTMENT_STORE__NAME:
				setName((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case MdePackage.DEPARTMENT_STORE__OWNER:
				setOwner(OWNER_EDEFAULT);
				return;
			case MdePackage.DEPARTMENT_STORE__LOCATION:
				setLocation(LOCATION_EDEFAULT);
				return;
			case MdePackage.DEPARTMENT_STORE__DEPARTMENTS:
				getDepartments().clear();
				return;
			case MdePackage.DEPARTMENT_STORE__TOTAL_DEPARTMENTS:
				setTotalDepartments(TOTAL_DEPARTMENTS_EDEFAULT);
				return;
			case MdePackage.DEPARTMENT_STORE__NAME:
				setName(NAME_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case MdePackage.DEPARTMENT_STORE__OWNER:
				return OWNER_EDEFAULT == null ? owner != null : !OWNER_EDEFAULT.equals(owner);
			case MdePackage.DEPARTMENT_STORE__LOCATION:
				return LOCATION_EDEFAULT == null ? location != null : !LOCATION_EDEFAULT.equals(location);
			case MdePackage.DEPARTMENT_STORE__DEPARTMENTS:
				return departments != null && !departments.isEmpty();
			case MdePackage.DEPARTMENT_STORE__TOTAL_DEPARTMENTS:
				return totalDepartments != TOTAL_DEPARTMENTS_EDEFAULT;
			case MdePackage.DEPARTMENT_STORE__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
			case MdePackage.DEPARTMENT_STORE___IS_NAME_NOT_EMPTY__STRING:
				return isNameNotEmpty((String)arguments.get(0));
		}
		return super.eInvoke(operationID, arguments);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (owner: ");
		result.append(owner);
		result.append(", location: ");
		result.append(location);
		result.append(", TotalDepartments: ");
		result.append(totalDepartments);
		result.append(", name: ");
		result.append(name);
		result.append(')');
		return result.toString();
	}

} //DepartmentStoreImpl
