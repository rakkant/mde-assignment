/**
 */
package mde.impl;

import java.util.Collection;

import mde.Cinema;
import mde.ClothingStore;
import mde.Department;
import mde.Foodcourt;
import mde.MdePackage;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Department</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link mde.impl.DepartmentImpl#getClothingStores <em>Clothing Stores</em>}</li>
 *   <li>{@link mde.impl.DepartmentImpl#getCinema <em>Cinema</em>}</li>
 *   <li>{@link mde.impl.DepartmentImpl#getFoodcourt <em>Foodcourt</em>}</li>
 * </ul>
 *
 * @generated
 */
public class DepartmentImpl extends MinimalEObjectImpl.Container implements Department {
	/**
	 * The cached value of the '{@link #getClothingStores() <em>Clothing Stores</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getClothingStores()
	 * @generated
	 * @ordered
	 */
	protected EList<ClothingStore> clothingStores;

	/**
	 * The cached value of the '{@link #getCinema() <em>Cinema</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCinema()
	 * @generated
	 * @ordered
	 */
	protected Cinema cinema;

	/**
	 * The cached value of the '{@link #getFoodcourt() <em>Foodcourt</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFoodcourt()
	 * @generated
	 * @ordered
	 */
	protected Foodcourt foodcourt;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DepartmentImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MdePackage.Literals.DEPARTMENT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<ClothingStore> getClothingStores() {
		if (clothingStores == null) {
			clothingStores = new EObjectContainmentEList<ClothingStore>(ClothingStore.class, this, MdePackage.DEPARTMENT__CLOTHING_STORES);
		}
		return clothingStores;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Cinema getCinema() {
		return cinema;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetCinema(Cinema newCinema, NotificationChain msgs) {
		Cinema oldCinema = cinema;
		cinema = newCinema;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, MdePackage.DEPARTMENT__CINEMA, oldCinema, newCinema);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCinema(Cinema newCinema) {
		if (newCinema != cinema) {
			NotificationChain msgs = null;
			if (cinema != null)
				msgs = ((InternalEObject)cinema).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - MdePackage.DEPARTMENT__CINEMA, null, msgs);
			if (newCinema != null)
				msgs = ((InternalEObject)newCinema).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - MdePackage.DEPARTMENT__CINEMA, null, msgs);
			msgs = basicSetCinema(newCinema, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MdePackage.DEPARTMENT__CINEMA, newCinema, newCinema));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Foodcourt getFoodcourt() {
		return foodcourt;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetFoodcourt(Foodcourt newFoodcourt, NotificationChain msgs) {
		Foodcourt oldFoodcourt = foodcourt;
		foodcourt = newFoodcourt;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, MdePackage.DEPARTMENT__FOODCOURT, oldFoodcourt, newFoodcourt);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setFoodcourt(Foodcourt newFoodcourt) {
		if (newFoodcourt != foodcourt) {
			NotificationChain msgs = null;
			if (foodcourt != null)
				msgs = ((InternalEObject)foodcourt).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - MdePackage.DEPARTMENT__FOODCOURT, null, msgs);
			if (newFoodcourt != null)
				msgs = ((InternalEObject)newFoodcourt).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - MdePackage.DEPARTMENT__FOODCOURT, null, msgs);
			msgs = basicSetFoodcourt(newFoodcourt, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MdePackage.DEPARTMENT__FOODCOURT, newFoodcourt, newFoodcourt));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case MdePackage.DEPARTMENT__CLOTHING_STORES:
				return ((InternalEList<?>)getClothingStores()).basicRemove(otherEnd, msgs);
			case MdePackage.DEPARTMENT__CINEMA:
				return basicSetCinema(null, msgs);
			case MdePackage.DEPARTMENT__FOODCOURT:
				return basicSetFoodcourt(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case MdePackage.DEPARTMENT__CLOTHING_STORES:
				return getClothingStores();
			case MdePackage.DEPARTMENT__CINEMA:
				return getCinema();
			case MdePackage.DEPARTMENT__FOODCOURT:
				return getFoodcourt();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case MdePackage.DEPARTMENT__CLOTHING_STORES:
				getClothingStores().clear();
				getClothingStores().addAll((Collection<? extends ClothingStore>)newValue);
				return;
			case MdePackage.DEPARTMENT__CINEMA:
				setCinema((Cinema)newValue);
				return;
			case MdePackage.DEPARTMENT__FOODCOURT:
				setFoodcourt((Foodcourt)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case MdePackage.DEPARTMENT__CLOTHING_STORES:
				getClothingStores().clear();
				return;
			case MdePackage.DEPARTMENT__CINEMA:
				setCinema((Cinema)null);
				return;
			case MdePackage.DEPARTMENT__FOODCOURT:
				setFoodcourt((Foodcourt)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case MdePackage.DEPARTMENT__CLOTHING_STORES:
				return clothingStores != null && !clothingStores.isEmpty();
			case MdePackage.DEPARTMENT__CINEMA:
				return cinema != null;
			case MdePackage.DEPARTMENT__FOODCOURT:
				return foodcourt != null;
		}
		return super.eIsSet(featureID);
	}

} //DepartmentImpl
