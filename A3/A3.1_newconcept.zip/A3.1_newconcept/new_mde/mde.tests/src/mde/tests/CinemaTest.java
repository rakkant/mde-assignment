/**
 */
package mde.tests;

import junit.textui.TestRunner;

import mde.Cinema;
import mde.MdeFactory;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Cinema</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class CinemaTest extends AbstractDepartmentTest {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(CinemaTest.class);
	}

	/**
	 * Constructs a new Cinema test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CinemaTest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this Cinema test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected Cinema getFixture() {
		return (Cinema)fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(MdeFactory.eINSTANCE.createCinema());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //CinemaTest
