/**
 */
package mde.tests;

import junit.framework.TestCase;

import junit.textui.TestRunner;

import mde.DepartmentStore;
import mde.MdeFactory;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Department Store</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following operations are tested:
 * <ul>
 *   <li>{@link mde.DepartmentStore#isNameNotEmpty(java.lang.String) <em>Is Name Not Empty</em>}</li>
 * </ul>
 * </p>
 * @generated
 */
public class DepartmentStoreTest extends TestCase {

	/**
	 * The fixture for this Department Store test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DepartmentStore fixture = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(DepartmentStoreTest.class);
	}

	/**
	 * Constructs a new Department Store test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DepartmentStoreTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this Department Store test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(DepartmentStore fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this Department Store test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DepartmentStore getFixture() {
		return fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(MdeFactory.eINSTANCE.createDepartmentStore());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

	/**
	 * Tests the '{@link mde.DepartmentStore#isNameNotEmpty(java.lang.String) <em>Is Name Not Empty</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mde.DepartmentStore#isNameNotEmpty(java.lang.String)
	 * @generated
	 */
	public void testIsNameNotEmpty__String() {
		// TODO: implement this operation test method
		// Ensure that you remove @generated or mark it @generated NOT
		fail();
	}

} //DepartmentStoreTest
