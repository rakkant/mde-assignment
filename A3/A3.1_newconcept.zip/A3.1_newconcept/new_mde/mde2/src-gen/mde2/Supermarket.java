/**
 */
package mde2;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Supermarket</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link mde2.Supermarket#getOpeningTime <em>Opening Time</em>}</li>
 *   <li>{@link mde2.Supermarket#getClosingTime <em>Closing Time</em>}</li>
 *   <li>{@link mde2.Supermarket#getSections <em>Sections</em>}</li>
 * </ul>
 *
 * @see mde2.Mde2Package#getSupermarket()
 * @model
 * @generated
 */
public interface Supermarket extends AbstractShop {
	/**
	 * Returns the value of the '<em><b>Opening Time</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Opening Time</em>' attribute.
	 * @see #setOpeningTime(String)
	 * @see mde2.Mde2Package#getSupermarket_OpeningTime()
	 * @model
	 * @generated
	 */
	String getOpeningTime();

	/**
	 * Sets the value of the '{@link mde2.Supermarket#getOpeningTime <em>Opening Time</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Opening Time</em>' attribute.
	 * @see #getOpeningTime()
	 * @generated
	 */
	void setOpeningTime(String value);

	/**
	 * Returns the value of the '<em><b>Closing Time</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Closing Time</em>' attribute.
	 * @see #setClosingTime(String)
	 * @see mde2.Mde2Package#getSupermarket_ClosingTime()
	 * @model
	 * @generated
	 */
	String getClosingTime();

	/**
	 * Sets the value of the '{@link mde2.Supermarket#getClosingTime <em>Closing Time</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Closing Time</em>' attribute.
	 * @see #getClosingTime()
	 * @generated
	 */
	void setClosingTime(String value);

	/**
	 * Returns the value of the '<em><b>Sections</b></em>' containment reference list.
	 * The list contents are of type {@link mde2.Section}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Sections</em>' containment reference list.
	 * @see mde2.Mde2Package#getSupermarket_Sections()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Section> getSections();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot body='ClosingTime &gt;= OpeningTime'"
	 * @generated
	 */
	Boolean isClosingTimeLaterThanOpeningTime(String closingtime, String openingTime);

} // Supermarket
