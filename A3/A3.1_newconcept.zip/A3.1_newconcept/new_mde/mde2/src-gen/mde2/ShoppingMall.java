/**
 */
package mde2;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Shopping Mall</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link mde2.ShoppingMall#getCompanyName <em>Company Name</em>}</li>
 *   <li>{@link mde2.ShoppingMall#getCeo <em>Ceo</em>}</li>
 *   <li>{@link mde2.ShoppingMall#getLocation <em>Location</em>}</li>
 *   <li>{@link mde2.ShoppingMall#getShops <em>Shops</em>}</li>
 * </ul>
 *
 * @see mde2.Mde2Package#getShoppingMall()
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='name'"
 * @generated
 */
public interface ShoppingMall extends EObject {
	/**
	 * Returns the value of the '<em><b>Company Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Company Name</em>' attribute.
	 * @see #setCompanyName(String)
	 * @see mde2.Mde2Package#getShoppingMall_CompanyName()
	 * @model
	 * @generated
	 */
	String getCompanyName();

	/**
	 * Sets the value of the '{@link mde2.ShoppingMall#getCompanyName <em>Company Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Company Name</em>' attribute.
	 * @see #getCompanyName()
	 * @generated
	 */
	void setCompanyName(String value);

	/**
	 * Returns the value of the '<em><b>Ceo</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ceo</em>' attribute.
	 * @see #setCeo(String)
	 * @see mde2.Mde2Package#getShoppingMall_Ceo()
	 * @model
	 * @generated
	 */
	String getCeo();

	/**
	 * Sets the value of the '{@link mde2.ShoppingMall#getCeo <em>Ceo</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Ceo</em>' attribute.
	 * @see #getCeo()
	 * @generated
	 */
	void setCeo(String value);

	/**
	 * Returns the value of the '<em><b>Location</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Location</em>' attribute.
	 * @see #setLocation(String)
	 * @see mde2.Mde2Package#getShoppingMall_Location()
	 * @model
	 * @generated
	 */
	String getLocation();

	/**
	 * Sets the value of the '{@link mde2.ShoppingMall#getLocation <em>Location</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Location</em>' attribute.
	 * @see #getLocation()
	 * @generated
	 */
	void setLocation(String value);

	/**
	 * Returns the value of the '<em><b>Shops</b></em>' containment reference list.
	 * The list contents are of type {@link mde2.Shop}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Shops</em>' containment reference list.
	 * @see mde2.Mde2Package#getShoppingMall_Shops()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Shop> getShops();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot body='name != null'"
	 * @generated
	 */
	Boolean isNameNotEmpty(String name);

} // ShoppingMall
