/**
 */
package mde2.impl;

import java.lang.reflect.InvocationTargetException;

import mde2.AbstractShop;
import mde2.Mde2Package;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Abstract Shop</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link mde2.impl.AbstractShopImpl#getSupervisorName <em>Supervisor Name</em>}</li>
 *   <li>{@link mde2.impl.AbstractShopImpl#getEmployeeAmount <em>Employee Amount</em>}</li>
 *   <li>{@link mde2.impl.AbstractShopImpl#getManagerAmount <em>Manager Amount</em>}</li>
 *   <li>{@link mde2.impl.AbstractShopImpl#getName <em>Name</em>}</li>
 *   <li>{@link mde2.impl.AbstractShopImpl#getFloorNumber <em>Floor Number</em>}</li>
 * </ul>
 *
 * @generated
 */
public abstract class AbstractShopImpl extends MinimalEObjectImpl.Container implements AbstractShop {
	/**
	 * The default value of the '{@link #getSupervisorName() <em>Supervisor Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSupervisorName()
	 * @generated
	 * @ordered
	 */
	protected static final String SUPERVISOR_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getSupervisorName() <em>Supervisor Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSupervisorName()
	 * @generated
	 * @ordered
	 */
	protected String supervisorName = SUPERVISOR_NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getEmployeeAmount() <em>Employee Amount</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEmployeeAmount()
	 * @generated
	 * @ordered
	 */
	protected static final int EMPLOYEE_AMOUNT_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getEmployeeAmount() <em>Employee Amount</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEmployeeAmount()
	 * @generated
	 * @ordered
	 */
	protected int employeeAmount = EMPLOYEE_AMOUNT_EDEFAULT;

	/**
	 * The default value of the '{@link #getManagerAmount() <em>Manager Amount</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getManagerAmount()
	 * @generated
	 * @ordered
	 */
	protected static final int MANAGER_AMOUNT_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getManagerAmount() <em>Manager Amount</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getManagerAmount()
	 * @generated
	 * @ordered
	 */
	protected int managerAmount = MANAGER_AMOUNT_EDEFAULT;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getFloorNumber() <em>Floor Number</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFloorNumber()
	 * @generated
	 * @ordered
	 */
	protected static final int FLOOR_NUMBER_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getFloorNumber() <em>Floor Number</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFloorNumber()
	 * @generated
	 * @ordered
	 */
	protected int floorNumber = FLOOR_NUMBER_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AbstractShopImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Mde2Package.Literals.ABSTRACT_SHOP;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getSupervisorName() {
		return supervisorName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSupervisorName(String newSupervisorName) {
		String oldSupervisorName = supervisorName;
		supervisorName = newSupervisorName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Mde2Package.ABSTRACT_SHOP__SUPERVISOR_NAME,
					oldSupervisorName, supervisorName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getEmployeeAmount() {
		return employeeAmount;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setEmployeeAmount(int newEmployeeAmount) {
		int oldEmployeeAmount = employeeAmount;
		employeeAmount = newEmployeeAmount;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Mde2Package.ABSTRACT_SHOP__EMPLOYEE_AMOUNT,
					oldEmployeeAmount, employeeAmount));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getManagerAmount() {
		return managerAmount;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setManagerAmount(int newManagerAmount) {
		int oldManagerAmount = managerAmount;
		managerAmount = newManagerAmount;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Mde2Package.ABSTRACT_SHOP__MANAGER_AMOUNT,
					oldManagerAmount, managerAmount));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Mde2Package.ABSTRACT_SHOP__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getFloorNumber() {
		return floorNumber;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setFloorNumber(int newFloorNumber) {
		int oldFloorNumber = floorNumber;
		floorNumber = newFloorNumber;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Mde2Package.ABSTRACT_SHOP__FLOOR_NUMBER,
					oldFloorNumber, floorNumber));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Boolean isFloorNumberMoreThan1(int floorNumber) {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Mde2Package.ABSTRACT_SHOP__SUPERVISOR_NAME:
			return getSupervisorName();
		case Mde2Package.ABSTRACT_SHOP__EMPLOYEE_AMOUNT:
			return getEmployeeAmount();
		case Mde2Package.ABSTRACT_SHOP__MANAGER_AMOUNT:
			return getManagerAmount();
		case Mde2Package.ABSTRACT_SHOP__NAME:
			return getName();
		case Mde2Package.ABSTRACT_SHOP__FLOOR_NUMBER:
			return getFloorNumber();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Mde2Package.ABSTRACT_SHOP__SUPERVISOR_NAME:
			setSupervisorName((String) newValue);
			return;
		case Mde2Package.ABSTRACT_SHOP__EMPLOYEE_AMOUNT:
			setEmployeeAmount((Integer) newValue);
			return;
		case Mde2Package.ABSTRACT_SHOP__MANAGER_AMOUNT:
			setManagerAmount((Integer) newValue);
			return;
		case Mde2Package.ABSTRACT_SHOP__NAME:
			setName((String) newValue);
			return;
		case Mde2Package.ABSTRACT_SHOP__FLOOR_NUMBER:
			setFloorNumber((Integer) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Mde2Package.ABSTRACT_SHOP__SUPERVISOR_NAME:
			setSupervisorName(SUPERVISOR_NAME_EDEFAULT);
			return;
		case Mde2Package.ABSTRACT_SHOP__EMPLOYEE_AMOUNT:
			setEmployeeAmount(EMPLOYEE_AMOUNT_EDEFAULT);
			return;
		case Mde2Package.ABSTRACT_SHOP__MANAGER_AMOUNT:
			setManagerAmount(MANAGER_AMOUNT_EDEFAULT);
			return;
		case Mde2Package.ABSTRACT_SHOP__NAME:
			setName(NAME_EDEFAULT);
			return;
		case Mde2Package.ABSTRACT_SHOP__FLOOR_NUMBER:
			setFloorNumber(FLOOR_NUMBER_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Mde2Package.ABSTRACT_SHOP__SUPERVISOR_NAME:
			return SUPERVISOR_NAME_EDEFAULT == null ? supervisorName != null
					: !SUPERVISOR_NAME_EDEFAULT.equals(supervisorName);
		case Mde2Package.ABSTRACT_SHOP__EMPLOYEE_AMOUNT:
			return employeeAmount != EMPLOYEE_AMOUNT_EDEFAULT;
		case Mde2Package.ABSTRACT_SHOP__MANAGER_AMOUNT:
			return managerAmount != MANAGER_AMOUNT_EDEFAULT;
		case Mde2Package.ABSTRACT_SHOP__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case Mde2Package.ABSTRACT_SHOP__FLOOR_NUMBER:
			return floorNumber != FLOOR_NUMBER_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
		case Mde2Package.ABSTRACT_SHOP___IS_FLOOR_NUMBER_MORE_THAN1__INT:
			return isFloorNumberMoreThan1((Integer) arguments.get(0));
		}
		return super.eInvoke(operationID, arguments);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (supervisorName: ");
		result.append(supervisorName);
		result.append(", employeeAmount: ");
		result.append(employeeAmount);
		result.append(", managerAmount: ");
		result.append(managerAmount);
		result.append(", name: ");
		result.append(name);
		result.append(", floorNumber: ");
		result.append(floorNumber);
		result.append(')');
		return result.toString();
	}

} //AbstractShopImpl
