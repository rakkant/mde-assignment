/**
 */
package mde2.impl;

import mde2.AbstractShop;
import mde2.ClothingStore;
import mde2.Mde2Factory;
import mde2.Mde2Package;
import mde2.Section;
import mde2.Shop;
import mde2.ShoppingMall;
import mde2.Supermarket;
import mde2.clothingType;
import mde2.sectionType;

import mde2.util.Mde2Validator;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EValidator;

import org.eclipse.emf.ecore.impl.EPackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class Mde2PackageImpl extends EPackageImpl implements Mde2Package {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass shoppingMallEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass supermarketEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass sectionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass shopEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass clothingStoreEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass abstractShopEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum sectionTypeEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum clothingTypeEEnum = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see mde2.Mde2Package#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private Mde2PackageImpl() {
		super(eNS_URI, Mde2Factory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 *
	 * <p>This method is used to initialize {@link Mde2Package#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static Mde2Package init() {
		if (isInited)
			return (Mde2Package) EPackage.Registry.INSTANCE.getEPackage(Mde2Package.eNS_URI);

		// Obtain or create and register package
		Object registeredMde2Package = EPackage.Registry.INSTANCE.get(eNS_URI);
		Mde2PackageImpl theMde2Package = registeredMde2Package instanceof Mde2PackageImpl
				? (Mde2PackageImpl) registeredMde2Package
				: new Mde2PackageImpl();

		isInited = true;

		// Create package meta-data objects
		theMde2Package.createPackageContents();

		// Initialize created meta-data
		theMde2Package.initializePackageContents();

		// Register package validator
		EValidator.Registry.INSTANCE.put(theMde2Package, new EValidator.Descriptor() {
			public EValidator getEValidator() {
				return Mde2Validator.INSTANCE;
			}
		});

		// Mark meta-data to indicate it can't be changed
		theMde2Package.freeze();

		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(Mde2Package.eNS_URI, theMde2Package);
		return theMde2Package;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getShoppingMall() {
		return shoppingMallEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getShoppingMall_CompanyName() {
		return (EAttribute) shoppingMallEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getShoppingMall_Ceo() {
		return (EAttribute) shoppingMallEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getShoppingMall_Location() {
		return (EAttribute) shoppingMallEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getShoppingMall_Shops() {
		return (EReference) shoppingMallEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getShoppingMall__IsNameNotEmpty__String() {
		return shoppingMallEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSupermarket() {
		return supermarketEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSupermarket_OpeningTime() {
		return (EAttribute) supermarketEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSupermarket_ClosingTime() {
		return (EAttribute) supermarketEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getSupermarket_Sections() {
		return (EReference) supermarketEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getSupermarket__IsClosingTimeLaterThanOpeningTime__String_String() {
		return supermarketEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSection() {
		return sectionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSection_Sections() {
		return (EAttribute) sectionEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getShop() {
		return shopEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getShop_Supermarket() {
		return (EReference) shopEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getShop_ClothingStores() {
		return (EReference) shopEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getClothingStore() {
		return clothingStoreEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getClothingStore_Type() {
		return (EAttribute) clothingStoreEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAbstractShop() {
		return abstractShopEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAbstractShop_SupervisorName() {
		return (EAttribute) abstractShopEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAbstractShop_EmployeeAmount() {
		return (EAttribute) abstractShopEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAbstractShop_ManagerAmount() {
		return (EAttribute) abstractShopEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAbstractShop_Name() {
		return (EAttribute) abstractShopEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAbstractShop_FloorNumber() {
		return (EAttribute) abstractShopEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getAbstractShop__IsFloorNumberMoreThan1__int() {
		return abstractShopEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getsectionType() {
		return sectionTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getclothingType() {
		return clothingTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Mde2Factory getMde2Factory() {
		return (Mde2Factory) getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated)
			return;
		isCreated = true;

		// Create classes and their features
		shoppingMallEClass = createEClass(SHOPPING_MALL);
		createEAttribute(shoppingMallEClass, SHOPPING_MALL__COMPANY_NAME);
		createEAttribute(shoppingMallEClass, SHOPPING_MALL__CEO);
		createEAttribute(shoppingMallEClass, SHOPPING_MALL__LOCATION);
		createEReference(shoppingMallEClass, SHOPPING_MALL__SHOPS);
		createEOperation(shoppingMallEClass, SHOPPING_MALL___IS_NAME_NOT_EMPTY__STRING);

		supermarketEClass = createEClass(SUPERMARKET);
		createEAttribute(supermarketEClass, SUPERMARKET__OPENING_TIME);
		createEAttribute(supermarketEClass, SUPERMARKET__CLOSING_TIME);
		createEReference(supermarketEClass, SUPERMARKET__SECTIONS);
		createEOperation(supermarketEClass, SUPERMARKET___IS_CLOSING_TIME_LATER_THAN_OPENING_TIME__STRING_STRING);

		sectionEClass = createEClass(SECTION);
		createEAttribute(sectionEClass, SECTION__SECTIONS);

		shopEClass = createEClass(SHOP);
		createEReference(shopEClass, SHOP__SUPERMARKET);
		createEReference(shopEClass, SHOP__CLOTHING_STORES);

		clothingStoreEClass = createEClass(CLOTHING_STORE);
		createEAttribute(clothingStoreEClass, CLOTHING_STORE__TYPE);

		abstractShopEClass = createEClass(ABSTRACT_SHOP);
		createEAttribute(abstractShopEClass, ABSTRACT_SHOP__SUPERVISOR_NAME);
		createEAttribute(abstractShopEClass, ABSTRACT_SHOP__EMPLOYEE_AMOUNT);
		createEAttribute(abstractShopEClass, ABSTRACT_SHOP__MANAGER_AMOUNT);
		createEAttribute(abstractShopEClass, ABSTRACT_SHOP__NAME);
		createEAttribute(abstractShopEClass, ABSTRACT_SHOP__FLOOR_NUMBER);
		createEOperation(abstractShopEClass, ABSTRACT_SHOP___IS_FLOOR_NUMBER_MORE_THAN1__INT);

		// Create enums
		sectionTypeEEnum = createEEnum(SECTION_TYPE);
		clothingTypeEEnum = createEEnum(CLOTHING_TYPE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized)
			return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		supermarketEClass.getESuperTypes().add(this.getAbstractShop());
		clothingStoreEClass.getESuperTypes().add(this.getAbstractShop());

		// Initialize classes, features, and operations; add parameters
		initEClass(shoppingMallEClass, ShoppingMall.class, "ShoppingMall", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getShoppingMall_CompanyName(), ecorePackage.getEString(), "companyName", null, 0, 1,
				ShoppingMall.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getShoppingMall_Ceo(), ecorePackage.getEString(), "ceo", null, 0, 1, ShoppingMall.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getShoppingMall_Location(), ecorePackage.getEString(), "location", null, 0, 1,
				ShoppingMall.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEReference(getShoppingMall_Shops(), this.getShop(), null, "shops", null, 1, -1, ShoppingMall.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		EOperation op = initEOperation(getShoppingMall__IsNameNotEmpty__String(), ecorePackage.getEBooleanObject(),
				"isNameNotEmpty", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEString(), "name", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEClass(supermarketEClass, Supermarket.class, "Supermarket", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getSupermarket_OpeningTime(), ecorePackage.getEString(), "openingTime", null, 0, 1,
				Supermarket.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getSupermarket_ClosingTime(), ecorePackage.getEString(), "closingTime", null, 0, 1,
				Supermarket.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEReference(getSupermarket_Sections(), this.getSection(), null, "sections", null, 1, -1, Supermarket.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		op = initEOperation(getSupermarket__IsClosingTimeLaterThanOpeningTime__String_String(),
				ecorePackage.getEBooleanObject(), "isClosingTimeLaterThanOpeningTime", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEString(), "closingtime", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEString(), "openingTime", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEClass(sectionEClass, Section.class, "Section", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getSection_Sections(), this.getsectionType(), "sections", null, 0, 1, Section.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(shopEClass, Shop.class, "Shop", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getShop_Supermarket(), this.getSupermarket(), null, "supermarket", null, 1, 1, Shop.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getShop_ClothingStores(), this.getClothingStore(), null, "clothingStores", null, 1, -1,
				Shop.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(clothingStoreEClass, ClothingStore.class, "ClothingStore", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getClothingStore_Type(), this.getclothingType(), "type", null, 0, 1, ClothingStore.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(abstractShopEClass, AbstractShop.class, "AbstractShop", IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getAbstractShop_SupervisorName(), ecorePackage.getEString(), "supervisorName", null, 0, 1,
				AbstractShop.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getAbstractShop_EmployeeAmount(), ecorePackage.getEInt(), "employeeAmount", null, 0, 1,
				AbstractShop.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getAbstractShop_ManagerAmount(), ecorePackage.getEInt(), "managerAmount", null, 0, 1,
				AbstractShop.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getAbstractShop_Name(), ecorePackage.getEString(), "name", null, 0, 1, AbstractShop.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAbstractShop_FloorNumber(), ecorePackage.getEInt(), "floorNumber", null, 0, 1,
				AbstractShop.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);

		op = initEOperation(getAbstractShop__IsFloorNumberMoreThan1__int(), ecorePackage.getEBooleanObject(),
				"isFloorNumberMoreThan1", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEInt(), "floorNumber", 0, 1, IS_UNIQUE, IS_ORDERED);

		// Initialize enums and add enum literals
		initEEnum(sectionTypeEEnum, sectionType.class, "sectionType");
		addEEnumLiteral(sectionTypeEEnum, sectionType.FRESH_PRODUCE);
		addEEnumLiteral(sectionTypeEEnum, sectionType.FRESH_VEGETABLES_AND_FRUITS);
		addEEnumLiteral(sectionTypeEEnum, sectionType.KITCHEN_WARE);
		addEEnumLiteral(sectionTypeEEnum, sectionType.HOUSEHOLD_CLEANERS);

		initEEnum(clothingTypeEEnum, clothingType.class, "clothingType");
		addEEnumLiteral(clothingTypeEEnum, clothingType.MEN);
		addEEnumLiteral(clothingTypeEEnum, clothingType.WOMEN);
		addEEnumLiteral(clothingTypeEEnum, clothingType.KIDS);
		addEEnumLiteral(clothingTypeEEnum, clothingType.SHOES);

		// Create resource
		createResource(eNS_URI);

		// Create annotations
		// http://www.eclipse.org/emf/2002/Ecore
		createEcoreAnnotations();
		// http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot
		createPivotAnnotations();
	}

	/**
	 * Initializes the annotations for <b>http://www.eclipse.org/emf/2002/Ecore</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createEcoreAnnotations() {
		String source = "http://www.eclipse.org/emf/2002/Ecore";
		addAnnotation(this, source,
				new String[] { "conversionDelegates", "http:///org/eclipse/emf/ecore/util/DateConversionDelegate",
						"invocationDelegates", "http://www.eclipse.org/emf/2002/Ecore/OCL", "validationDelegates",
						"http://www.eclipse.org/emf/2002/Ecore/OCL" });
		addAnnotation(shoppingMallEClass, source, new String[] { "constraints", "name" });
	}

	/**
	 * Initializes the annotations for <b>http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createPivotAnnotations() {
		String source = "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot";
		addAnnotation(getShoppingMall__IsNameNotEmpty__String(), source, new String[] { "body", "name != null" });
		addAnnotation(getSupermarket__IsClosingTimeLaterThanOpeningTime__String_String(), source,
				new String[] { "body", "ClosingTime >= OpeningTime" });
		addAnnotation(getAbstractShop__IsFloorNumberMoreThan1__int(), source,
				new String[] { "body", "floorNumber > 1" });
	}

} //Mde2PackageImpl
