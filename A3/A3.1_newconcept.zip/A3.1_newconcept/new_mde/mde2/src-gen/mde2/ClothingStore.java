/**
 */
package mde2;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Clothing Store</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link mde2.ClothingStore#getType <em>Type</em>}</li>
 * </ul>
 *
 * @see mde2.Mde2Package#getClothingStore()
 * @model
 * @generated
 */
public interface ClothingStore extends AbstractShop {
	/**
	 * Returns the value of the '<em><b>Type</b></em>' attribute.
	 * The literals are from the enumeration {@link mde2.clothingType}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' attribute.
	 * @see mde2.clothingType
	 * @see #setType(clothingType)
	 * @see mde2.Mde2Package#getClothingStore_Type()
	 * @model
	 * @generated
	 */
	clothingType getType();

	/**
	 * Sets the value of the '{@link mde2.ClothingStore#getType <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' attribute.
	 * @see mde2.clothingType
	 * @see #getType()
	 * @generated
	 */
	void setType(clothingType value);

} // ClothingStore
