/**
 */
package mde2;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Section</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link mde2.Section#getSections <em>Sections</em>}</li>
 * </ul>
 *
 * @see mde2.Mde2Package#getSection()
 * @model
 * @generated
 */
public interface Section extends EObject {
	/**
	 * Returns the value of the '<em><b>Sections</b></em>' attribute.
	 * The literals are from the enumeration {@link mde2.sectionType}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Sections</em>' attribute.
	 * @see mde2.sectionType
	 * @see #setSections(sectionType)
	 * @see mde2.Mde2Package#getSection_Sections()
	 * @model
	 * @generated
	 */
	sectionType getSections();

	/**
	 * Sets the value of the '{@link mde2.Section#getSections <em>Sections</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Sections</em>' attribute.
	 * @see mde2.sectionType
	 * @see #getSections()
	 * @generated
	 */
	void setSections(sectionType value);

} // Section
