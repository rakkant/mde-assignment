/**
 */
package mde2;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.Enumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>clothing Type</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * @see mde2.Mde2Package#getclothingType()
 * @model
 * @generated
 */
public enum clothingType implements Enumerator {
	/**
	 * The '<em><b>Men</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #MEN_VALUE
	 * @generated
	 * @ordered
	 */
	MEN(0, "men", "men"),

	/**
	 * The '<em><b>Women</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #WOMEN_VALUE
	 * @generated
	 * @ordered
	 */
	WOMEN(1, "women", "women"),

	/**
	 * The '<em><b>Kids</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #KIDS_VALUE
	 * @generated
	 * @ordered
	 */
	KIDS(2, "kids", "kids"),

	/**
	 * The '<em><b>Shoes</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #SHOES_VALUE
	 * @generated
	 * @ordered
	 */
	SHOES(3, "shoes", "shoes");

	/**
	 * The '<em><b>Men</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #MEN
	 * @model name="men"
	 * @generated
	 * @ordered
	 */
	public static final int MEN_VALUE = 0;

	/**
	 * The '<em><b>Women</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #WOMEN
	 * @model name="women"
	 * @generated
	 * @ordered
	 */
	public static final int WOMEN_VALUE = 1;

	/**
	 * The '<em><b>Kids</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #KIDS
	 * @model name="kids"
	 * @generated
	 * @ordered
	 */
	public static final int KIDS_VALUE = 2;

	/**
	 * The '<em><b>Shoes</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #SHOES
	 * @model name="shoes"
	 * @generated
	 * @ordered
	 */
	public static final int SHOES_VALUE = 3;

	/**
	 * An array of all the '<em><b>clothing Type</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final clothingType[] VALUES_ARRAY = new clothingType[] { MEN, WOMEN, KIDS, SHOES, };

	/**
	 * A public read-only list of all the '<em><b>clothing Type</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final List<clothingType> VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	/**
	 * Returns the '<em><b>clothing Type</b></em>' literal with the specified literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param literal the literal.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static clothingType get(String literal) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			clothingType result = VALUES_ARRAY[i];
			if (result.toString().equals(literal)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>clothing Type</b></em>' literal with the specified name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param name the name.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static clothingType getByName(String name) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			clothingType result = VALUES_ARRAY[i];
			if (result.getName().equals(name)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>clothing Type</b></em>' literal with the specified integer value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the integer value.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static clothingType get(int value) {
		switch (value) {
		case MEN_VALUE:
			return MEN;
		case WOMEN_VALUE:
			return WOMEN;
		case KIDS_VALUE:
			return KIDS;
		case SHOES_VALUE:
			return SHOES;
		}
		return null;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final int value;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String name;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String literal;

	/**
	 * Only this class can construct instances.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private clothingType(int value, String name, String literal) {
		this.value = value;
		this.name = name;
		this.literal = literal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getValue() {
		return value;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLiteral() {
		return literal;
	}

	/**
	 * Returns the literal value of the enumerator, which is its string representation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		return literal;
	}

} //clothingType
