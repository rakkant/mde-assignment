/**
 */
package mde;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Department</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link mde.Department#getClothingStores <em>Clothing Stores</em>}</li>
 *   <li>{@link mde.Department#getCinema <em>Cinema</em>}</li>
 *   <li>{@link mde.Department#getFoodcourt <em>Foodcourt</em>}</li>
 * </ul>
 *
 * @see mde.MdePackage#getDepartment()
 * @model
 * @generated
 */
public interface Department extends EObject {
	/**
	 * Returns the value of the '<em><b>Clothing Stores</b></em>' containment reference list.
	 * The list contents are of type {@link mde.ClothingStore}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Clothing Stores</em>' containment reference list.
	 * @see mde.MdePackage#getDepartment_ClothingStores()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<ClothingStore> getClothingStores();

	/**
	 * Returns the value of the '<em><b>Cinema</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Cinema</em>' containment reference.
	 * @see #setCinema(Cinema)
	 * @see mde.MdePackage#getDepartment_Cinema()
	 * @model containment="true" required="true"
	 * @generated
	 */
	Cinema getCinema();

	/**
	 * Sets the value of the '{@link mde.Department#getCinema <em>Cinema</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Cinema</em>' containment reference.
	 * @see #getCinema()
	 * @generated
	 */
	void setCinema(Cinema value);

	/**
	 * Returns the value of the '<em><b>Foodcourt</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Foodcourt</em>' containment reference.
	 * @see #setFoodcourt(Foodcourt)
	 * @see mde.MdePackage#getDepartment_Foodcourt()
	 * @model containment="true" required="true"
	 * @generated
	 */
	Foodcourt getFoodcourt();

	/**
	 * Sets the value of the '{@link mde.Department#getFoodcourt <em>Foodcourt</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Foodcourt</em>' containment reference.
	 * @see #getFoodcourt()
	 * @generated
	 */
	void setFoodcourt(Foodcourt value);

} // Department
