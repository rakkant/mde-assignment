/**
 */
package mde;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>restaurant</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link mde.restaurant#getType <em>Type</em>}</li>
 * </ul>
 *
 * @see mde.MdePackage#getrestaurant()
 * @model
 * @generated
 */
public interface restaurant extends EObject {
	/**
	 * Returns the value of the '<em><b>Type</b></em>' attribute.
	 * The literals are from the enumeration {@link mde.foodType}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' attribute.
	 * @see mde.foodType
	 * @see #setType(foodType)
	 * @see mde.MdePackage#getrestaurant_Type()
	 * @model
	 * @generated
	 */
	foodType getType();

	/**
	 * Sets the value of the '{@link mde.restaurant#getType <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' attribute.
	 * @see mde.foodType
	 * @see #getType()
	 * @generated
	 */
	void setType(foodType value);

} // restaurant
