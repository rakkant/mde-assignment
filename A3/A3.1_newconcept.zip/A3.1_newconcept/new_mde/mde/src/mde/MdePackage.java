/**
 */
package mde;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see mde.MdeFactory
 * @model kind="package"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore conversionDelegates='http:///org/eclipse/emf/ecore/util/DateConversionDelegate' invocationDelegates='http://www.eclipse.org/emf/2002/Ecore/OCL' validationDelegates='http://www.eclipse.org/emf/2002/Ecore/OCL'"
 * @generated
 */
public interface MdePackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "mde";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.example.org/mde";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "mde";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	MdePackage eINSTANCE = mde.impl.MdePackageImpl.init();

	/**
	 * The meta object id for the '{@link mde.impl.DepartmentStoreImpl <em>Department Store</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mde.impl.DepartmentStoreImpl
	 * @see mde.impl.MdePackageImpl#getDepartmentStore()
	 * @generated
	 */
	int DEPARTMENT_STORE = 0;

	/**
	 * The feature id for the '<em><b>Owner</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPARTMENT_STORE__OWNER = 0;

	/**
	 * The feature id for the '<em><b>Location</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPARTMENT_STORE__LOCATION = 1;

	/**
	 * The feature id for the '<em><b>Departments</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPARTMENT_STORE__DEPARTMENTS = 2;

	/**
	 * The feature id for the '<em><b>Total Departments</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPARTMENT_STORE__TOTAL_DEPARTMENTS = 3;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPARTMENT_STORE__NAME = 4;

	/**
	 * The number of structural features of the '<em>Department Store</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPARTMENT_STORE_FEATURE_COUNT = 5;

	/**
	 * The operation id for the '<em>Is Name Not Empty</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPARTMENT_STORE___IS_NAME_NOT_EMPTY__STRING = 0;

	/**
	 * The number of operations of the '<em>Department Store</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPARTMENT_STORE_OPERATION_COUNT = 1;

	/**
	 * The meta object id for the '{@link mde.impl.DepartmentImpl <em>Department</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mde.impl.DepartmentImpl
	 * @see mde.impl.MdePackageImpl#getDepartment()
	 * @generated
	 */
	int DEPARTMENT = 1;

	/**
	 * The feature id for the '<em><b>Clothing Stores</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPARTMENT__CLOTHING_STORES = 0;

	/**
	 * The feature id for the '<em><b>Cinema</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPARTMENT__CINEMA = 1;

	/**
	 * The feature id for the '<em><b>Foodcourt</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPARTMENT__FOODCOURT = 2;

	/**
	 * The number of structural features of the '<em>Department</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPARTMENT_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Department</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPARTMENT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link mde.impl.AbstractDepartmentImpl <em>Abstract Department</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mde.impl.AbstractDepartmentImpl
	 * @see mde.impl.MdePackageImpl#getAbstractDepartment()
	 * @generated
	 */
	int ABSTRACT_DEPARTMENT = 6;

	/**
	 * The feature id for the '<em><b>Manager Amount</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_DEPARTMENT__MANAGER_AMOUNT = 0;

	/**
	 * The feature id for the '<em><b>Employee Amount</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_DEPARTMENT__EMPLOYEE_AMOUNT = 1;

	/**
	 * The feature id for the '<em><b>Capacity</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_DEPARTMENT__CAPACITY = 2;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_DEPARTMENT__NAME = 3;

	/**
	 * The number of structural features of the '<em>Abstract Department</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_DEPARTMENT_FEATURE_COUNT = 4;

	/**
	 * The operation id for the '<em>Is Manager Amount Less Than Employee Amount</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_DEPARTMENT___IS_MANAGER_AMOUNT_LESS_THAN_EMPLOYEE_AMOUNT__INT_INT = 0;

	/**
	 * The operation id for the '<em>Is Capacity Greater Than Total Departments Multiply By20</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_DEPARTMENT___IS_CAPACITY_GREATER_THAN_TOTAL_DEPARTMENTS_MULTIPLY_BY20__INT_INT = 1;

	/**
	 * The number of operations of the '<em>Abstract Department</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_DEPARTMENT_OPERATION_COUNT = 2;

	/**
	 * The meta object id for the '{@link mde.impl.FoodcourtImpl <em>Foodcourt</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mde.impl.FoodcourtImpl
	 * @see mde.impl.MdePackageImpl#getFoodcourt()
	 * @generated
	 */
	int FOODCOURT = 2;

	/**
	 * The feature id for the '<em><b>Manager Amount</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FOODCOURT__MANAGER_AMOUNT = ABSTRACT_DEPARTMENT__MANAGER_AMOUNT;

	/**
	 * The feature id for the '<em><b>Employee Amount</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FOODCOURT__EMPLOYEE_AMOUNT = ABSTRACT_DEPARTMENT__EMPLOYEE_AMOUNT;

	/**
	 * The feature id for the '<em><b>Capacity</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FOODCOURT__CAPACITY = ABSTRACT_DEPARTMENT__CAPACITY;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FOODCOURT__NAME = ABSTRACT_DEPARTMENT__NAME;

	/**
	 * The feature id for the '<em><b>Floor</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FOODCOURT__FLOOR = ABSTRACT_DEPARTMENT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Restaurants</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FOODCOURT__RESTAURANTS = ABSTRACT_DEPARTMENT_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Foodcourt</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FOODCOURT_FEATURE_COUNT = ABSTRACT_DEPARTMENT_FEATURE_COUNT + 2;

	/**
	 * The operation id for the '<em>Is Manager Amount Less Than Employee Amount</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FOODCOURT___IS_MANAGER_AMOUNT_LESS_THAN_EMPLOYEE_AMOUNT__INT_INT = ABSTRACT_DEPARTMENT___IS_MANAGER_AMOUNT_LESS_THAN_EMPLOYEE_AMOUNT__INT_INT;

	/**
	 * The operation id for the '<em>Is Capacity Greater Than Total Departments Multiply By20</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FOODCOURT___IS_CAPACITY_GREATER_THAN_TOTAL_DEPARTMENTS_MULTIPLY_BY20__INT_INT = ABSTRACT_DEPARTMENT___IS_CAPACITY_GREATER_THAN_TOTAL_DEPARTMENTS_MULTIPLY_BY20__INT_INT;

	/**
	 * The number of operations of the '<em>Foodcourt</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FOODCOURT_OPERATION_COUNT = ABSTRACT_DEPARTMENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link mde.impl.ClothingStoreImpl <em>Clothing Store</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mde.impl.ClothingStoreImpl
	 * @see mde.impl.MdePackageImpl#getClothingStore()
	 * @generated
	 */
	int CLOTHING_STORE = 3;

	/**
	 * The feature id for the '<em><b>Manager Amount</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOTHING_STORE__MANAGER_AMOUNT = ABSTRACT_DEPARTMENT__MANAGER_AMOUNT;

	/**
	 * The feature id for the '<em><b>Employee Amount</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOTHING_STORE__EMPLOYEE_AMOUNT = ABSTRACT_DEPARTMENT__EMPLOYEE_AMOUNT;

	/**
	 * The feature id for the '<em><b>Capacity</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOTHING_STORE__CAPACITY = ABSTRACT_DEPARTMENT__CAPACITY;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOTHING_STORE__NAME = ABSTRACT_DEPARTMENT__NAME;

	/**
	 * The feature id for the '<em><b>Floor</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOTHING_STORE__FLOOR = ABSTRACT_DEPARTMENT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOTHING_STORE__TYPE = ABSTRACT_DEPARTMENT_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Clothing Store</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOTHING_STORE_FEATURE_COUNT = ABSTRACT_DEPARTMENT_FEATURE_COUNT + 2;

	/**
	 * The operation id for the '<em>Is Manager Amount Less Than Employee Amount</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOTHING_STORE___IS_MANAGER_AMOUNT_LESS_THAN_EMPLOYEE_AMOUNT__INT_INT = ABSTRACT_DEPARTMENT___IS_MANAGER_AMOUNT_LESS_THAN_EMPLOYEE_AMOUNT__INT_INT;

	/**
	 * The operation id for the '<em>Is Capacity Greater Than Total Departments Multiply By20</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOTHING_STORE___IS_CAPACITY_GREATER_THAN_TOTAL_DEPARTMENTS_MULTIPLY_BY20__INT_INT = ABSTRACT_DEPARTMENT___IS_CAPACITY_GREATER_THAN_TOTAL_DEPARTMENTS_MULTIPLY_BY20__INT_INT;

	/**
	 * The number of operations of the '<em>Clothing Store</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOTHING_STORE_OPERATION_COUNT = ABSTRACT_DEPARTMENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link mde.impl.CinemaImpl <em>Cinema</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mde.impl.CinemaImpl
	 * @see mde.impl.MdePackageImpl#getCinema()
	 * @generated
	 */
	int CINEMA = 4;

	/**
	 * The feature id for the '<em><b>Manager Amount</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CINEMA__MANAGER_AMOUNT = ABSTRACT_DEPARTMENT__MANAGER_AMOUNT;

	/**
	 * The feature id for the '<em><b>Employee Amount</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CINEMA__EMPLOYEE_AMOUNT = ABSTRACT_DEPARTMENT__EMPLOYEE_AMOUNT;

	/**
	 * The feature id for the '<em><b>Capacity</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CINEMA__CAPACITY = ABSTRACT_DEPARTMENT__CAPACITY;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CINEMA__NAME = ABSTRACT_DEPARTMENT__NAME;

	/**
	 * The feature id for the '<em><b>Floor</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CINEMA__FLOOR = ABSTRACT_DEPARTMENT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Theater Amount</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CINEMA__THEATER_AMOUNT = ABSTRACT_DEPARTMENT_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Cinema</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CINEMA_FEATURE_COUNT = ABSTRACT_DEPARTMENT_FEATURE_COUNT + 2;

	/**
	 * The operation id for the '<em>Is Manager Amount Less Than Employee Amount</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CINEMA___IS_MANAGER_AMOUNT_LESS_THAN_EMPLOYEE_AMOUNT__INT_INT = ABSTRACT_DEPARTMENT___IS_MANAGER_AMOUNT_LESS_THAN_EMPLOYEE_AMOUNT__INT_INT;

	/**
	 * The operation id for the '<em>Is Capacity Greater Than Total Departments Multiply By20</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CINEMA___IS_CAPACITY_GREATER_THAN_TOTAL_DEPARTMENTS_MULTIPLY_BY20__INT_INT = ABSTRACT_DEPARTMENT___IS_CAPACITY_GREATER_THAN_TOTAL_DEPARTMENTS_MULTIPLY_BY20__INT_INT;

	/**
	 * The number of operations of the '<em>Cinema</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CINEMA_OPERATION_COUNT = ABSTRACT_DEPARTMENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link mde.impl.restaurantImpl <em>restaurant</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mde.impl.restaurantImpl
	 * @see mde.impl.MdePackageImpl#getrestaurant()
	 * @generated
	 */
	int RESTAURANT = 5;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RESTAURANT__TYPE = 0;

	/**
	 * The number of structural features of the '<em>restaurant</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RESTAURANT_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>restaurant</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RESTAURANT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link mde.foodType <em>food Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mde.foodType
	 * @see mde.impl.MdePackageImpl#getfoodType()
	 * @generated
	 */
	int FOOD_TYPE = 7;

	/**
	 * The meta object id for the '{@link mde.clothingType <em>clothing Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mde.clothingType
	 * @see mde.impl.MdePackageImpl#getclothingType()
	 * @generated
	 */
	int CLOTHING_TYPE = 8;


	/**
	 * Returns the meta object for class '{@link mde.DepartmentStore <em>Department Store</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Department Store</em>'.
	 * @see mde.DepartmentStore
	 * @generated
	 */
	EClass getDepartmentStore();

	/**
	 * Returns the meta object for the attribute '{@link mde.DepartmentStore#getOwner <em>Owner</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Owner</em>'.
	 * @see mde.DepartmentStore#getOwner()
	 * @see #getDepartmentStore()
	 * @generated
	 */
	EAttribute getDepartmentStore_Owner();

	/**
	 * Returns the meta object for the attribute '{@link mde.DepartmentStore#getLocation <em>Location</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Location</em>'.
	 * @see mde.DepartmentStore#getLocation()
	 * @see #getDepartmentStore()
	 * @generated
	 */
	EAttribute getDepartmentStore_Location();

	/**
	 * Returns the meta object for the containment reference list '{@link mde.DepartmentStore#getDepartments <em>Departments</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Departments</em>'.
	 * @see mde.DepartmentStore#getDepartments()
	 * @see #getDepartmentStore()
	 * @generated
	 */
	EReference getDepartmentStore_Departments();

	/**
	 * Returns the meta object for the attribute '{@link mde.DepartmentStore#getTotalDepartments <em>Total Departments</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Total Departments</em>'.
	 * @see mde.DepartmentStore#getTotalDepartments()
	 * @see #getDepartmentStore()
	 * @generated
	 */
	EAttribute getDepartmentStore_TotalDepartments();

	/**
	 * Returns the meta object for the attribute '{@link mde.DepartmentStore#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see mde.DepartmentStore#getName()
	 * @see #getDepartmentStore()
	 * @generated
	 */
	EAttribute getDepartmentStore_Name();

	/**
	 * Returns the meta object for the '{@link mde.DepartmentStore#isNameNotEmpty(java.lang.String) <em>Is Name Not Empty</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Name Not Empty</em>' operation.
	 * @see mde.DepartmentStore#isNameNotEmpty(java.lang.String)
	 * @generated
	 */
	EOperation getDepartmentStore__IsNameNotEmpty__String();

	/**
	 * Returns the meta object for class '{@link mde.Department <em>Department</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Department</em>'.
	 * @see mde.Department
	 * @generated
	 */
	EClass getDepartment();

	/**
	 * Returns the meta object for the containment reference list '{@link mde.Department#getClothingStores <em>Clothing Stores</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Clothing Stores</em>'.
	 * @see mde.Department#getClothingStores()
	 * @see #getDepartment()
	 * @generated
	 */
	EReference getDepartment_ClothingStores();

	/**
	 * Returns the meta object for the containment reference '{@link mde.Department#getCinema <em>Cinema</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Cinema</em>'.
	 * @see mde.Department#getCinema()
	 * @see #getDepartment()
	 * @generated
	 */
	EReference getDepartment_Cinema();

	/**
	 * Returns the meta object for the containment reference '{@link mde.Department#getFoodcourt <em>Foodcourt</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Foodcourt</em>'.
	 * @see mde.Department#getFoodcourt()
	 * @see #getDepartment()
	 * @generated
	 */
	EReference getDepartment_Foodcourt();

	/**
	 * Returns the meta object for class '{@link mde.Foodcourt <em>Foodcourt</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Foodcourt</em>'.
	 * @see mde.Foodcourt
	 * @generated
	 */
	EClass getFoodcourt();

	/**
	 * Returns the meta object for the attribute '{@link mde.Foodcourt#getFloor <em>Floor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Floor</em>'.
	 * @see mde.Foodcourt#getFloor()
	 * @see #getFoodcourt()
	 * @generated
	 */
	EAttribute getFoodcourt_Floor();

	/**
	 * Returns the meta object for the containment reference list '{@link mde.Foodcourt#getRestaurants <em>Restaurants</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Restaurants</em>'.
	 * @see mde.Foodcourt#getRestaurants()
	 * @see #getFoodcourt()
	 * @generated
	 */
	EReference getFoodcourt_Restaurants();

	/**
	 * Returns the meta object for class '{@link mde.ClothingStore <em>Clothing Store</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Clothing Store</em>'.
	 * @see mde.ClothingStore
	 * @generated
	 */
	EClass getClothingStore();

	/**
	 * Returns the meta object for the attribute '{@link mde.ClothingStore#getFloor <em>Floor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Floor</em>'.
	 * @see mde.ClothingStore#getFloor()
	 * @see #getClothingStore()
	 * @generated
	 */
	EAttribute getClothingStore_Floor();

	/**
	 * Returns the meta object for the attribute '{@link mde.ClothingStore#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see mde.ClothingStore#getType()
	 * @see #getClothingStore()
	 * @generated
	 */
	EAttribute getClothingStore_Type();

	/**
	 * Returns the meta object for class '{@link mde.Cinema <em>Cinema</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Cinema</em>'.
	 * @see mde.Cinema
	 * @generated
	 */
	EClass getCinema();

	/**
	 * Returns the meta object for the attribute '{@link mde.Cinema#getFloor <em>Floor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Floor</em>'.
	 * @see mde.Cinema#getFloor()
	 * @see #getCinema()
	 * @generated
	 */
	EAttribute getCinema_Floor();

	/**
	 * Returns the meta object for the attribute '{@link mde.Cinema#getTheaterAmount <em>Theater Amount</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Theater Amount</em>'.
	 * @see mde.Cinema#getTheaterAmount()
	 * @see #getCinema()
	 * @generated
	 */
	EAttribute getCinema_TheaterAmount();

	/**
	 * Returns the meta object for class '{@link mde.restaurant <em>restaurant</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>restaurant</em>'.
	 * @see mde.restaurant
	 * @generated
	 */
	EClass getrestaurant();

	/**
	 * Returns the meta object for the attribute '{@link mde.restaurant#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see mde.restaurant#getType()
	 * @see #getrestaurant()
	 * @generated
	 */
	EAttribute getrestaurant_Type();

	/**
	 * Returns the meta object for class '{@link mde.AbstractDepartment <em>Abstract Department</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Abstract Department</em>'.
	 * @see mde.AbstractDepartment
	 * @generated
	 */
	EClass getAbstractDepartment();

	/**
	 * Returns the meta object for the attribute '{@link mde.AbstractDepartment#getManagerAmount <em>Manager Amount</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Manager Amount</em>'.
	 * @see mde.AbstractDepartment#getManagerAmount()
	 * @see #getAbstractDepartment()
	 * @generated
	 */
	EAttribute getAbstractDepartment_ManagerAmount();

	/**
	 * Returns the meta object for the attribute '{@link mde.AbstractDepartment#getEmployeeAmount <em>Employee Amount</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Employee Amount</em>'.
	 * @see mde.AbstractDepartment#getEmployeeAmount()
	 * @see #getAbstractDepartment()
	 * @generated
	 */
	EAttribute getAbstractDepartment_EmployeeAmount();

	/**
	 * Returns the meta object for the attribute '{@link mde.AbstractDepartment#getCapacity <em>Capacity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Capacity</em>'.
	 * @see mde.AbstractDepartment#getCapacity()
	 * @see #getAbstractDepartment()
	 * @generated
	 */
	EAttribute getAbstractDepartment_Capacity();

	/**
	 * Returns the meta object for the attribute '{@link mde.AbstractDepartment#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see mde.AbstractDepartment#getName()
	 * @see #getAbstractDepartment()
	 * @generated
	 */
	EAttribute getAbstractDepartment_Name();

	/**
	 * Returns the meta object for the '{@link mde.AbstractDepartment#isManagerAmountLessThanEmployeeAmount(int, int) <em>Is Manager Amount Less Than Employee Amount</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Manager Amount Less Than Employee Amount</em>' operation.
	 * @see mde.AbstractDepartment#isManagerAmountLessThanEmployeeAmount(int, int)
	 * @generated
	 */
	EOperation getAbstractDepartment__IsManagerAmountLessThanEmployeeAmount__int_int();

	/**
	 * Returns the meta object for the '{@link mde.AbstractDepartment#isCapacityGreaterThanTotalDepartmentsMultiplyBy20(int, int) <em>Is Capacity Greater Than Total Departments Multiply By20</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Capacity Greater Than Total Departments Multiply By20</em>' operation.
	 * @see mde.AbstractDepartment#isCapacityGreaterThanTotalDepartmentsMultiplyBy20(int, int)
	 * @generated
	 */
	EOperation getAbstractDepartment__IsCapacityGreaterThanTotalDepartmentsMultiplyBy20__int_int();

	/**
	 * Returns the meta object for enum '{@link mde.foodType <em>food Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>food Type</em>'.
	 * @see mde.foodType
	 * @generated
	 */
	EEnum getfoodType();

	/**
	 * Returns the meta object for enum '{@link mde.clothingType <em>clothing Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>clothing Type</em>'.
	 * @see mde.clothingType
	 * @generated
	 */
	EEnum getclothingType();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	MdeFactory getMdeFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link mde.impl.DepartmentStoreImpl <em>Department Store</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mde.impl.DepartmentStoreImpl
		 * @see mde.impl.MdePackageImpl#getDepartmentStore()
		 * @generated
		 */
		EClass DEPARTMENT_STORE = eINSTANCE.getDepartmentStore();

		/**
		 * The meta object literal for the '<em><b>Owner</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DEPARTMENT_STORE__OWNER = eINSTANCE.getDepartmentStore_Owner();

		/**
		 * The meta object literal for the '<em><b>Location</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DEPARTMENT_STORE__LOCATION = eINSTANCE.getDepartmentStore_Location();

		/**
		 * The meta object literal for the '<em><b>Departments</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DEPARTMENT_STORE__DEPARTMENTS = eINSTANCE.getDepartmentStore_Departments();

		/**
		 * The meta object literal for the '<em><b>Total Departments</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DEPARTMENT_STORE__TOTAL_DEPARTMENTS = eINSTANCE.getDepartmentStore_TotalDepartments();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DEPARTMENT_STORE__NAME = eINSTANCE.getDepartmentStore_Name();

		/**
		 * The meta object literal for the '<em><b>Is Name Not Empty</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation DEPARTMENT_STORE___IS_NAME_NOT_EMPTY__STRING = eINSTANCE.getDepartmentStore__IsNameNotEmpty__String();

		/**
		 * The meta object literal for the '{@link mde.impl.DepartmentImpl <em>Department</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mde.impl.DepartmentImpl
		 * @see mde.impl.MdePackageImpl#getDepartment()
		 * @generated
		 */
		EClass DEPARTMENT = eINSTANCE.getDepartment();

		/**
		 * The meta object literal for the '<em><b>Clothing Stores</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DEPARTMENT__CLOTHING_STORES = eINSTANCE.getDepartment_ClothingStores();

		/**
		 * The meta object literal for the '<em><b>Cinema</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DEPARTMENT__CINEMA = eINSTANCE.getDepartment_Cinema();

		/**
		 * The meta object literal for the '<em><b>Foodcourt</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DEPARTMENT__FOODCOURT = eINSTANCE.getDepartment_Foodcourt();

		/**
		 * The meta object literal for the '{@link mde.impl.FoodcourtImpl <em>Foodcourt</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mde.impl.FoodcourtImpl
		 * @see mde.impl.MdePackageImpl#getFoodcourt()
		 * @generated
		 */
		EClass FOODCOURT = eINSTANCE.getFoodcourt();

		/**
		 * The meta object literal for the '<em><b>Floor</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FOODCOURT__FLOOR = eINSTANCE.getFoodcourt_Floor();

		/**
		 * The meta object literal for the '<em><b>Restaurants</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FOODCOURT__RESTAURANTS = eINSTANCE.getFoodcourt_Restaurants();

		/**
		 * The meta object literal for the '{@link mde.impl.ClothingStoreImpl <em>Clothing Store</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mde.impl.ClothingStoreImpl
		 * @see mde.impl.MdePackageImpl#getClothingStore()
		 * @generated
		 */
		EClass CLOTHING_STORE = eINSTANCE.getClothingStore();

		/**
		 * The meta object literal for the '<em><b>Floor</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CLOTHING_STORE__FLOOR = eINSTANCE.getClothingStore_Floor();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CLOTHING_STORE__TYPE = eINSTANCE.getClothingStore_Type();

		/**
		 * The meta object literal for the '{@link mde.impl.CinemaImpl <em>Cinema</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mde.impl.CinemaImpl
		 * @see mde.impl.MdePackageImpl#getCinema()
		 * @generated
		 */
		EClass CINEMA = eINSTANCE.getCinema();

		/**
		 * The meta object literal for the '<em><b>Floor</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CINEMA__FLOOR = eINSTANCE.getCinema_Floor();

		/**
		 * The meta object literal for the '<em><b>Theater Amount</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CINEMA__THEATER_AMOUNT = eINSTANCE.getCinema_TheaterAmount();

		/**
		 * The meta object literal for the '{@link mde.impl.restaurantImpl <em>restaurant</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mde.impl.restaurantImpl
		 * @see mde.impl.MdePackageImpl#getrestaurant()
		 * @generated
		 */
		EClass RESTAURANT = eINSTANCE.getrestaurant();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute RESTAURANT__TYPE = eINSTANCE.getrestaurant_Type();

		/**
		 * The meta object literal for the '{@link mde.impl.AbstractDepartmentImpl <em>Abstract Department</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mde.impl.AbstractDepartmentImpl
		 * @see mde.impl.MdePackageImpl#getAbstractDepartment()
		 * @generated
		 */
		EClass ABSTRACT_DEPARTMENT = eINSTANCE.getAbstractDepartment();

		/**
		 * The meta object literal for the '<em><b>Manager Amount</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ABSTRACT_DEPARTMENT__MANAGER_AMOUNT = eINSTANCE.getAbstractDepartment_ManagerAmount();

		/**
		 * The meta object literal for the '<em><b>Employee Amount</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ABSTRACT_DEPARTMENT__EMPLOYEE_AMOUNT = eINSTANCE.getAbstractDepartment_EmployeeAmount();

		/**
		 * The meta object literal for the '<em><b>Capacity</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ABSTRACT_DEPARTMENT__CAPACITY = eINSTANCE.getAbstractDepartment_Capacity();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ABSTRACT_DEPARTMENT__NAME = eINSTANCE.getAbstractDepartment_Name();

		/**
		 * The meta object literal for the '<em><b>Is Manager Amount Less Than Employee Amount</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ABSTRACT_DEPARTMENT___IS_MANAGER_AMOUNT_LESS_THAN_EMPLOYEE_AMOUNT__INT_INT = eINSTANCE.getAbstractDepartment__IsManagerAmountLessThanEmployeeAmount__int_int();

		/**
		 * The meta object literal for the '<em><b>Is Capacity Greater Than Total Departments Multiply By20</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ABSTRACT_DEPARTMENT___IS_CAPACITY_GREATER_THAN_TOTAL_DEPARTMENTS_MULTIPLY_BY20__INT_INT = eINSTANCE.getAbstractDepartment__IsCapacityGreaterThanTotalDepartmentsMultiplyBy20__int_int();

		/**
		 * The meta object literal for the '{@link mde.foodType <em>food Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mde.foodType
		 * @see mde.impl.MdePackageImpl#getfoodType()
		 * @generated
		 */
		EEnum FOOD_TYPE = eINSTANCE.getfoodType();

		/**
		 * The meta object literal for the '{@link mde.clothingType <em>clothing Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mde.clothingType
		 * @see mde.impl.MdePackageImpl#getclothingType()
		 * @generated
		 */
		EEnum CLOTHING_TYPE = eINSTANCE.getclothingType();

	}

} //MdePackage
