/**
 */
package mde;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.Enumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>food Type</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * @see mde.MdePackage#getfoodType()
 * @model
 * @generated
 */
public enum foodType implements Enumerator {
	/**
	 * The '<em><b>Japanese</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #JAPANESE_VALUE
	 * @generated
	 * @ordered
	 */
	JAPANESE(0, "japanese", "japanese"),

	/**
	 * The '<em><b>Fastfood</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #FASTFOOD_VALUE
	 * @generated
	 * @ordered
	 */
	FASTFOOD(1, "fastfood", "fastfood"),

	/**
	 * The '<em><b>Italian</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #ITALIAN_VALUE
	 * @generated
	 * @ordered
	 */
	ITALIAN(2, "italian", "italian"),

	/**
	 * The '<em><b>Cafe</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #CAFE_VALUE
	 * @generated
	 * @ordered
	 */
	CAFE(3, "cafe", "cafe");

	/**
	 * The '<em><b>Japanese</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #JAPANESE
	 * @model name="japanese"
	 * @generated
	 * @ordered
	 */
	public static final int JAPANESE_VALUE = 0;

	/**
	 * The '<em><b>Fastfood</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #FASTFOOD
	 * @model name="fastfood"
	 * @generated
	 * @ordered
	 */
	public static final int FASTFOOD_VALUE = 1;

	/**
	 * The '<em><b>Italian</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #ITALIAN
	 * @model name="italian"
	 * @generated
	 * @ordered
	 */
	public static final int ITALIAN_VALUE = 2;

	/**
	 * The '<em><b>Cafe</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #CAFE
	 * @model name="cafe"
	 * @generated
	 * @ordered
	 */
	public static final int CAFE_VALUE = 3;

	/**
	 * An array of all the '<em><b>food Type</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final foodType[] VALUES_ARRAY =
		new foodType[] {
			JAPANESE,
			FASTFOOD,
			ITALIAN,
			CAFE,
		};

	/**
	 * A public read-only list of all the '<em><b>food Type</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final List<foodType> VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	/**
	 * Returns the '<em><b>food Type</b></em>' literal with the specified literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param literal the literal.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static foodType get(String literal) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			foodType result = VALUES_ARRAY[i];
			if (result.toString().equals(literal)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>food Type</b></em>' literal with the specified name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param name the name.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static foodType getByName(String name) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			foodType result = VALUES_ARRAY[i];
			if (result.getName().equals(name)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>food Type</b></em>' literal with the specified integer value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the integer value.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static foodType get(int value) {
		switch (value) {
			case JAPANESE_VALUE: return JAPANESE;
			case FASTFOOD_VALUE: return FASTFOOD;
			case ITALIAN_VALUE: return ITALIAN;
			case CAFE_VALUE: return CAFE;
		}
		return null;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final int value;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String name;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String literal;

	/**
	 * Only this class can construct instances.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private foodType(int value, String name, String literal) {
		this.value = value;
		this.name = name;
		this.literal = literal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getValue() {
	  return value;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
	  return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLiteral() {
	  return literal;
	}

	/**
	 * Returns the literal value of the enumerator, which is its string representation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		return literal;
	}
	
} //foodType
