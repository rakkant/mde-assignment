/**
 */
package mde;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Clothing Store</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link mde.ClothingStore#getFloor <em>Floor</em>}</li>
 *   <li>{@link mde.ClothingStore#getType <em>Type</em>}</li>
 * </ul>
 *
 * @see mde.MdePackage#getClothingStore()
 * @model
 * @generated
 */
public interface ClothingStore extends AbstractDepartment {
	/**
	 * Returns the value of the '<em><b>Floor</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Floor</em>' attribute.
	 * @see #setFloor(int)
	 * @see mde.MdePackage#getClothingStore_Floor()
	 * @model
	 * @generated
	 */
	int getFloor();

	/**
	 * Sets the value of the '{@link mde.ClothingStore#getFloor <em>Floor</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Floor</em>' attribute.
	 * @see #getFloor()
	 * @generated
	 */
	void setFloor(int value);

	/**
	 * Returns the value of the '<em><b>Type</b></em>' attribute.
	 * The literals are from the enumeration {@link mde.clothingType}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' attribute.
	 * @see mde.clothingType
	 * @see #setType(clothingType)
	 * @see mde.MdePackage#getClothingStore_Type()
	 * @model
	 * @generated
	 */
	clothingType getType();

	/**
	 * Sets the value of the '{@link mde.ClothingStore#getType <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' attribute.
	 * @see mde.clothingType
	 * @see #getType()
	 * @generated
	 */
	void setType(clothingType value);

} // ClothingStore
