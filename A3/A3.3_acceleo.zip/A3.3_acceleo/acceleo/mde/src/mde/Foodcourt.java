/**
 */
package mde;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Foodcourt</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link mde.Foodcourt#getFloor <em>Floor</em>}</li>
 *   <li>{@link mde.Foodcourt#getRestaurants <em>Restaurants</em>}</li>
 * </ul>
 *
 * @see mde.MdePackage#getFoodcourt()
 * @model
 * @generated
 */
public interface Foodcourt extends AbstractDepartment {
	/**
	 * Returns the value of the '<em><b>Floor</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Floor</em>' attribute.
	 * @see #setFloor(int)
	 * @see mde.MdePackage#getFoodcourt_Floor()
	 * @model
	 * @generated
	 */
	int getFloor();

	/**
	 * Sets the value of the '{@link mde.Foodcourt#getFloor <em>Floor</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Floor</em>' attribute.
	 * @see #getFloor()
	 * @generated
	 */
	void setFloor(int value);

	/**
	 * Returns the value of the '<em><b>Restaurants</b></em>' containment reference list.
	 * The list contents are of type {@link mde.restaurant}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Restaurants</em>' containment reference list.
	 * @see mde.MdePackage#getFoodcourt_Restaurants()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<restaurant> getRestaurants();

} // Foodcourt
