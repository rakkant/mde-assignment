/**
 */
package mde.impl;

import mde.AbstractDepartment;
import mde.Cinema;
import mde.ClothingStore;
import mde.Department;
import mde.DepartmentStore;
import mde.Foodcourt;
import mde.MdeFactory;
import mde.MdePackage;
import mde.clothingType;
import mde.foodType;
import mde.restaurant;

import mde.util.MdeValidator;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EValidator;

import org.eclipse.emf.ecore.impl.EPackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class MdePackageImpl extends EPackageImpl implements MdePackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass departmentStoreEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass departmentEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass foodcourtEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass clothingStoreEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass cinemaEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass restaurantEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass abstractDepartmentEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum foodTypeEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum clothingTypeEEnum = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see mde.MdePackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private MdePackageImpl() {
		super(eNS_URI, MdeFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 *
	 * <p>This method is used to initialize {@link MdePackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static MdePackage init() {
		if (isInited) return (MdePackage)EPackage.Registry.INSTANCE.getEPackage(MdePackage.eNS_URI);

		// Obtain or create and register package
		Object registeredMdePackage = EPackage.Registry.INSTANCE.get(eNS_URI);
		MdePackageImpl theMdePackage = registeredMdePackage instanceof MdePackageImpl ? (MdePackageImpl)registeredMdePackage : new MdePackageImpl();

		isInited = true;

		// Create package meta-data objects
		theMdePackage.createPackageContents();

		// Initialize created meta-data
		theMdePackage.initializePackageContents();

		// Register package validator
		EValidator.Registry.INSTANCE.put
			(theMdePackage,
			 new EValidator.Descriptor() {
				 public EValidator getEValidator() {
					 return MdeValidator.INSTANCE;
				 }
			 });

		// Mark meta-data to indicate it can't be changed
		theMdePackage.freeze();

		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(MdePackage.eNS_URI, theMdePackage);
		return theMdePackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDepartmentStore() {
		return departmentStoreEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDepartmentStore_Owner() {
		return (EAttribute)departmentStoreEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDepartmentStore_Location() {
		return (EAttribute)departmentStoreEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDepartmentStore_Departments() {
		return (EReference)departmentStoreEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDepartmentStore_TotalDepartments() {
		return (EAttribute)departmentStoreEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDepartmentStore_Name() {
		return (EAttribute)departmentStoreEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getDepartmentStore__IsNameNotEmpty__String() {
		return departmentStoreEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDepartment() {
		return departmentEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDepartment_ClothingStores() {
		return (EReference)departmentEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDepartment_Cinema() {
		return (EReference)departmentEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDepartment_Foodcourt() {
		return (EReference)departmentEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getFoodcourt() {
		return foodcourtEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getFoodcourt_Floor() {
		return (EAttribute)foodcourtEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getFoodcourt_Restaurants() {
		return (EReference)foodcourtEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getClothingStore() {
		return clothingStoreEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getClothingStore_Floor() {
		return (EAttribute)clothingStoreEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getClothingStore_Type() {
		return (EAttribute)clothingStoreEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCinema() {
		return cinemaEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCinema_Floor() {
		return (EAttribute)cinemaEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCinema_TheaterAmount() {
		return (EAttribute)cinemaEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getrestaurant() {
		return restaurantEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getrestaurant_Type() {
		return (EAttribute)restaurantEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAbstractDepartment() {
		return abstractDepartmentEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAbstractDepartment_ManagerAmount() {
		return (EAttribute)abstractDepartmentEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAbstractDepartment_EmployeeAmount() {
		return (EAttribute)abstractDepartmentEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAbstractDepartment_Capacity() {
		return (EAttribute)abstractDepartmentEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAbstractDepartment_Name() {
		return (EAttribute)abstractDepartmentEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getAbstractDepartment__IsManagerAmountLessThanEmployeeAmount__int_int() {
		return abstractDepartmentEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getAbstractDepartment__IsCapacityGreaterThanTotalDepartmentsMultiplyBy20__int_int() {
		return abstractDepartmentEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getfoodType() {
		return foodTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getclothingType() {
		return clothingTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MdeFactory getMdeFactory() {
		return (MdeFactory)getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated) return;
		isCreated = true;

		// Create classes and their features
		departmentStoreEClass = createEClass(DEPARTMENT_STORE);
		createEAttribute(departmentStoreEClass, DEPARTMENT_STORE__OWNER);
		createEAttribute(departmentStoreEClass, DEPARTMENT_STORE__LOCATION);
		createEReference(departmentStoreEClass, DEPARTMENT_STORE__DEPARTMENTS);
		createEAttribute(departmentStoreEClass, DEPARTMENT_STORE__TOTAL_DEPARTMENTS);
		createEAttribute(departmentStoreEClass, DEPARTMENT_STORE__NAME);
		createEOperation(departmentStoreEClass, DEPARTMENT_STORE___IS_NAME_NOT_EMPTY__STRING);

		departmentEClass = createEClass(DEPARTMENT);
		createEReference(departmentEClass, DEPARTMENT__CLOTHING_STORES);
		createEReference(departmentEClass, DEPARTMENT__CINEMA);
		createEReference(departmentEClass, DEPARTMENT__FOODCOURT);

		foodcourtEClass = createEClass(FOODCOURT);
		createEAttribute(foodcourtEClass, FOODCOURT__FLOOR);
		createEReference(foodcourtEClass, FOODCOURT__RESTAURANTS);

		clothingStoreEClass = createEClass(CLOTHING_STORE);
		createEAttribute(clothingStoreEClass, CLOTHING_STORE__FLOOR);
		createEAttribute(clothingStoreEClass, CLOTHING_STORE__TYPE);

		cinemaEClass = createEClass(CINEMA);
		createEAttribute(cinemaEClass, CINEMA__FLOOR);
		createEAttribute(cinemaEClass, CINEMA__THEATER_AMOUNT);

		restaurantEClass = createEClass(RESTAURANT);
		createEAttribute(restaurantEClass, RESTAURANT__TYPE);

		abstractDepartmentEClass = createEClass(ABSTRACT_DEPARTMENT);
		createEAttribute(abstractDepartmentEClass, ABSTRACT_DEPARTMENT__MANAGER_AMOUNT);
		createEAttribute(abstractDepartmentEClass, ABSTRACT_DEPARTMENT__EMPLOYEE_AMOUNT);
		createEAttribute(abstractDepartmentEClass, ABSTRACT_DEPARTMENT__CAPACITY);
		createEAttribute(abstractDepartmentEClass, ABSTRACT_DEPARTMENT__NAME);
		createEOperation(abstractDepartmentEClass, ABSTRACT_DEPARTMENT___IS_MANAGER_AMOUNT_LESS_THAN_EMPLOYEE_AMOUNT__INT_INT);
		createEOperation(abstractDepartmentEClass, ABSTRACT_DEPARTMENT___IS_CAPACITY_GREATER_THAN_TOTAL_DEPARTMENTS_MULTIPLY_BY20__INT_INT);

		// Create enums
		foodTypeEEnum = createEEnum(FOOD_TYPE);
		clothingTypeEEnum = createEEnum(CLOTHING_TYPE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized) return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		foodcourtEClass.getESuperTypes().add(this.getAbstractDepartment());
		clothingStoreEClass.getESuperTypes().add(this.getAbstractDepartment());
		cinemaEClass.getESuperTypes().add(this.getAbstractDepartment());

		// Initialize classes, features, and operations; add parameters
		initEClass(departmentStoreEClass, DepartmentStore.class, "DepartmentStore", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getDepartmentStore_Owner(), ecorePackage.getEString(), "owner", null, 0, 1, DepartmentStore.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getDepartmentStore_Location(), ecorePackage.getEString(), "location", null, 0, 1, DepartmentStore.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDepartmentStore_Departments(), this.getDepartment(), null, "departments", null, 1, -1, DepartmentStore.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getDepartmentStore_TotalDepartments(), ecorePackage.getEInt(), "TotalDepartments", null, 0, 1, DepartmentStore.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getDepartmentStore_Name(), ecorePackage.getEString(), "name", null, 0, 1, DepartmentStore.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		EOperation op = initEOperation(getDepartmentStore__IsNameNotEmpty__String(), ecorePackage.getEBooleanObject(), "isNameNotEmpty", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEString(), "name", 1, 1, IS_UNIQUE, IS_ORDERED);

		initEClass(departmentEClass, Department.class, "Department", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getDepartment_ClothingStores(), this.getClothingStore(), null, "clothingStores", null, 1, -1, Department.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDepartment_Cinema(), this.getCinema(), null, "cinema", null, 1, 1, Department.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDepartment_Foodcourt(), this.getFoodcourt(), null, "foodcourt", null, 1, 1, Department.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(foodcourtEClass, Foodcourt.class, "Foodcourt", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getFoodcourt_Floor(), ecorePackage.getEInt(), "floor", null, 0, 1, Foodcourt.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getFoodcourt_Restaurants(), this.getrestaurant(), null, "restaurants", null, 1, -1, Foodcourt.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(clothingStoreEClass, ClothingStore.class, "ClothingStore", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getClothingStore_Floor(), ecorePackage.getEInt(), "floor", null, 0, 1, ClothingStore.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getClothingStore_Type(), this.getclothingType(), "type", null, 0, 1, ClothingStore.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(cinemaEClass, Cinema.class, "Cinema", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getCinema_Floor(), ecorePackage.getEInt(), "floor", null, 0, 1, Cinema.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCinema_TheaterAmount(), ecorePackage.getEInt(), "theaterAmount", null, 0, 1, Cinema.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(restaurantEClass, restaurant.class, "restaurant", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getrestaurant_Type(), this.getfoodType(), "type", null, 0, 1, restaurant.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(abstractDepartmentEClass, AbstractDepartment.class, "AbstractDepartment", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getAbstractDepartment_ManagerAmount(), ecorePackage.getEInt(), "managerAmount", null, 0, 1, AbstractDepartment.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAbstractDepartment_EmployeeAmount(), ecorePackage.getEInt(), "employeeAmount", null, 0, 1, AbstractDepartment.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAbstractDepartment_Capacity(), ecorePackage.getEInt(), "capacity", null, 0, 1, AbstractDepartment.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAbstractDepartment_Name(), ecorePackage.getEString(), "name", null, 0, 1, AbstractDepartment.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		op = initEOperation(getAbstractDepartment__IsManagerAmountLessThanEmployeeAmount__int_int(), ecorePackage.getEBooleanObject(), "isManagerAmountLessThanEmployeeAmount", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEInt(), "managerAmount", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEInt(), "employeeAmount", 1, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getAbstractDepartment__IsCapacityGreaterThanTotalDepartmentsMultiplyBy20__int_int(), null, "isCapacityGreaterThanTotalDepartmentsMultiplyBy20", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEInt(), "totalDepartments", 1, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEInt(), "capacity", 1, 1, IS_UNIQUE, IS_ORDERED);

		// Initialize enums and add enum literals
		initEEnum(foodTypeEEnum, foodType.class, "foodType");
		addEEnumLiteral(foodTypeEEnum, foodType.JAPANESE);
		addEEnumLiteral(foodTypeEEnum, foodType.FASTFOOD);
		addEEnumLiteral(foodTypeEEnum, foodType.ITALIAN);
		addEEnumLiteral(foodTypeEEnum, foodType.CAFE);

		initEEnum(clothingTypeEEnum, clothingType.class, "clothingType");
		addEEnumLiteral(clothingTypeEEnum, clothingType.WOMEN_CLOTHINGS);
		addEEnumLiteral(clothingTypeEEnum, clothingType.MEN_CLOTHINGS);
		addEEnumLiteral(clothingTypeEEnum, clothingType.KIDS_CLOTHINGS);

		// Create resource
		createResource(eNS_URI);

		// Create annotations
		// http://www.eclipse.org/emf/2002/Ecore
		createEcoreAnnotations();
		// http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot
		createPivotAnnotations();
	}

	/**
	 * Initializes the annotations for <b>http://www.eclipse.org/emf/2002/Ecore</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createEcoreAnnotations() {
		String source = "http://www.eclipse.org/emf/2002/Ecore";
		addAnnotation
		  (this,
		   source,
		   new String[] {
			   "conversionDelegates", "http:///org/eclipse/emf/ecore/util/DateConversionDelegate",
			   "invocationDelegates", "http://www.eclipse.org/emf/2002/Ecore/OCL",
			   "validationDelegates", "http://www.eclipse.org/emf/2002/Ecore/OCL"
		   });
		addAnnotation
		  (departmentStoreEClass,
		   source,
		   new String[] {
			   "constraints", "name"
		   });
	}

	/**
	 * Initializes the annotations for <b>http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createPivotAnnotations() {
		String source = "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot";
		addAnnotation
		  (getDepartmentStore__IsNameNotEmpty__String(),
		   source,
		   new String[] {
			   "body", "name != null"
		   });
		addAnnotation
		  (getDepartmentStore_TotalDepartments(),
		   source,
		   new String[] {
			   "derivation", "Department"
		   });
		addAnnotation
		  (getAbstractDepartment__IsManagerAmountLessThanEmployeeAmount__int_int(),
		   source,
		   new String[] {
			   "body", "managerAmount < employeeAmount"
		   });
		addAnnotation
		  (getAbstractDepartment__IsCapacityGreaterThanTotalDepartmentsMultiplyBy20__int_int(),
		   source,
		   new String[] {
			   "body", "capacity > departmentAmount*20"
		   });
	}

} //MdePackageImpl
