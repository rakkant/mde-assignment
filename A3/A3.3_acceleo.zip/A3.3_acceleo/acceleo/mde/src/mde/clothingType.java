/**
 */
package mde;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.Enumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>clothing Type</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * @see mde.MdePackage#getclothingType()
 * @model
 * @generated
 */
public enum clothingType implements Enumerator {
	/**
	 * The '<em><b>Women Clothings</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #WOMEN_CLOTHINGS_VALUE
	 * @generated
	 * @ordered
	 */
	WOMEN_CLOTHINGS(0, "womenClothings", "womenClothings"),

	/**
	 * The '<em><b>Men Clothings</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #MEN_CLOTHINGS_VALUE
	 * @generated
	 * @ordered
	 */
	MEN_CLOTHINGS(1, "menClothings", "menClothings"),

	/**
	 * The '<em><b>Kids Clothings</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #KIDS_CLOTHINGS_VALUE
	 * @generated
	 * @ordered
	 */
	KIDS_CLOTHINGS(2, "kidsClothings", "kidsClothings");

	/**
	 * The '<em><b>Women Clothings</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #WOMEN_CLOTHINGS
	 * @model name="womenClothings"
	 * @generated
	 * @ordered
	 */
	public static final int WOMEN_CLOTHINGS_VALUE = 0;

	/**
	 * The '<em><b>Men Clothings</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #MEN_CLOTHINGS
	 * @model name="menClothings"
	 * @generated
	 * @ordered
	 */
	public static final int MEN_CLOTHINGS_VALUE = 1;

	/**
	 * The '<em><b>Kids Clothings</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #KIDS_CLOTHINGS
	 * @model name="kidsClothings"
	 * @generated
	 * @ordered
	 */
	public static final int KIDS_CLOTHINGS_VALUE = 2;

	/**
	 * An array of all the '<em><b>clothing Type</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final clothingType[] VALUES_ARRAY =
		new clothingType[] {
			WOMEN_CLOTHINGS,
			MEN_CLOTHINGS,
			KIDS_CLOTHINGS,
		};

	/**
	 * A public read-only list of all the '<em><b>clothing Type</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final List<clothingType> VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	/**
	 * Returns the '<em><b>clothing Type</b></em>' literal with the specified literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param literal the literal.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static clothingType get(String literal) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			clothingType result = VALUES_ARRAY[i];
			if (result.toString().equals(literal)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>clothing Type</b></em>' literal with the specified name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param name the name.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static clothingType getByName(String name) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			clothingType result = VALUES_ARRAY[i];
			if (result.getName().equals(name)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>clothing Type</b></em>' literal with the specified integer value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the integer value.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static clothingType get(int value) {
		switch (value) {
			case WOMEN_CLOTHINGS_VALUE: return WOMEN_CLOTHINGS;
			case MEN_CLOTHINGS_VALUE: return MEN_CLOTHINGS;
			case KIDS_CLOTHINGS_VALUE: return KIDS_CLOTHINGS;
		}
		return null;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final int value;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String name;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String literal;

	/**
	 * Only this class can construct instances.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private clothingType(int value, String name, String literal) {
		this.value = value;
		this.name = name;
		this.literal = literal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getValue() {
	  return value;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
	  return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLiteral() {
	  return literal;
	}

	/**
	 * Returns the literal value of the enumerator, which is its string representation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		return literal;
	}
	
} //clothingType
