package org.xtext.example.mdeStore.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.common.util.Enumerator;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import org.xtext.example.mdeStore.services.MyProjectGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalMyProjectParser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_STRING", "RULE_ID", "RULE_INT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'ShoppingMall'", "'{'", "'companyName'", "'ceo'", "'location'", "'shops'", "','", "'}'", "'Shop'", "'supermarket'", "'clothingStores'", "'Supermarket'", "'supervisorName'", "'employeeAmount'", "'managerAmount'", "'floorNumber'", "'openingTime'", "'closingTime'", "'sections'", "'ClothingStore'", "'type'", "'-'", "'Section'", "'freshProduce'", "'freshVegetablesAndFruits'", "'kitchenWare'", "'householdCleaners'", "'men'", "'women'", "'kids'", "'shoes'"
    };
    public static final int RULE_STRING=4;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__37=37;
    public static final int T__16=16;
    public static final int T__38=38;
    public static final int T__17=17;
    public static final int T__39=39;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int T__33=33;
    public static final int T__12=12;
    public static final int T__34=34;
    public static final int T__13=13;
    public static final int T__35=35;
    public static final int T__14=14;
    public static final int T__36=36;
    public static final int EOF=-1;
    public static final int T__30=30;
    public static final int T__31=31;
    public static final int T__32=32;
    public static final int RULE_ID=5;
    public static final int RULE_WS=9;
    public static final int RULE_ANY_OTHER=10;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int RULE_INT=6;
    public static final int T__29=29;
    public static final int T__22=22;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__23=23;
    public static final int T__24=24;
    public static final int T__25=25;
    public static final int T__40=40;
    public static final int T__41=41;
    public static final int T__20=20;
    public static final int T__21=21;

    // delegates
    // delegators


        public InternalMyProjectParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalMyProjectParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalMyProjectParser.tokenNames; }
    public String getGrammarFileName() { return "InternalMyProject.g"; }



     	private MyProjectGrammarAccess grammarAccess;

        public InternalMyProjectParser(TokenStream input, MyProjectGrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "ShoppingMall";
       	}

       	@Override
       	protected MyProjectGrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleShoppingMall"
    // InternalMyProject.g:65:1: entryRuleShoppingMall returns [EObject current=null] : iv_ruleShoppingMall= ruleShoppingMall EOF ;
    public final EObject entryRuleShoppingMall() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleShoppingMall = null;


        try {
            // InternalMyProject.g:65:53: (iv_ruleShoppingMall= ruleShoppingMall EOF )
            // InternalMyProject.g:66:2: iv_ruleShoppingMall= ruleShoppingMall EOF
            {
             newCompositeNode(grammarAccess.getShoppingMallRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleShoppingMall=ruleShoppingMall();

            state._fsp--;

             current =iv_ruleShoppingMall; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleShoppingMall"


    // $ANTLR start "ruleShoppingMall"
    // InternalMyProject.g:72:1: ruleShoppingMall returns [EObject current=null] : (otherlv_0= 'ShoppingMall' otherlv_1= '{' (otherlv_2= 'companyName' ( (lv_companyName_3_0= ruleEString ) ) )? (otherlv_4= 'ceo' ( (lv_ceo_5_0= ruleEString ) ) )? (otherlv_6= 'location' ( (lv_location_7_0= ruleEString ) ) )? otherlv_8= 'shops' otherlv_9= '{' ( (lv_shops_10_0= ruleShop ) ) (otherlv_11= ',' ( (lv_shops_12_0= ruleShop ) ) )* otherlv_13= '}' otherlv_14= '}' ) ;
    public final EObject ruleShoppingMall() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        Token otherlv_8=null;
        Token otherlv_9=null;
        Token otherlv_11=null;
        Token otherlv_13=null;
        Token otherlv_14=null;
        AntlrDatatypeRuleToken lv_companyName_3_0 = null;

        AntlrDatatypeRuleToken lv_ceo_5_0 = null;

        AntlrDatatypeRuleToken lv_location_7_0 = null;

        EObject lv_shops_10_0 = null;

        EObject lv_shops_12_0 = null;



        	enterRule();

        try {
            // InternalMyProject.g:78:2: ( (otherlv_0= 'ShoppingMall' otherlv_1= '{' (otherlv_2= 'companyName' ( (lv_companyName_3_0= ruleEString ) ) )? (otherlv_4= 'ceo' ( (lv_ceo_5_0= ruleEString ) ) )? (otherlv_6= 'location' ( (lv_location_7_0= ruleEString ) ) )? otherlv_8= 'shops' otherlv_9= '{' ( (lv_shops_10_0= ruleShop ) ) (otherlv_11= ',' ( (lv_shops_12_0= ruleShop ) ) )* otherlv_13= '}' otherlv_14= '}' ) )
            // InternalMyProject.g:79:2: (otherlv_0= 'ShoppingMall' otherlv_1= '{' (otherlv_2= 'companyName' ( (lv_companyName_3_0= ruleEString ) ) )? (otherlv_4= 'ceo' ( (lv_ceo_5_0= ruleEString ) ) )? (otherlv_6= 'location' ( (lv_location_7_0= ruleEString ) ) )? otherlv_8= 'shops' otherlv_9= '{' ( (lv_shops_10_0= ruleShop ) ) (otherlv_11= ',' ( (lv_shops_12_0= ruleShop ) ) )* otherlv_13= '}' otherlv_14= '}' )
            {
            // InternalMyProject.g:79:2: (otherlv_0= 'ShoppingMall' otherlv_1= '{' (otherlv_2= 'companyName' ( (lv_companyName_3_0= ruleEString ) ) )? (otherlv_4= 'ceo' ( (lv_ceo_5_0= ruleEString ) ) )? (otherlv_6= 'location' ( (lv_location_7_0= ruleEString ) ) )? otherlv_8= 'shops' otherlv_9= '{' ( (lv_shops_10_0= ruleShop ) ) (otherlv_11= ',' ( (lv_shops_12_0= ruleShop ) ) )* otherlv_13= '}' otherlv_14= '}' )
            // InternalMyProject.g:80:3: otherlv_0= 'ShoppingMall' otherlv_1= '{' (otherlv_2= 'companyName' ( (lv_companyName_3_0= ruleEString ) ) )? (otherlv_4= 'ceo' ( (lv_ceo_5_0= ruleEString ) ) )? (otherlv_6= 'location' ( (lv_location_7_0= ruleEString ) ) )? otherlv_8= 'shops' otherlv_9= '{' ( (lv_shops_10_0= ruleShop ) ) (otherlv_11= ',' ( (lv_shops_12_0= ruleShop ) ) )* otherlv_13= '}' otherlv_14= '}'
            {
            otherlv_0=(Token)match(input,11,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getShoppingMallAccess().getShoppingMallKeyword_0());
            		
            otherlv_1=(Token)match(input,12,FOLLOW_4); 

            			newLeafNode(otherlv_1, grammarAccess.getShoppingMallAccess().getLeftCurlyBracketKeyword_1());
            		
            // InternalMyProject.g:88:3: (otherlv_2= 'companyName' ( (lv_companyName_3_0= ruleEString ) ) )?
            int alt1=2;
            int LA1_0 = input.LA(1);

            if ( (LA1_0==13) ) {
                alt1=1;
            }
            switch (alt1) {
                case 1 :
                    // InternalMyProject.g:89:4: otherlv_2= 'companyName' ( (lv_companyName_3_0= ruleEString ) )
                    {
                    otherlv_2=(Token)match(input,13,FOLLOW_5); 

                    				newLeafNode(otherlv_2, grammarAccess.getShoppingMallAccess().getCompanyNameKeyword_2_0());
                    			
                    // InternalMyProject.g:93:4: ( (lv_companyName_3_0= ruleEString ) )
                    // InternalMyProject.g:94:5: (lv_companyName_3_0= ruleEString )
                    {
                    // InternalMyProject.g:94:5: (lv_companyName_3_0= ruleEString )
                    // InternalMyProject.g:95:6: lv_companyName_3_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getShoppingMallAccess().getCompanyNameEStringParserRuleCall_2_1_0());
                    					
                    pushFollow(FOLLOW_6);
                    lv_companyName_3_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getShoppingMallRule());
                    						}
                    						set(
                    							current,
                    							"companyName",
                    							lv_companyName_3_0,
                    							"org.xtext.example.mdeStore.MyProject.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalMyProject.g:113:3: (otherlv_4= 'ceo' ( (lv_ceo_5_0= ruleEString ) ) )?
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==14) ) {
                alt2=1;
            }
            switch (alt2) {
                case 1 :
                    // InternalMyProject.g:114:4: otherlv_4= 'ceo' ( (lv_ceo_5_0= ruleEString ) )
                    {
                    otherlv_4=(Token)match(input,14,FOLLOW_5); 

                    				newLeafNode(otherlv_4, grammarAccess.getShoppingMallAccess().getCeoKeyword_3_0());
                    			
                    // InternalMyProject.g:118:4: ( (lv_ceo_5_0= ruleEString ) )
                    // InternalMyProject.g:119:5: (lv_ceo_5_0= ruleEString )
                    {
                    // InternalMyProject.g:119:5: (lv_ceo_5_0= ruleEString )
                    // InternalMyProject.g:120:6: lv_ceo_5_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getShoppingMallAccess().getCeoEStringParserRuleCall_3_1_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_ceo_5_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getShoppingMallRule());
                    						}
                    						set(
                    							current,
                    							"ceo",
                    							lv_ceo_5_0,
                    							"org.xtext.example.mdeStore.MyProject.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalMyProject.g:138:3: (otherlv_6= 'location' ( (lv_location_7_0= ruleEString ) ) )?
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( (LA3_0==15) ) {
                alt3=1;
            }
            switch (alt3) {
                case 1 :
                    // InternalMyProject.g:139:4: otherlv_6= 'location' ( (lv_location_7_0= ruleEString ) )
                    {
                    otherlv_6=(Token)match(input,15,FOLLOW_5); 

                    				newLeafNode(otherlv_6, grammarAccess.getShoppingMallAccess().getLocationKeyword_4_0());
                    			
                    // InternalMyProject.g:143:4: ( (lv_location_7_0= ruleEString ) )
                    // InternalMyProject.g:144:5: (lv_location_7_0= ruleEString )
                    {
                    // InternalMyProject.g:144:5: (lv_location_7_0= ruleEString )
                    // InternalMyProject.g:145:6: lv_location_7_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getShoppingMallAccess().getLocationEStringParserRuleCall_4_1_0());
                    					
                    pushFollow(FOLLOW_8);
                    lv_location_7_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getShoppingMallRule());
                    						}
                    						set(
                    							current,
                    							"location",
                    							lv_location_7_0,
                    							"org.xtext.example.mdeStore.MyProject.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_8=(Token)match(input,16,FOLLOW_3); 

            			newLeafNode(otherlv_8, grammarAccess.getShoppingMallAccess().getShopsKeyword_5());
            		
            otherlv_9=(Token)match(input,12,FOLLOW_9); 

            			newLeafNode(otherlv_9, grammarAccess.getShoppingMallAccess().getLeftCurlyBracketKeyword_6());
            		
            // InternalMyProject.g:171:3: ( (lv_shops_10_0= ruleShop ) )
            // InternalMyProject.g:172:4: (lv_shops_10_0= ruleShop )
            {
            // InternalMyProject.g:172:4: (lv_shops_10_0= ruleShop )
            // InternalMyProject.g:173:5: lv_shops_10_0= ruleShop
            {

            					newCompositeNode(grammarAccess.getShoppingMallAccess().getShopsShopParserRuleCall_7_0());
            				
            pushFollow(FOLLOW_10);
            lv_shops_10_0=ruleShop();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getShoppingMallRule());
            					}
            					add(
            						current,
            						"shops",
            						lv_shops_10_0,
            						"org.xtext.example.mdeStore.MyProject.Shop");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalMyProject.g:190:3: (otherlv_11= ',' ( (lv_shops_12_0= ruleShop ) ) )*
            loop4:
            do {
                int alt4=2;
                int LA4_0 = input.LA(1);

                if ( (LA4_0==17) ) {
                    alt4=1;
                }


                switch (alt4) {
            	case 1 :
            	    // InternalMyProject.g:191:4: otherlv_11= ',' ( (lv_shops_12_0= ruleShop ) )
            	    {
            	    otherlv_11=(Token)match(input,17,FOLLOW_9); 

            	    				newLeafNode(otherlv_11, grammarAccess.getShoppingMallAccess().getCommaKeyword_8_0());
            	    			
            	    // InternalMyProject.g:195:4: ( (lv_shops_12_0= ruleShop ) )
            	    // InternalMyProject.g:196:5: (lv_shops_12_0= ruleShop )
            	    {
            	    // InternalMyProject.g:196:5: (lv_shops_12_0= ruleShop )
            	    // InternalMyProject.g:197:6: lv_shops_12_0= ruleShop
            	    {

            	    						newCompositeNode(grammarAccess.getShoppingMallAccess().getShopsShopParserRuleCall_8_1_0());
            	    					
            	    pushFollow(FOLLOW_10);
            	    lv_shops_12_0=ruleShop();

            	    state._fsp--;


            	    						if (current==null) {
            	    							current = createModelElementForParent(grammarAccess.getShoppingMallRule());
            	    						}
            	    						add(
            	    							current,
            	    							"shops",
            	    							lv_shops_12_0,
            	    							"org.xtext.example.mdeStore.MyProject.Shop");
            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop4;
                }
            } while (true);

            otherlv_13=(Token)match(input,18,FOLLOW_11); 

            			newLeafNode(otherlv_13, grammarAccess.getShoppingMallAccess().getRightCurlyBracketKeyword_9());
            		
            otherlv_14=(Token)match(input,18,FOLLOW_2); 

            			newLeafNode(otherlv_14, grammarAccess.getShoppingMallAccess().getRightCurlyBracketKeyword_10());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleShoppingMall"


    // $ANTLR start "entryRuleEString"
    // InternalMyProject.g:227:1: entryRuleEString returns [String current=null] : iv_ruleEString= ruleEString EOF ;
    public final String entryRuleEString() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleEString = null;


        try {
            // InternalMyProject.g:227:47: (iv_ruleEString= ruleEString EOF )
            // InternalMyProject.g:228:2: iv_ruleEString= ruleEString EOF
            {
             newCompositeNode(grammarAccess.getEStringRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEString=ruleEString();

            state._fsp--;

             current =iv_ruleEString.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEString"


    // $ANTLR start "ruleEString"
    // InternalMyProject.g:234:1: ruleEString returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID ) ;
    public final AntlrDatatypeRuleToken ruleEString() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_STRING_0=null;
        Token this_ID_1=null;


        	enterRule();

        try {
            // InternalMyProject.g:240:2: ( (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID ) )
            // InternalMyProject.g:241:2: (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID )
            {
            // InternalMyProject.g:241:2: (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID )
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0==RULE_STRING) ) {
                alt5=1;
            }
            else if ( (LA5_0==RULE_ID) ) {
                alt5=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 5, 0, input);

                throw nvae;
            }
            switch (alt5) {
                case 1 :
                    // InternalMyProject.g:242:3: this_STRING_0= RULE_STRING
                    {
                    this_STRING_0=(Token)match(input,RULE_STRING,FOLLOW_2); 

                    			current.merge(this_STRING_0);
                    		

                    			newLeafNode(this_STRING_0, grammarAccess.getEStringAccess().getSTRINGTerminalRuleCall_0());
                    		

                    }
                    break;
                case 2 :
                    // InternalMyProject.g:250:3: this_ID_1= RULE_ID
                    {
                    this_ID_1=(Token)match(input,RULE_ID,FOLLOW_2); 

                    			current.merge(this_ID_1);
                    		

                    			newLeafNode(this_ID_1, grammarAccess.getEStringAccess().getIDTerminalRuleCall_1());
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEString"


    // $ANTLR start "entryRuleShop"
    // InternalMyProject.g:261:1: entryRuleShop returns [EObject current=null] : iv_ruleShop= ruleShop EOF ;
    public final EObject entryRuleShop() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleShop = null;


        try {
            // InternalMyProject.g:261:45: (iv_ruleShop= ruleShop EOF )
            // InternalMyProject.g:262:2: iv_ruleShop= ruleShop EOF
            {
             newCompositeNode(grammarAccess.getShopRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleShop=ruleShop();

            state._fsp--;

             current =iv_ruleShop; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleShop"


    // $ANTLR start "ruleShop"
    // InternalMyProject.g:268:1: ruleShop returns [EObject current=null] : (otherlv_0= 'Shop' otherlv_1= '{' otherlv_2= 'supermarket' ( (lv_supermarket_3_0= ruleSupermarket ) ) otherlv_4= 'clothingStores' otherlv_5= '{' ( (lv_clothingStores_6_0= ruleClothingStore ) ) (otherlv_7= ',' ( (lv_clothingStores_8_0= ruleClothingStore ) ) )* otherlv_9= '}' otherlv_10= '}' ) ;
    public final EObject ruleShop() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        Token otherlv_9=null;
        Token otherlv_10=null;
        EObject lv_supermarket_3_0 = null;

        EObject lv_clothingStores_6_0 = null;

        EObject lv_clothingStores_8_0 = null;



        	enterRule();

        try {
            // InternalMyProject.g:274:2: ( (otherlv_0= 'Shop' otherlv_1= '{' otherlv_2= 'supermarket' ( (lv_supermarket_3_0= ruleSupermarket ) ) otherlv_4= 'clothingStores' otherlv_5= '{' ( (lv_clothingStores_6_0= ruleClothingStore ) ) (otherlv_7= ',' ( (lv_clothingStores_8_0= ruleClothingStore ) ) )* otherlv_9= '}' otherlv_10= '}' ) )
            // InternalMyProject.g:275:2: (otherlv_0= 'Shop' otherlv_1= '{' otherlv_2= 'supermarket' ( (lv_supermarket_3_0= ruleSupermarket ) ) otherlv_4= 'clothingStores' otherlv_5= '{' ( (lv_clothingStores_6_0= ruleClothingStore ) ) (otherlv_7= ',' ( (lv_clothingStores_8_0= ruleClothingStore ) ) )* otherlv_9= '}' otherlv_10= '}' )
            {
            // InternalMyProject.g:275:2: (otherlv_0= 'Shop' otherlv_1= '{' otherlv_2= 'supermarket' ( (lv_supermarket_3_0= ruleSupermarket ) ) otherlv_4= 'clothingStores' otherlv_5= '{' ( (lv_clothingStores_6_0= ruleClothingStore ) ) (otherlv_7= ',' ( (lv_clothingStores_8_0= ruleClothingStore ) ) )* otherlv_9= '}' otherlv_10= '}' )
            // InternalMyProject.g:276:3: otherlv_0= 'Shop' otherlv_1= '{' otherlv_2= 'supermarket' ( (lv_supermarket_3_0= ruleSupermarket ) ) otherlv_4= 'clothingStores' otherlv_5= '{' ( (lv_clothingStores_6_0= ruleClothingStore ) ) (otherlv_7= ',' ( (lv_clothingStores_8_0= ruleClothingStore ) ) )* otherlv_9= '}' otherlv_10= '}'
            {
            otherlv_0=(Token)match(input,19,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getShopAccess().getShopKeyword_0());
            		
            otherlv_1=(Token)match(input,12,FOLLOW_12); 

            			newLeafNode(otherlv_1, grammarAccess.getShopAccess().getLeftCurlyBracketKeyword_1());
            		
            otherlv_2=(Token)match(input,20,FOLLOW_13); 

            			newLeafNode(otherlv_2, grammarAccess.getShopAccess().getSupermarketKeyword_2());
            		
            // InternalMyProject.g:288:3: ( (lv_supermarket_3_0= ruleSupermarket ) )
            // InternalMyProject.g:289:4: (lv_supermarket_3_0= ruleSupermarket )
            {
            // InternalMyProject.g:289:4: (lv_supermarket_3_0= ruleSupermarket )
            // InternalMyProject.g:290:5: lv_supermarket_3_0= ruleSupermarket
            {

            					newCompositeNode(grammarAccess.getShopAccess().getSupermarketSupermarketParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_14);
            lv_supermarket_3_0=ruleSupermarket();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getShopRule());
            					}
            					set(
            						current,
            						"supermarket",
            						lv_supermarket_3_0,
            						"org.xtext.example.mdeStore.MyProject.Supermarket");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_4=(Token)match(input,21,FOLLOW_3); 

            			newLeafNode(otherlv_4, grammarAccess.getShopAccess().getClothingStoresKeyword_4());
            		
            otherlv_5=(Token)match(input,12,FOLLOW_15); 

            			newLeafNode(otherlv_5, grammarAccess.getShopAccess().getLeftCurlyBracketKeyword_5());
            		
            // InternalMyProject.g:315:3: ( (lv_clothingStores_6_0= ruleClothingStore ) )
            // InternalMyProject.g:316:4: (lv_clothingStores_6_0= ruleClothingStore )
            {
            // InternalMyProject.g:316:4: (lv_clothingStores_6_0= ruleClothingStore )
            // InternalMyProject.g:317:5: lv_clothingStores_6_0= ruleClothingStore
            {

            					newCompositeNode(grammarAccess.getShopAccess().getClothingStoresClothingStoreParserRuleCall_6_0());
            				
            pushFollow(FOLLOW_10);
            lv_clothingStores_6_0=ruleClothingStore();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getShopRule());
            					}
            					add(
            						current,
            						"clothingStores",
            						lv_clothingStores_6_0,
            						"org.xtext.example.mdeStore.MyProject.ClothingStore");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalMyProject.g:334:3: (otherlv_7= ',' ( (lv_clothingStores_8_0= ruleClothingStore ) ) )*
            loop6:
            do {
                int alt6=2;
                int LA6_0 = input.LA(1);

                if ( (LA6_0==17) ) {
                    alt6=1;
                }


                switch (alt6) {
            	case 1 :
            	    // InternalMyProject.g:335:4: otherlv_7= ',' ( (lv_clothingStores_8_0= ruleClothingStore ) )
            	    {
            	    otherlv_7=(Token)match(input,17,FOLLOW_15); 

            	    				newLeafNode(otherlv_7, grammarAccess.getShopAccess().getCommaKeyword_7_0());
            	    			
            	    // InternalMyProject.g:339:4: ( (lv_clothingStores_8_0= ruleClothingStore ) )
            	    // InternalMyProject.g:340:5: (lv_clothingStores_8_0= ruleClothingStore )
            	    {
            	    // InternalMyProject.g:340:5: (lv_clothingStores_8_0= ruleClothingStore )
            	    // InternalMyProject.g:341:6: lv_clothingStores_8_0= ruleClothingStore
            	    {

            	    						newCompositeNode(grammarAccess.getShopAccess().getClothingStoresClothingStoreParserRuleCall_7_1_0());
            	    					
            	    pushFollow(FOLLOW_10);
            	    lv_clothingStores_8_0=ruleClothingStore();

            	    state._fsp--;


            	    						if (current==null) {
            	    							current = createModelElementForParent(grammarAccess.getShopRule());
            	    						}
            	    						add(
            	    							current,
            	    							"clothingStores",
            	    							lv_clothingStores_8_0,
            	    							"org.xtext.example.mdeStore.MyProject.ClothingStore");
            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop6;
                }
            } while (true);

            otherlv_9=(Token)match(input,18,FOLLOW_11); 

            			newLeafNode(otherlv_9, grammarAccess.getShopAccess().getRightCurlyBracketKeyword_8());
            		
            otherlv_10=(Token)match(input,18,FOLLOW_2); 

            			newLeafNode(otherlv_10, grammarAccess.getShopAccess().getRightCurlyBracketKeyword_9());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleShop"


    // $ANTLR start "entryRuleSupermarket"
    // InternalMyProject.g:371:1: entryRuleSupermarket returns [EObject current=null] : iv_ruleSupermarket= ruleSupermarket EOF ;
    public final EObject entryRuleSupermarket() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSupermarket = null;


        try {
            // InternalMyProject.g:371:52: (iv_ruleSupermarket= ruleSupermarket EOF )
            // InternalMyProject.g:372:2: iv_ruleSupermarket= ruleSupermarket EOF
            {
             newCompositeNode(grammarAccess.getSupermarketRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleSupermarket=ruleSupermarket();

            state._fsp--;

             current =iv_ruleSupermarket; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSupermarket"


    // $ANTLR start "ruleSupermarket"
    // InternalMyProject.g:378:1: ruleSupermarket returns [EObject current=null] : (otherlv_0= 'Supermarket' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '{' (otherlv_3= 'supervisorName' ( (lv_supervisorName_4_0= ruleEString ) ) )? (otherlv_5= 'employeeAmount' ( (lv_employeeAmount_6_0= ruleEInt ) ) )? (otherlv_7= 'managerAmount' ( (lv_managerAmount_8_0= ruleEInt ) ) )? (otherlv_9= 'floorNumber' ( (lv_floorNumber_10_0= ruleEInt ) ) )? (otherlv_11= 'openingTime' ( (lv_openingTime_12_0= ruleEString ) ) )? (otherlv_13= 'closingTime' ( (lv_closingTime_14_0= ruleEString ) ) )? otherlv_15= 'sections' otherlv_16= '{' ( (lv_sections_17_0= ruleSection ) ) (otherlv_18= ',' ( (lv_sections_19_0= ruleSection ) ) )* otherlv_20= '}' otherlv_21= '}' ) ;
    public final EObject ruleSupermarket() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        Token otherlv_9=null;
        Token otherlv_11=null;
        Token otherlv_13=null;
        Token otherlv_15=null;
        Token otherlv_16=null;
        Token otherlv_18=null;
        Token otherlv_20=null;
        Token otherlv_21=null;
        AntlrDatatypeRuleToken lv_name_1_0 = null;

        AntlrDatatypeRuleToken lv_supervisorName_4_0 = null;

        AntlrDatatypeRuleToken lv_employeeAmount_6_0 = null;

        AntlrDatatypeRuleToken lv_managerAmount_8_0 = null;

        AntlrDatatypeRuleToken lv_floorNumber_10_0 = null;

        AntlrDatatypeRuleToken lv_openingTime_12_0 = null;

        AntlrDatatypeRuleToken lv_closingTime_14_0 = null;

        EObject lv_sections_17_0 = null;

        EObject lv_sections_19_0 = null;



        	enterRule();

        try {
            // InternalMyProject.g:384:2: ( (otherlv_0= 'Supermarket' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '{' (otherlv_3= 'supervisorName' ( (lv_supervisorName_4_0= ruleEString ) ) )? (otherlv_5= 'employeeAmount' ( (lv_employeeAmount_6_0= ruleEInt ) ) )? (otherlv_7= 'managerAmount' ( (lv_managerAmount_8_0= ruleEInt ) ) )? (otherlv_9= 'floorNumber' ( (lv_floorNumber_10_0= ruleEInt ) ) )? (otherlv_11= 'openingTime' ( (lv_openingTime_12_0= ruleEString ) ) )? (otherlv_13= 'closingTime' ( (lv_closingTime_14_0= ruleEString ) ) )? otherlv_15= 'sections' otherlv_16= '{' ( (lv_sections_17_0= ruleSection ) ) (otherlv_18= ',' ( (lv_sections_19_0= ruleSection ) ) )* otherlv_20= '}' otherlv_21= '}' ) )
            // InternalMyProject.g:385:2: (otherlv_0= 'Supermarket' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '{' (otherlv_3= 'supervisorName' ( (lv_supervisorName_4_0= ruleEString ) ) )? (otherlv_5= 'employeeAmount' ( (lv_employeeAmount_6_0= ruleEInt ) ) )? (otherlv_7= 'managerAmount' ( (lv_managerAmount_8_0= ruleEInt ) ) )? (otherlv_9= 'floorNumber' ( (lv_floorNumber_10_0= ruleEInt ) ) )? (otherlv_11= 'openingTime' ( (lv_openingTime_12_0= ruleEString ) ) )? (otherlv_13= 'closingTime' ( (lv_closingTime_14_0= ruleEString ) ) )? otherlv_15= 'sections' otherlv_16= '{' ( (lv_sections_17_0= ruleSection ) ) (otherlv_18= ',' ( (lv_sections_19_0= ruleSection ) ) )* otherlv_20= '}' otherlv_21= '}' )
            {
            // InternalMyProject.g:385:2: (otherlv_0= 'Supermarket' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '{' (otherlv_3= 'supervisorName' ( (lv_supervisorName_4_0= ruleEString ) ) )? (otherlv_5= 'employeeAmount' ( (lv_employeeAmount_6_0= ruleEInt ) ) )? (otherlv_7= 'managerAmount' ( (lv_managerAmount_8_0= ruleEInt ) ) )? (otherlv_9= 'floorNumber' ( (lv_floorNumber_10_0= ruleEInt ) ) )? (otherlv_11= 'openingTime' ( (lv_openingTime_12_0= ruleEString ) ) )? (otherlv_13= 'closingTime' ( (lv_closingTime_14_0= ruleEString ) ) )? otherlv_15= 'sections' otherlv_16= '{' ( (lv_sections_17_0= ruleSection ) ) (otherlv_18= ',' ( (lv_sections_19_0= ruleSection ) ) )* otherlv_20= '}' otherlv_21= '}' )
            // InternalMyProject.g:386:3: otherlv_0= 'Supermarket' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '{' (otherlv_3= 'supervisorName' ( (lv_supervisorName_4_0= ruleEString ) ) )? (otherlv_5= 'employeeAmount' ( (lv_employeeAmount_6_0= ruleEInt ) ) )? (otherlv_7= 'managerAmount' ( (lv_managerAmount_8_0= ruleEInt ) ) )? (otherlv_9= 'floorNumber' ( (lv_floorNumber_10_0= ruleEInt ) ) )? (otherlv_11= 'openingTime' ( (lv_openingTime_12_0= ruleEString ) ) )? (otherlv_13= 'closingTime' ( (lv_closingTime_14_0= ruleEString ) ) )? otherlv_15= 'sections' otherlv_16= '{' ( (lv_sections_17_0= ruleSection ) ) (otherlv_18= ',' ( (lv_sections_19_0= ruleSection ) ) )* otherlv_20= '}' otherlv_21= '}'
            {
            otherlv_0=(Token)match(input,22,FOLLOW_5); 

            			newLeafNode(otherlv_0, grammarAccess.getSupermarketAccess().getSupermarketKeyword_0());
            		
            // InternalMyProject.g:390:3: ( (lv_name_1_0= ruleEString ) )
            // InternalMyProject.g:391:4: (lv_name_1_0= ruleEString )
            {
            // InternalMyProject.g:391:4: (lv_name_1_0= ruleEString )
            // InternalMyProject.g:392:5: lv_name_1_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getSupermarketAccess().getNameEStringParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_3);
            lv_name_1_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getSupermarketRule());
            					}
            					set(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.xtext.example.mdeStore.MyProject.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_2=(Token)match(input,12,FOLLOW_16); 

            			newLeafNode(otherlv_2, grammarAccess.getSupermarketAccess().getLeftCurlyBracketKeyword_2());
            		
            // InternalMyProject.g:413:3: (otherlv_3= 'supervisorName' ( (lv_supervisorName_4_0= ruleEString ) ) )?
            int alt7=2;
            int LA7_0 = input.LA(1);

            if ( (LA7_0==23) ) {
                alt7=1;
            }
            switch (alt7) {
                case 1 :
                    // InternalMyProject.g:414:4: otherlv_3= 'supervisorName' ( (lv_supervisorName_4_0= ruleEString ) )
                    {
                    otherlv_3=(Token)match(input,23,FOLLOW_5); 

                    				newLeafNode(otherlv_3, grammarAccess.getSupermarketAccess().getSupervisorNameKeyword_3_0());
                    			
                    // InternalMyProject.g:418:4: ( (lv_supervisorName_4_0= ruleEString ) )
                    // InternalMyProject.g:419:5: (lv_supervisorName_4_0= ruleEString )
                    {
                    // InternalMyProject.g:419:5: (lv_supervisorName_4_0= ruleEString )
                    // InternalMyProject.g:420:6: lv_supervisorName_4_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getSupermarketAccess().getSupervisorNameEStringParserRuleCall_3_1_0());
                    					
                    pushFollow(FOLLOW_17);
                    lv_supervisorName_4_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getSupermarketRule());
                    						}
                    						set(
                    							current,
                    							"supervisorName",
                    							lv_supervisorName_4_0,
                    							"org.xtext.example.mdeStore.MyProject.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalMyProject.g:438:3: (otherlv_5= 'employeeAmount' ( (lv_employeeAmount_6_0= ruleEInt ) ) )?
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( (LA8_0==24) ) {
                alt8=1;
            }
            switch (alt8) {
                case 1 :
                    // InternalMyProject.g:439:4: otherlv_5= 'employeeAmount' ( (lv_employeeAmount_6_0= ruleEInt ) )
                    {
                    otherlv_5=(Token)match(input,24,FOLLOW_18); 

                    				newLeafNode(otherlv_5, grammarAccess.getSupermarketAccess().getEmployeeAmountKeyword_4_0());
                    			
                    // InternalMyProject.g:443:4: ( (lv_employeeAmount_6_0= ruleEInt ) )
                    // InternalMyProject.g:444:5: (lv_employeeAmount_6_0= ruleEInt )
                    {
                    // InternalMyProject.g:444:5: (lv_employeeAmount_6_0= ruleEInt )
                    // InternalMyProject.g:445:6: lv_employeeAmount_6_0= ruleEInt
                    {

                    						newCompositeNode(grammarAccess.getSupermarketAccess().getEmployeeAmountEIntParserRuleCall_4_1_0());
                    					
                    pushFollow(FOLLOW_19);
                    lv_employeeAmount_6_0=ruleEInt();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getSupermarketRule());
                    						}
                    						set(
                    							current,
                    							"employeeAmount",
                    							lv_employeeAmount_6_0,
                    							"org.xtext.example.mdeStore.MyProject.EInt");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalMyProject.g:463:3: (otherlv_7= 'managerAmount' ( (lv_managerAmount_8_0= ruleEInt ) ) )?
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( (LA9_0==25) ) {
                alt9=1;
            }
            switch (alt9) {
                case 1 :
                    // InternalMyProject.g:464:4: otherlv_7= 'managerAmount' ( (lv_managerAmount_8_0= ruleEInt ) )
                    {
                    otherlv_7=(Token)match(input,25,FOLLOW_18); 

                    				newLeafNode(otherlv_7, grammarAccess.getSupermarketAccess().getManagerAmountKeyword_5_0());
                    			
                    // InternalMyProject.g:468:4: ( (lv_managerAmount_8_0= ruleEInt ) )
                    // InternalMyProject.g:469:5: (lv_managerAmount_8_0= ruleEInt )
                    {
                    // InternalMyProject.g:469:5: (lv_managerAmount_8_0= ruleEInt )
                    // InternalMyProject.g:470:6: lv_managerAmount_8_0= ruleEInt
                    {

                    						newCompositeNode(grammarAccess.getSupermarketAccess().getManagerAmountEIntParserRuleCall_5_1_0());
                    					
                    pushFollow(FOLLOW_20);
                    lv_managerAmount_8_0=ruleEInt();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getSupermarketRule());
                    						}
                    						set(
                    							current,
                    							"managerAmount",
                    							lv_managerAmount_8_0,
                    							"org.xtext.example.mdeStore.MyProject.EInt");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalMyProject.g:488:3: (otherlv_9= 'floorNumber' ( (lv_floorNumber_10_0= ruleEInt ) ) )?
            int alt10=2;
            int LA10_0 = input.LA(1);

            if ( (LA10_0==26) ) {
                alt10=1;
            }
            switch (alt10) {
                case 1 :
                    // InternalMyProject.g:489:4: otherlv_9= 'floorNumber' ( (lv_floorNumber_10_0= ruleEInt ) )
                    {
                    otherlv_9=(Token)match(input,26,FOLLOW_18); 

                    				newLeafNode(otherlv_9, grammarAccess.getSupermarketAccess().getFloorNumberKeyword_6_0());
                    			
                    // InternalMyProject.g:493:4: ( (lv_floorNumber_10_0= ruleEInt ) )
                    // InternalMyProject.g:494:5: (lv_floorNumber_10_0= ruleEInt )
                    {
                    // InternalMyProject.g:494:5: (lv_floorNumber_10_0= ruleEInt )
                    // InternalMyProject.g:495:6: lv_floorNumber_10_0= ruleEInt
                    {

                    						newCompositeNode(grammarAccess.getSupermarketAccess().getFloorNumberEIntParserRuleCall_6_1_0());
                    					
                    pushFollow(FOLLOW_21);
                    lv_floorNumber_10_0=ruleEInt();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getSupermarketRule());
                    						}
                    						set(
                    							current,
                    							"floorNumber",
                    							lv_floorNumber_10_0,
                    							"org.xtext.example.mdeStore.MyProject.EInt");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalMyProject.g:513:3: (otherlv_11= 'openingTime' ( (lv_openingTime_12_0= ruleEString ) ) )?
            int alt11=2;
            int LA11_0 = input.LA(1);

            if ( (LA11_0==27) ) {
                alt11=1;
            }
            switch (alt11) {
                case 1 :
                    // InternalMyProject.g:514:4: otherlv_11= 'openingTime' ( (lv_openingTime_12_0= ruleEString ) )
                    {
                    otherlv_11=(Token)match(input,27,FOLLOW_5); 

                    				newLeafNode(otherlv_11, grammarAccess.getSupermarketAccess().getOpeningTimeKeyword_7_0());
                    			
                    // InternalMyProject.g:518:4: ( (lv_openingTime_12_0= ruleEString ) )
                    // InternalMyProject.g:519:5: (lv_openingTime_12_0= ruleEString )
                    {
                    // InternalMyProject.g:519:5: (lv_openingTime_12_0= ruleEString )
                    // InternalMyProject.g:520:6: lv_openingTime_12_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getSupermarketAccess().getOpeningTimeEStringParserRuleCall_7_1_0());
                    					
                    pushFollow(FOLLOW_22);
                    lv_openingTime_12_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getSupermarketRule());
                    						}
                    						set(
                    							current,
                    							"openingTime",
                    							lv_openingTime_12_0,
                    							"org.xtext.example.mdeStore.MyProject.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalMyProject.g:538:3: (otherlv_13= 'closingTime' ( (lv_closingTime_14_0= ruleEString ) ) )?
            int alt12=2;
            int LA12_0 = input.LA(1);

            if ( (LA12_0==28) ) {
                alt12=1;
            }
            switch (alt12) {
                case 1 :
                    // InternalMyProject.g:539:4: otherlv_13= 'closingTime' ( (lv_closingTime_14_0= ruleEString ) )
                    {
                    otherlv_13=(Token)match(input,28,FOLLOW_5); 

                    				newLeafNode(otherlv_13, grammarAccess.getSupermarketAccess().getClosingTimeKeyword_8_0());
                    			
                    // InternalMyProject.g:543:4: ( (lv_closingTime_14_0= ruleEString ) )
                    // InternalMyProject.g:544:5: (lv_closingTime_14_0= ruleEString )
                    {
                    // InternalMyProject.g:544:5: (lv_closingTime_14_0= ruleEString )
                    // InternalMyProject.g:545:6: lv_closingTime_14_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getSupermarketAccess().getClosingTimeEStringParserRuleCall_8_1_0());
                    					
                    pushFollow(FOLLOW_23);
                    lv_closingTime_14_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getSupermarketRule());
                    						}
                    						set(
                    							current,
                    							"closingTime",
                    							lv_closingTime_14_0,
                    							"org.xtext.example.mdeStore.MyProject.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_15=(Token)match(input,29,FOLLOW_3); 

            			newLeafNode(otherlv_15, grammarAccess.getSupermarketAccess().getSectionsKeyword_9());
            		
            otherlv_16=(Token)match(input,12,FOLLOW_24); 

            			newLeafNode(otherlv_16, grammarAccess.getSupermarketAccess().getLeftCurlyBracketKeyword_10());
            		
            // InternalMyProject.g:571:3: ( (lv_sections_17_0= ruleSection ) )
            // InternalMyProject.g:572:4: (lv_sections_17_0= ruleSection )
            {
            // InternalMyProject.g:572:4: (lv_sections_17_0= ruleSection )
            // InternalMyProject.g:573:5: lv_sections_17_0= ruleSection
            {

            					newCompositeNode(grammarAccess.getSupermarketAccess().getSectionsSectionParserRuleCall_11_0());
            				
            pushFollow(FOLLOW_10);
            lv_sections_17_0=ruleSection();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getSupermarketRule());
            					}
            					add(
            						current,
            						"sections",
            						lv_sections_17_0,
            						"org.xtext.example.mdeStore.MyProject.Section");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalMyProject.g:590:3: (otherlv_18= ',' ( (lv_sections_19_0= ruleSection ) ) )*
            loop13:
            do {
                int alt13=2;
                int LA13_0 = input.LA(1);

                if ( (LA13_0==17) ) {
                    alt13=1;
                }


                switch (alt13) {
            	case 1 :
            	    // InternalMyProject.g:591:4: otherlv_18= ',' ( (lv_sections_19_0= ruleSection ) )
            	    {
            	    otherlv_18=(Token)match(input,17,FOLLOW_24); 

            	    				newLeafNode(otherlv_18, grammarAccess.getSupermarketAccess().getCommaKeyword_12_0());
            	    			
            	    // InternalMyProject.g:595:4: ( (lv_sections_19_0= ruleSection ) )
            	    // InternalMyProject.g:596:5: (lv_sections_19_0= ruleSection )
            	    {
            	    // InternalMyProject.g:596:5: (lv_sections_19_0= ruleSection )
            	    // InternalMyProject.g:597:6: lv_sections_19_0= ruleSection
            	    {

            	    						newCompositeNode(grammarAccess.getSupermarketAccess().getSectionsSectionParserRuleCall_12_1_0());
            	    					
            	    pushFollow(FOLLOW_10);
            	    lv_sections_19_0=ruleSection();

            	    state._fsp--;


            	    						if (current==null) {
            	    							current = createModelElementForParent(grammarAccess.getSupermarketRule());
            	    						}
            	    						add(
            	    							current,
            	    							"sections",
            	    							lv_sections_19_0,
            	    							"org.xtext.example.mdeStore.MyProject.Section");
            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop13;
                }
            } while (true);

            otherlv_20=(Token)match(input,18,FOLLOW_11); 

            			newLeafNode(otherlv_20, grammarAccess.getSupermarketAccess().getRightCurlyBracketKeyword_13());
            		
            otherlv_21=(Token)match(input,18,FOLLOW_2); 

            			newLeafNode(otherlv_21, grammarAccess.getSupermarketAccess().getRightCurlyBracketKeyword_14());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSupermarket"


    // $ANTLR start "entryRuleClothingStore"
    // InternalMyProject.g:627:1: entryRuleClothingStore returns [EObject current=null] : iv_ruleClothingStore= ruleClothingStore EOF ;
    public final EObject entryRuleClothingStore() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleClothingStore = null;


        try {
            // InternalMyProject.g:627:54: (iv_ruleClothingStore= ruleClothingStore EOF )
            // InternalMyProject.g:628:2: iv_ruleClothingStore= ruleClothingStore EOF
            {
             newCompositeNode(grammarAccess.getClothingStoreRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleClothingStore=ruleClothingStore();

            state._fsp--;

             current =iv_ruleClothingStore; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleClothingStore"


    // $ANTLR start "ruleClothingStore"
    // InternalMyProject.g:634:1: ruleClothingStore returns [EObject current=null] : ( () otherlv_1= 'ClothingStore' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' (otherlv_4= 'supervisorName' ( (lv_supervisorName_5_0= ruleEString ) ) )? (otherlv_6= 'employeeAmount' ( (lv_employeeAmount_7_0= ruleEInt ) ) )? (otherlv_8= 'managerAmount' ( (lv_managerAmount_9_0= ruleEInt ) ) )? (otherlv_10= 'floorNumber' ( (lv_floorNumber_11_0= ruleEInt ) ) )? (otherlv_12= 'type' ( (lv_type_13_0= ruleclothingType ) ) )? otherlv_14= '}' ) ;
    public final EObject ruleClothingStore() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        Token otherlv_8=null;
        Token otherlv_10=null;
        Token otherlv_12=null;
        Token otherlv_14=null;
        AntlrDatatypeRuleToken lv_name_2_0 = null;

        AntlrDatatypeRuleToken lv_supervisorName_5_0 = null;

        AntlrDatatypeRuleToken lv_employeeAmount_7_0 = null;

        AntlrDatatypeRuleToken lv_managerAmount_9_0 = null;

        AntlrDatatypeRuleToken lv_floorNumber_11_0 = null;

        Enumerator lv_type_13_0 = null;



        	enterRule();

        try {
            // InternalMyProject.g:640:2: ( ( () otherlv_1= 'ClothingStore' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' (otherlv_4= 'supervisorName' ( (lv_supervisorName_5_0= ruleEString ) ) )? (otherlv_6= 'employeeAmount' ( (lv_employeeAmount_7_0= ruleEInt ) ) )? (otherlv_8= 'managerAmount' ( (lv_managerAmount_9_0= ruleEInt ) ) )? (otherlv_10= 'floorNumber' ( (lv_floorNumber_11_0= ruleEInt ) ) )? (otherlv_12= 'type' ( (lv_type_13_0= ruleclothingType ) ) )? otherlv_14= '}' ) )
            // InternalMyProject.g:641:2: ( () otherlv_1= 'ClothingStore' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' (otherlv_4= 'supervisorName' ( (lv_supervisorName_5_0= ruleEString ) ) )? (otherlv_6= 'employeeAmount' ( (lv_employeeAmount_7_0= ruleEInt ) ) )? (otherlv_8= 'managerAmount' ( (lv_managerAmount_9_0= ruleEInt ) ) )? (otherlv_10= 'floorNumber' ( (lv_floorNumber_11_0= ruleEInt ) ) )? (otherlv_12= 'type' ( (lv_type_13_0= ruleclothingType ) ) )? otherlv_14= '}' )
            {
            // InternalMyProject.g:641:2: ( () otherlv_1= 'ClothingStore' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' (otherlv_4= 'supervisorName' ( (lv_supervisorName_5_0= ruleEString ) ) )? (otherlv_6= 'employeeAmount' ( (lv_employeeAmount_7_0= ruleEInt ) ) )? (otherlv_8= 'managerAmount' ( (lv_managerAmount_9_0= ruleEInt ) ) )? (otherlv_10= 'floorNumber' ( (lv_floorNumber_11_0= ruleEInt ) ) )? (otherlv_12= 'type' ( (lv_type_13_0= ruleclothingType ) ) )? otherlv_14= '}' )
            // InternalMyProject.g:642:3: () otherlv_1= 'ClothingStore' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' (otherlv_4= 'supervisorName' ( (lv_supervisorName_5_0= ruleEString ) ) )? (otherlv_6= 'employeeAmount' ( (lv_employeeAmount_7_0= ruleEInt ) ) )? (otherlv_8= 'managerAmount' ( (lv_managerAmount_9_0= ruleEInt ) ) )? (otherlv_10= 'floorNumber' ( (lv_floorNumber_11_0= ruleEInt ) ) )? (otherlv_12= 'type' ( (lv_type_13_0= ruleclothingType ) ) )? otherlv_14= '}'
            {
            // InternalMyProject.g:642:3: ()
            // InternalMyProject.g:643:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getClothingStoreAccess().getClothingStoreAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,30,FOLLOW_5); 

            			newLeafNode(otherlv_1, grammarAccess.getClothingStoreAccess().getClothingStoreKeyword_1());
            		
            // InternalMyProject.g:653:3: ( (lv_name_2_0= ruleEString ) )
            // InternalMyProject.g:654:4: (lv_name_2_0= ruleEString )
            {
            // InternalMyProject.g:654:4: (lv_name_2_0= ruleEString )
            // InternalMyProject.g:655:5: lv_name_2_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getClothingStoreAccess().getNameEStringParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_3);
            lv_name_2_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getClothingStoreRule());
            					}
            					set(
            						current,
            						"name",
            						lv_name_2_0,
            						"org.xtext.example.mdeStore.MyProject.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_3=(Token)match(input,12,FOLLOW_25); 

            			newLeafNode(otherlv_3, grammarAccess.getClothingStoreAccess().getLeftCurlyBracketKeyword_3());
            		
            // InternalMyProject.g:676:3: (otherlv_4= 'supervisorName' ( (lv_supervisorName_5_0= ruleEString ) ) )?
            int alt14=2;
            int LA14_0 = input.LA(1);

            if ( (LA14_0==23) ) {
                alt14=1;
            }
            switch (alt14) {
                case 1 :
                    // InternalMyProject.g:677:4: otherlv_4= 'supervisorName' ( (lv_supervisorName_5_0= ruleEString ) )
                    {
                    otherlv_4=(Token)match(input,23,FOLLOW_5); 

                    				newLeafNode(otherlv_4, grammarAccess.getClothingStoreAccess().getSupervisorNameKeyword_4_0());
                    			
                    // InternalMyProject.g:681:4: ( (lv_supervisorName_5_0= ruleEString ) )
                    // InternalMyProject.g:682:5: (lv_supervisorName_5_0= ruleEString )
                    {
                    // InternalMyProject.g:682:5: (lv_supervisorName_5_0= ruleEString )
                    // InternalMyProject.g:683:6: lv_supervisorName_5_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getClothingStoreAccess().getSupervisorNameEStringParserRuleCall_4_1_0());
                    					
                    pushFollow(FOLLOW_26);
                    lv_supervisorName_5_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getClothingStoreRule());
                    						}
                    						set(
                    							current,
                    							"supervisorName",
                    							lv_supervisorName_5_0,
                    							"org.xtext.example.mdeStore.MyProject.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalMyProject.g:701:3: (otherlv_6= 'employeeAmount' ( (lv_employeeAmount_7_0= ruleEInt ) ) )?
            int alt15=2;
            int LA15_0 = input.LA(1);

            if ( (LA15_0==24) ) {
                alt15=1;
            }
            switch (alt15) {
                case 1 :
                    // InternalMyProject.g:702:4: otherlv_6= 'employeeAmount' ( (lv_employeeAmount_7_0= ruleEInt ) )
                    {
                    otherlv_6=(Token)match(input,24,FOLLOW_18); 

                    				newLeafNode(otherlv_6, grammarAccess.getClothingStoreAccess().getEmployeeAmountKeyword_5_0());
                    			
                    // InternalMyProject.g:706:4: ( (lv_employeeAmount_7_0= ruleEInt ) )
                    // InternalMyProject.g:707:5: (lv_employeeAmount_7_0= ruleEInt )
                    {
                    // InternalMyProject.g:707:5: (lv_employeeAmount_7_0= ruleEInt )
                    // InternalMyProject.g:708:6: lv_employeeAmount_7_0= ruleEInt
                    {

                    						newCompositeNode(grammarAccess.getClothingStoreAccess().getEmployeeAmountEIntParserRuleCall_5_1_0());
                    					
                    pushFollow(FOLLOW_27);
                    lv_employeeAmount_7_0=ruleEInt();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getClothingStoreRule());
                    						}
                    						set(
                    							current,
                    							"employeeAmount",
                    							lv_employeeAmount_7_0,
                    							"org.xtext.example.mdeStore.MyProject.EInt");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalMyProject.g:726:3: (otherlv_8= 'managerAmount' ( (lv_managerAmount_9_0= ruleEInt ) ) )?
            int alt16=2;
            int LA16_0 = input.LA(1);

            if ( (LA16_0==25) ) {
                alt16=1;
            }
            switch (alt16) {
                case 1 :
                    // InternalMyProject.g:727:4: otherlv_8= 'managerAmount' ( (lv_managerAmount_9_0= ruleEInt ) )
                    {
                    otherlv_8=(Token)match(input,25,FOLLOW_18); 

                    				newLeafNode(otherlv_8, grammarAccess.getClothingStoreAccess().getManagerAmountKeyword_6_0());
                    			
                    // InternalMyProject.g:731:4: ( (lv_managerAmount_9_0= ruleEInt ) )
                    // InternalMyProject.g:732:5: (lv_managerAmount_9_0= ruleEInt )
                    {
                    // InternalMyProject.g:732:5: (lv_managerAmount_9_0= ruleEInt )
                    // InternalMyProject.g:733:6: lv_managerAmount_9_0= ruleEInt
                    {

                    						newCompositeNode(grammarAccess.getClothingStoreAccess().getManagerAmountEIntParserRuleCall_6_1_0());
                    					
                    pushFollow(FOLLOW_28);
                    lv_managerAmount_9_0=ruleEInt();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getClothingStoreRule());
                    						}
                    						set(
                    							current,
                    							"managerAmount",
                    							lv_managerAmount_9_0,
                    							"org.xtext.example.mdeStore.MyProject.EInt");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalMyProject.g:751:3: (otherlv_10= 'floorNumber' ( (lv_floorNumber_11_0= ruleEInt ) ) )?
            int alt17=2;
            int LA17_0 = input.LA(1);

            if ( (LA17_0==26) ) {
                alt17=1;
            }
            switch (alt17) {
                case 1 :
                    // InternalMyProject.g:752:4: otherlv_10= 'floorNumber' ( (lv_floorNumber_11_0= ruleEInt ) )
                    {
                    otherlv_10=(Token)match(input,26,FOLLOW_18); 

                    				newLeafNode(otherlv_10, grammarAccess.getClothingStoreAccess().getFloorNumberKeyword_7_0());
                    			
                    // InternalMyProject.g:756:4: ( (lv_floorNumber_11_0= ruleEInt ) )
                    // InternalMyProject.g:757:5: (lv_floorNumber_11_0= ruleEInt )
                    {
                    // InternalMyProject.g:757:5: (lv_floorNumber_11_0= ruleEInt )
                    // InternalMyProject.g:758:6: lv_floorNumber_11_0= ruleEInt
                    {

                    						newCompositeNode(grammarAccess.getClothingStoreAccess().getFloorNumberEIntParserRuleCall_7_1_0());
                    					
                    pushFollow(FOLLOW_29);
                    lv_floorNumber_11_0=ruleEInt();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getClothingStoreRule());
                    						}
                    						set(
                    							current,
                    							"floorNumber",
                    							lv_floorNumber_11_0,
                    							"org.xtext.example.mdeStore.MyProject.EInt");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalMyProject.g:776:3: (otherlv_12= 'type' ( (lv_type_13_0= ruleclothingType ) ) )?
            int alt18=2;
            int LA18_0 = input.LA(1);

            if ( (LA18_0==31) ) {
                alt18=1;
            }
            switch (alt18) {
                case 1 :
                    // InternalMyProject.g:777:4: otherlv_12= 'type' ( (lv_type_13_0= ruleclothingType ) )
                    {
                    otherlv_12=(Token)match(input,31,FOLLOW_30); 

                    				newLeafNode(otherlv_12, grammarAccess.getClothingStoreAccess().getTypeKeyword_8_0());
                    			
                    // InternalMyProject.g:781:4: ( (lv_type_13_0= ruleclothingType ) )
                    // InternalMyProject.g:782:5: (lv_type_13_0= ruleclothingType )
                    {
                    // InternalMyProject.g:782:5: (lv_type_13_0= ruleclothingType )
                    // InternalMyProject.g:783:6: lv_type_13_0= ruleclothingType
                    {

                    						newCompositeNode(grammarAccess.getClothingStoreAccess().getTypeClothingTypeEnumRuleCall_8_1_0());
                    					
                    pushFollow(FOLLOW_11);
                    lv_type_13_0=ruleclothingType();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getClothingStoreRule());
                    						}
                    						set(
                    							current,
                    							"type",
                    							lv_type_13_0,
                    							"org.xtext.example.mdeStore.MyProject.clothingType");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_14=(Token)match(input,18,FOLLOW_2); 

            			newLeafNode(otherlv_14, grammarAccess.getClothingStoreAccess().getRightCurlyBracketKeyword_9());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleClothingStore"


    // $ANTLR start "entryRuleEInt"
    // InternalMyProject.g:809:1: entryRuleEInt returns [String current=null] : iv_ruleEInt= ruleEInt EOF ;
    public final String entryRuleEInt() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleEInt = null;


        try {
            // InternalMyProject.g:809:44: (iv_ruleEInt= ruleEInt EOF )
            // InternalMyProject.g:810:2: iv_ruleEInt= ruleEInt EOF
            {
             newCompositeNode(grammarAccess.getEIntRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEInt=ruleEInt();

            state._fsp--;

             current =iv_ruleEInt.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEInt"


    // $ANTLR start "ruleEInt"
    // InternalMyProject.g:816:1: ruleEInt returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : ( (kw= '-' )? this_INT_1= RULE_INT ) ;
    public final AntlrDatatypeRuleToken ruleEInt() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;
        Token this_INT_1=null;


        	enterRule();

        try {
            // InternalMyProject.g:822:2: ( ( (kw= '-' )? this_INT_1= RULE_INT ) )
            // InternalMyProject.g:823:2: ( (kw= '-' )? this_INT_1= RULE_INT )
            {
            // InternalMyProject.g:823:2: ( (kw= '-' )? this_INT_1= RULE_INT )
            // InternalMyProject.g:824:3: (kw= '-' )? this_INT_1= RULE_INT
            {
            // InternalMyProject.g:824:3: (kw= '-' )?
            int alt19=2;
            int LA19_0 = input.LA(1);

            if ( (LA19_0==32) ) {
                alt19=1;
            }
            switch (alt19) {
                case 1 :
                    // InternalMyProject.g:825:4: kw= '-'
                    {
                    kw=(Token)match(input,32,FOLLOW_31); 

                    				current.merge(kw);
                    				newLeafNode(kw, grammarAccess.getEIntAccess().getHyphenMinusKeyword_0());
                    			

                    }
                    break;

            }

            this_INT_1=(Token)match(input,RULE_INT,FOLLOW_2); 

            			current.merge(this_INT_1);
            		

            			newLeafNode(this_INT_1, grammarAccess.getEIntAccess().getINTTerminalRuleCall_1());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEInt"


    // $ANTLR start "entryRuleSection"
    // InternalMyProject.g:842:1: entryRuleSection returns [EObject current=null] : iv_ruleSection= ruleSection EOF ;
    public final EObject entryRuleSection() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSection = null;


        try {
            // InternalMyProject.g:842:48: (iv_ruleSection= ruleSection EOF )
            // InternalMyProject.g:843:2: iv_ruleSection= ruleSection EOF
            {
             newCompositeNode(grammarAccess.getSectionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleSection=ruleSection();

            state._fsp--;

             current =iv_ruleSection; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSection"


    // $ANTLR start "ruleSection"
    // InternalMyProject.g:849:1: ruleSection returns [EObject current=null] : ( () otherlv_1= 'Section' otherlv_2= '{' (otherlv_3= 'sections' ( (lv_sections_4_0= rulesectionType ) ) )? otherlv_5= '}' ) ;
    public final EObject ruleSection() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        Enumerator lv_sections_4_0 = null;



        	enterRule();

        try {
            // InternalMyProject.g:855:2: ( ( () otherlv_1= 'Section' otherlv_2= '{' (otherlv_3= 'sections' ( (lv_sections_4_0= rulesectionType ) ) )? otherlv_5= '}' ) )
            // InternalMyProject.g:856:2: ( () otherlv_1= 'Section' otherlv_2= '{' (otherlv_3= 'sections' ( (lv_sections_4_0= rulesectionType ) ) )? otherlv_5= '}' )
            {
            // InternalMyProject.g:856:2: ( () otherlv_1= 'Section' otherlv_2= '{' (otherlv_3= 'sections' ( (lv_sections_4_0= rulesectionType ) ) )? otherlv_5= '}' )
            // InternalMyProject.g:857:3: () otherlv_1= 'Section' otherlv_2= '{' (otherlv_3= 'sections' ( (lv_sections_4_0= rulesectionType ) ) )? otherlv_5= '}'
            {
            // InternalMyProject.g:857:3: ()
            // InternalMyProject.g:858:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getSectionAccess().getSectionAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,33,FOLLOW_3); 

            			newLeafNode(otherlv_1, grammarAccess.getSectionAccess().getSectionKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_32); 

            			newLeafNode(otherlv_2, grammarAccess.getSectionAccess().getLeftCurlyBracketKeyword_2());
            		
            // InternalMyProject.g:872:3: (otherlv_3= 'sections' ( (lv_sections_4_0= rulesectionType ) ) )?
            int alt20=2;
            int LA20_0 = input.LA(1);

            if ( (LA20_0==29) ) {
                alt20=1;
            }
            switch (alt20) {
                case 1 :
                    // InternalMyProject.g:873:4: otherlv_3= 'sections' ( (lv_sections_4_0= rulesectionType ) )
                    {
                    otherlv_3=(Token)match(input,29,FOLLOW_33); 

                    				newLeafNode(otherlv_3, grammarAccess.getSectionAccess().getSectionsKeyword_3_0());
                    			
                    // InternalMyProject.g:877:4: ( (lv_sections_4_0= rulesectionType ) )
                    // InternalMyProject.g:878:5: (lv_sections_4_0= rulesectionType )
                    {
                    // InternalMyProject.g:878:5: (lv_sections_4_0= rulesectionType )
                    // InternalMyProject.g:879:6: lv_sections_4_0= rulesectionType
                    {

                    						newCompositeNode(grammarAccess.getSectionAccess().getSectionsSectionTypeEnumRuleCall_3_1_0());
                    					
                    pushFollow(FOLLOW_11);
                    lv_sections_4_0=rulesectionType();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getSectionRule());
                    						}
                    						set(
                    							current,
                    							"sections",
                    							lv_sections_4_0,
                    							"org.xtext.example.mdeStore.MyProject.sectionType");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_5=(Token)match(input,18,FOLLOW_2); 

            			newLeafNode(otherlv_5, grammarAccess.getSectionAccess().getRightCurlyBracketKeyword_4());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSection"


    // $ANTLR start "rulesectionType"
    // InternalMyProject.g:905:1: rulesectionType returns [Enumerator current=null] : ( (enumLiteral_0= 'freshProduce' ) | (enumLiteral_1= 'freshVegetablesAndFruits' ) | (enumLiteral_2= 'kitchenWare' ) | (enumLiteral_3= 'householdCleaners' ) ) ;
    public final Enumerator rulesectionType() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;


        	enterRule();

        try {
            // InternalMyProject.g:911:2: ( ( (enumLiteral_0= 'freshProduce' ) | (enumLiteral_1= 'freshVegetablesAndFruits' ) | (enumLiteral_2= 'kitchenWare' ) | (enumLiteral_3= 'householdCleaners' ) ) )
            // InternalMyProject.g:912:2: ( (enumLiteral_0= 'freshProduce' ) | (enumLiteral_1= 'freshVegetablesAndFruits' ) | (enumLiteral_2= 'kitchenWare' ) | (enumLiteral_3= 'householdCleaners' ) )
            {
            // InternalMyProject.g:912:2: ( (enumLiteral_0= 'freshProduce' ) | (enumLiteral_1= 'freshVegetablesAndFruits' ) | (enumLiteral_2= 'kitchenWare' ) | (enumLiteral_3= 'householdCleaners' ) )
            int alt21=4;
            switch ( input.LA(1) ) {
            case 34:
                {
                alt21=1;
                }
                break;
            case 35:
                {
                alt21=2;
                }
                break;
            case 36:
                {
                alt21=3;
                }
                break;
            case 37:
                {
                alt21=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 21, 0, input);

                throw nvae;
            }

            switch (alt21) {
                case 1 :
                    // InternalMyProject.g:913:3: (enumLiteral_0= 'freshProduce' )
                    {
                    // InternalMyProject.g:913:3: (enumLiteral_0= 'freshProduce' )
                    // InternalMyProject.g:914:4: enumLiteral_0= 'freshProduce'
                    {
                    enumLiteral_0=(Token)match(input,34,FOLLOW_2); 

                    				current = grammarAccess.getSectionTypeAccess().getFreshProduceEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getSectionTypeAccess().getFreshProduceEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalMyProject.g:921:3: (enumLiteral_1= 'freshVegetablesAndFruits' )
                    {
                    // InternalMyProject.g:921:3: (enumLiteral_1= 'freshVegetablesAndFruits' )
                    // InternalMyProject.g:922:4: enumLiteral_1= 'freshVegetablesAndFruits'
                    {
                    enumLiteral_1=(Token)match(input,35,FOLLOW_2); 

                    				current = grammarAccess.getSectionTypeAccess().getFreshVegetablesAndFruitsEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getSectionTypeAccess().getFreshVegetablesAndFruitsEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalMyProject.g:929:3: (enumLiteral_2= 'kitchenWare' )
                    {
                    // InternalMyProject.g:929:3: (enumLiteral_2= 'kitchenWare' )
                    // InternalMyProject.g:930:4: enumLiteral_2= 'kitchenWare'
                    {
                    enumLiteral_2=(Token)match(input,36,FOLLOW_2); 

                    				current = grammarAccess.getSectionTypeAccess().getKitchenWareEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getSectionTypeAccess().getKitchenWareEnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;
                case 4 :
                    // InternalMyProject.g:937:3: (enumLiteral_3= 'householdCleaners' )
                    {
                    // InternalMyProject.g:937:3: (enumLiteral_3= 'householdCleaners' )
                    // InternalMyProject.g:938:4: enumLiteral_3= 'householdCleaners'
                    {
                    enumLiteral_3=(Token)match(input,37,FOLLOW_2); 

                    				current = grammarAccess.getSectionTypeAccess().getHouseholdCleanersEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_3, grammarAccess.getSectionTypeAccess().getHouseholdCleanersEnumLiteralDeclaration_3());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulesectionType"


    // $ANTLR start "ruleclothingType"
    // InternalMyProject.g:948:1: ruleclothingType returns [Enumerator current=null] : ( (enumLiteral_0= 'men' ) | (enumLiteral_1= 'women' ) | (enumLiteral_2= 'kids' ) | (enumLiteral_3= 'shoes' ) ) ;
    public final Enumerator ruleclothingType() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;


        	enterRule();

        try {
            // InternalMyProject.g:954:2: ( ( (enumLiteral_0= 'men' ) | (enumLiteral_1= 'women' ) | (enumLiteral_2= 'kids' ) | (enumLiteral_3= 'shoes' ) ) )
            // InternalMyProject.g:955:2: ( (enumLiteral_0= 'men' ) | (enumLiteral_1= 'women' ) | (enumLiteral_2= 'kids' ) | (enumLiteral_3= 'shoes' ) )
            {
            // InternalMyProject.g:955:2: ( (enumLiteral_0= 'men' ) | (enumLiteral_1= 'women' ) | (enumLiteral_2= 'kids' ) | (enumLiteral_3= 'shoes' ) )
            int alt22=4;
            switch ( input.LA(1) ) {
            case 38:
                {
                alt22=1;
                }
                break;
            case 39:
                {
                alt22=2;
                }
                break;
            case 40:
                {
                alt22=3;
                }
                break;
            case 41:
                {
                alt22=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 22, 0, input);

                throw nvae;
            }

            switch (alt22) {
                case 1 :
                    // InternalMyProject.g:956:3: (enumLiteral_0= 'men' )
                    {
                    // InternalMyProject.g:956:3: (enumLiteral_0= 'men' )
                    // InternalMyProject.g:957:4: enumLiteral_0= 'men'
                    {
                    enumLiteral_0=(Token)match(input,38,FOLLOW_2); 

                    				current = grammarAccess.getClothingTypeAccess().getMenEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getClothingTypeAccess().getMenEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalMyProject.g:964:3: (enumLiteral_1= 'women' )
                    {
                    // InternalMyProject.g:964:3: (enumLiteral_1= 'women' )
                    // InternalMyProject.g:965:4: enumLiteral_1= 'women'
                    {
                    enumLiteral_1=(Token)match(input,39,FOLLOW_2); 

                    				current = grammarAccess.getClothingTypeAccess().getWomenEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getClothingTypeAccess().getWomenEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalMyProject.g:972:3: (enumLiteral_2= 'kids' )
                    {
                    // InternalMyProject.g:972:3: (enumLiteral_2= 'kids' )
                    // InternalMyProject.g:973:4: enumLiteral_2= 'kids'
                    {
                    enumLiteral_2=(Token)match(input,40,FOLLOW_2); 

                    				current = grammarAccess.getClothingTypeAccess().getKidsEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getClothingTypeAccess().getKidsEnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;
                case 4 :
                    // InternalMyProject.g:980:3: (enumLiteral_3= 'shoes' )
                    {
                    // InternalMyProject.g:980:3: (enumLiteral_3= 'shoes' )
                    // InternalMyProject.g:981:4: enumLiteral_3= 'shoes'
                    {
                    enumLiteral_3=(Token)match(input,41,FOLLOW_2); 

                    				current = grammarAccess.getClothingTypeAccess().getShoesEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_3, grammarAccess.getClothingTypeAccess().getShoesEnumLiteralDeclaration_3());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleclothingType"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x000000000001E000L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000000030L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x000000000001C000L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000000018000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000060000L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000040000L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000000400000L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000000200000L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000040000000L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x000000003F800000L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x000000003F000000L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000000100000040L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x000000003E000000L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x000000003C000000L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x0000000038000000L});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x0000000030000000L});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x0000000020000000L});
    public static final BitSet FOLLOW_24 = new BitSet(new long[]{0x0000000200000000L});
    public static final BitSet FOLLOW_25 = new BitSet(new long[]{0x0000000087840000L});
    public static final BitSet FOLLOW_26 = new BitSet(new long[]{0x0000000087040000L});
    public static final BitSet FOLLOW_27 = new BitSet(new long[]{0x0000000086040000L});
    public static final BitSet FOLLOW_28 = new BitSet(new long[]{0x0000000084040000L});
    public static final BitSet FOLLOW_29 = new BitSet(new long[]{0x0000000080040000L});
    public static final BitSet FOLLOW_30 = new BitSet(new long[]{0x000003C000000000L});
    public static final BitSet FOLLOW_31 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_32 = new BitSet(new long[]{0x0000000020040000L});
    public static final BitSet FOLLOW_33 = new BitSet(new long[]{0x0000003C00000000L});

}