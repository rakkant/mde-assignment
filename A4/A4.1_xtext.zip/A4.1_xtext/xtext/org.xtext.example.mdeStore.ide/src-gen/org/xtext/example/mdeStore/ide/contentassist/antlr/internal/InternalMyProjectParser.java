package org.xtext.example.mdeStore.ide.contentassist.antlr.internal;

import java.io.InputStream;
import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.AbstractInternalContentAssistParser;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.DFA;
import org.xtext.example.mdeStore.services.MyProjectGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalMyProjectParser extends AbstractInternalContentAssistParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_STRING", "RULE_ID", "RULE_INT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'freshProduce'", "'freshVegetablesAndFruits'", "'kitchenWare'", "'householdCleaners'", "'men'", "'women'", "'kids'", "'shoes'", "'ShoppingMall'", "'{'", "'shops'", "'}'", "'companyName'", "'ceo'", "'location'", "','", "'Shop'", "'supermarket'", "'clothingStores'", "'Supermarket'", "'sections'", "'supervisorName'", "'employeeAmount'", "'managerAmount'", "'floorNumber'", "'openingTime'", "'closingTime'", "'ClothingStore'", "'type'", "'-'", "'Section'"
    };
    public static final int RULE_STRING=4;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__37=37;
    public static final int T__16=16;
    public static final int T__38=38;
    public static final int T__17=17;
    public static final int T__39=39;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int T__33=33;
    public static final int T__12=12;
    public static final int T__34=34;
    public static final int T__13=13;
    public static final int T__35=35;
    public static final int T__14=14;
    public static final int T__36=36;
    public static final int EOF=-1;
    public static final int T__30=30;
    public static final int T__31=31;
    public static final int T__32=32;
    public static final int RULE_ID=5;
    public static final int RULE_WS=9;
    public static final int RULE_ANY_OTHER=10;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int RULE_INT=6;
    public static final int T__29=29;
    public static final int T__22=22;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__23=23;
    public static final int T__24=24;
    public static final int T__25=25;
    public static final int T__40=40;
    public static final int T__41=41;
    public static final int T__20=20;
    public static final int T__21=21;

    // delegates
    // delegators


        public InternalMyProjectParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalMyProjectParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalMyProjectParser.tokenNames; }
    public String getGrammarFileName() { return "InternalMyProject.g"; }


    	private MyProjectGrammarAccess grammarAccess;

    	public void setGrammarAccess(MyProjectGrammarAccess grammarAccess) {
    		this.grammarAccess = grammarAccess;
    	}

    	@Override
    	protected Grammar getGrammar() {
    		return grammarAccess.getGrammar();
    	}

    	@Override
    	protected String getValueForTokenName(String tokenName) {
    		return tokenName;
    	}



    // $ANTLR start "entryRuleShoppingMall"
    // InternalMyProject.g:53:1: entryRuleShoppingMall : ruleShoppingMall EOF ;
    public final void entryRuleShoppingMall() throws RecognitionException {
        try {
            // InternalMyProject.g:54:1: ( ruleShoppingMall EOF )
            // InternalMyProject.g:55:1: ruleShoppingMall EOF
            {
             before(grammarAccess.getShoppingMallRule()); 
            pushFollow(FOLLOW_1);
            ruleShoppingMall();

            state._fsp--;

             after(grammarAccess.getShoppingMallRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleShoppingMall"


    // $ANTLR start "ruleShoppingMall"
    // InternalMyProject.g:62:1: ruleShoppingMall : ( ( rule__ShoppingMall__Group__0 ) ) ;
    public final void ruleShoppingMall() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:66:2: ( ( ( rule__ShoppingMall__Group__0 ) ) )
            // InternalMyProject.g:67:2: ( ( rule__ShoppingMall__Group__0 ) )
            {
            // InternalMyProject.g:67:2: ( ( rule__ShoppingMall__Group__0 ) )
            // InternalMyProject.g:68:3: ( rule__ShoppingMall__Group__0 )
            {
             before(grammarAccess.getShoppingMallAccess().getGroup()); 
            // InternalMyProject.g:69:3: ( rule__ShoppingMall__Group__0 )
            // InternalMyProject.g:69:4: rule__ShoppingMall__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__ShoppingMall__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getShoppingMallAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleShoppingMall"


    // $ANTLR start "entryRuleEString"
    // InternalMyProject.g:78:1: entryRuleEString : ruleEString EOF ;
    public final void entryRuleEString() throws RecognitionException {
        try {
            // InternalMyProject.g:79:1: ( ruleEString EOF )
            // InternalMyProject.g:80:1: ruleEString EOF
            {
             before(grammarAccess.getEStringRule()); 
            pushFollow(FOLLOW_1);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getEStringRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleEString"


    // $ANTLR start "ruleEString"
    // InternalMyProject.g:87:1: ruleEString : ( ( rule__EString__Alternatives ) ) ;
    public final void ruleEString() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:91:2: ( ( ( rule__EString__Alternatives ) ) )
            // InternalMyProject.g:92:2: ( ( rule__EString__Alternatives ) )
            {
            // InternalMyProject.g:92:2: ( ( rule__EString__Alternatives ) )
            // InternalMyProject.g:93:3: ( rule__EString__Alternatives )
            {
             before(grammarAccess.getEStringAccess().getAlternatives()); 
            // InternalMyProject.g:94:3: ( rule__EString__Alternatives )
            // InternalMyProject.g:94:4: rule__EString__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__EString__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getEStringAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleEString"


    // $ANTLR start "entryRuleShop"
    // InternalMyProject.g:103:1: entryRuleShop : ruleShop EOF ;
    public final void entryRuleShop() throws RecognitionException {
        try {
            // InternalMyProject.g:104:1: ( ruleShop EOF )
            // InternalMyProject.g:105:1: ruleShop EOF
            {
             before(grammarAccess.getShopRule()); 
            pushFollow(FOLLOW_1);
            ruleShop();

            state._fsp--;

             after(grammarAccess.getShopRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleShop"


    // $ANTLR start "ruleShop"
    // InternalMyProject.g:112:1: ruleShop : ( ( rule__Shop__Group__0 ) ) ;
    public final void ruleShop() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:116:2: ( ( ( rule__Shop__Group__0 ) ) )
            // InternalMyProject.g:117:2: ( ( rule__Shop__Group__0 ) )
            {
            // InternalMyProject.g:117:2: ( ( rule__Shop__Group__0 ) )
            // InternalMyProject.g:118:3: ( rule__Shop__Group__0 )
            {
             before(grammarAccess.getShopAccess().getGroup()); 
            // InternalMyProject.g:119:3: ( rule__Shop__Group__0 )
            // InternalMyProject.g:119:4: rule__Shop__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Shop__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getShopAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleShop"


    // $ANTLR start "entryRuleSupermarket"
    // InternalMyProject.g:128:1: entryRuleSupermarket : ruleSupermarket EOF ;
    public final void entryRuleSupermarket() throws RecognitionException {
        try {
            // InternalMyProject.g:129:1: ( ruleSupermarket EOF )
            // InternalMyProject.g:130:1: ruleSupermarket EOF
            {
             before(grammarAccess.getSupermarketRule()); 
            pushFollow(FOLLOW_1);
            ruleSupermarket();

            state._fsp--;

             after(grammarAccess.getSupermarketRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleSupermarket"


    // $ANTLR start "ruleSupermarket"
    // InternalMyProject.g:137:1: ruleSupermarket : ( ( rule__Supermarket__Group__0 ) ) ;
    public final void ruleSupermarket() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:141:2: ( ( ( rule__Supermarket__Group__0 ) ) )
            // InternalMyProject.g:142:2: ( ( rule__Supermarket__Group__0 ) )
            {
            // InternalMyProject.g:142:2: ( ( rule__Supermarket__Group__0 ) )
            // InternalMyProject.g:143:3: ( rule__Supermarket__Group__0 )
            {
             before(grammarAccess.getSupermarketAccess().getGroup()); 
            // InternalMyProject.g:144:3: ( rule__Supermarket__Group__0 )
            // InternalMyProject.g:144:4: rule__Supermarket__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Supermarket__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getSupermarketAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleSupermarket"


    // $ANTLR start "entryRuleClothingStore"
    // InternalMyProject.g:153:1: entryRuleClothingStore : ruleClothingStore EOF ;
    public final void entryRuleClothingStore() throws RecognitionException {
        try {
            // InternalMyProject.g:154:1: ( ruleClothingStore EOF )
            // InternalMyProject.g:155:1: ruleClothingStore EOF
            {
             before(grammarAccess.getClothingStoreRule()); 
            pushFollow(FOLLOW_1);
            ruleClothingStore();

            state._fsp--;

             after(grammarAccess.getClothingStoreRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleClothingStore"


    // $ANTLR start "ruleClothingStore"
    // InternalMyProject.g:162:1: ruleClothingStore : ( ( rule__ClothingStore__Group__0 ) ) ;
    public final void ruleClothingStore() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:166:2: ( ( ( rule__ClothingStore__Group__0 ) ) )
            // InternalMyProject.g:167:2: ( ( rule__ClothingStore__Group__0 ) )
            {
            // InternalMyProject.g:167:2: ( ( rule__ClothingStore__Group__0 ) )
            // InternalMyProject.g:168:3: ( rule__ClothingStore__Group__0 )
            {
             before(grammarAccess.getClothingStoreAccess().getGroup()); 
            // InternalMyProject.g:169:3: ( rule__ClothingStore__Group__0 )
            // InternalMyProject.g:169:4: rule__ClothingStore__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__ClothingStore__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getClothingStoreAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleClothingStore"


    // $ANTLR start "entryRuleEInt"
    // InternalMyProject.g:178:1: entryRuleEInt : ruleEInt EOF ;
    public final void entryRuleEInt() throws RecognitionException {
        try {
            // InternalMyProject.g:179:1: ( ruleEInt EOF )
            // InternalMyProject.g:180:1: ruleEInt EOF
            {
             before(grammarAccess.getEIntRule()); 
            pushFollow(FOLLOW_1);
            ruleEInt();

            state._fsp--;

             after(grammarAccess.getEIntRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleEInt"


    // $ANTLR start "ruleEInt"
    // InternalMyProject.g:187:1: ruleEInt : ( ( rule__EInt__Group__0 ) ) ;
    public final void ruleEInt() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:191:2: ( ( ( rule__EInt__Group__0 ) ) )
            // InternalMyProject.g:192:2: ( ( rule__EInt__Group__0 ) )
            {
            // InternalMyProject.g:192:2: ( ( rule__EInt__Group__0 ) )
            // InternalMyProject.g:193:3: ( rule__EInt__Group__0 )
            {
             before(grammarAccess.getEIntAccess().getGroup()); 
            // InternalMyProject.g:194:3: ( rule__EInt__Group__0 )
            // InternalMyProject.g:194:4: rule__EInt__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__EInt__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getEIntAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleEInt"


    // $ANTLR start "entryRuleSection"
    // InternalMyProject.g:203:1: entryRuleSection : ruleSection EOF ;
    public final void entryRuleSection() throws RecognitionException {
        try {
            // InternalMyProject.g:204:1: ( ruleSection EOF )
            // InternalMyProject.g:205:1: ruleSection EOF
            {
             before(grammarAccess.getSectionRule()); 
            pushFollow(FOLLOW_1);
            ruleSection();

            state._fsp--;

             after(grammarAccess.getSectionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleSection"


    // $ANTLR start "ruleSection"
    // InternalMyProject.g:212:1: ruleSection : ( ( rule__Section__Group__0 ) ) ;
    public final void ruleSection() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:216:2: ( ( ( rule__Section__Group__0 ) ) )
            // InternalMyProject.g:217:2: ( ( rule__Section__Group__0 ) )
            {
            // InternalMyProject.g:217:2: ( ( rule__Section__Group__0 ) )
            // InternalMyProject.g:218:3: ( rule__Section__Group__0 )
            {
             before(grammarAccess.getSectionAccess().getGroup()); 
            // InternalMyProject.g:219:3: ( rule__Section__Group__0 )
            // InternalMyProject.g:219:4: rule__Section__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Section__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getSectionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleSection"


    // $ANTLR start "rulesectionType"
    // InternalMyProject.g:228:1: rulesectionType : ( ( rule__SectionType__Alternatives ) ) ;
    public final void rulesectionType() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:232:1: ( ( ( rule__SectionType__Alternatives ) ) )
            // InternalMyProject.g:233:2: ( ( rule__SectionType__Alternatives ) )
            {
            // InternalMyProject.g:233:2: ( ( rule__SectionType__Alternatives ) )
            // InternalMyProject.g:234:3: ( rule__SectionType__Alternatives )
            {
             before(grammarAccess.getSectionTypeAccess().getAlternatives()); 
            // InternalMyProject.g:235:3: ( rule__SectionType__Alternatives )
            // InternalMyProject.g:235:4: rule__SectionType__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__SectionType__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getSectionTypeAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rulesectionType"


    // $ANTLR start "ruleclothingType"
    // InternalMyProject.g:244:1: ruleclothingType : ( ( rule__ClothingType__Alternatives ) ) ;
    public final void ruleclothingType() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:248:1: ( ( ( rule__ClothingType__Alternatives ) ) )
            // InternalMyProject.g:249:2: ( ( rule__ClothingType__Alternatives ) )
            {
            // InternalMyProject.g:249:2: ( ( rule__ClothingType__Alternatives ) )
            // InternalMyProject.g:250:3: ( rule__ClothingType__Alternatives )
            {
             before(grammarAccess.getClothingTypeAccess().getAlternatives()); 
            // InternalMyProject.g:251:3: ( rule__ClothingType__Alternatives )
            // InternalMyProject.g:251:4: rule__ClothingType__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__ClothingType__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getClothingTypeAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleclothingType"


    // $ANTLR start "rule__EString__Alternatives"
    // InternalMyProject.g:259:1: rule__EString__Alternatives : ( ( RULE_STRING ) | ( RULE_ID ) );
    public final void rule__EString__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:263:1: ( ( RULE_STRING ) | ( RULE_ID ) )
            int alt1=2;
            int LA1_0 = input.LA(1);

            if ( (LA1_0==RULE_STRING) ) {
                alt1=1;
            }
            else if ( (LA1_0==RULE_ID) ) {
                alt1=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 1, 0, input);

                throw nvae;
            }
            switch (alt1) {
                case 1 :
                    // InternalMyProject.g:264:2: ( RULE_STRING )
                    {
                    // InternalMyProject.g:264:2: ( RULE_STRING )
                    // InternalMyProject.g:265:3: RULE_STRING
                    {
                     before(grammarAccess.getEStringAccess().getSTRINGTerminalRuleCall_0()); 
                    match(input,RULE_STRING,FOLLOW_2); 
                     after(grammarAccess.getEStringAccess().getSTRINGTerminalRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalMyProject.g:270:2: ( RULE_ID )
                    {
                    // InternalMyProject.g:270:2: ( RULE_ID )
                    // InternalMyProject.g:271:3: RULE_ID
                    {
                     before(grammarAccess.getEStringAccess().getIDTerminalRuleCall_1()); 
                    match(input,RULE_ID,FOLLOW_2); 
                     after(grammarAccess.getEStringAccess().getIDTerminalRuleCall_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EString__Alternatives"


    // $ANTLR start "rule__SectionType__Alternatives"
    // InternalMyProject.g:280:1: rule__SectionType__Alternatives : ( ( ( 'freshProduce' ) ) | ( ( 'freshVegetablesAndFruits' ) ) | ( ( 'kitchenWare' ) ) | ( ( 'householdCleaners' ) ) );
    public final void rule__SectionType__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:284:1: ( ( ( 'freshProduce' ) ) | ( ( 'freshVegetablesAndFruits' ) ) | ( ( 'kitchenWare' ) ) | ( ( 'householdCleaners' ) ) )
            int alt2=4;
            switch ( input.LA(1) ) {
            case 11:
                {
                alt2=1;
                }
                break;
            case 12:
                {
                alt2=2;
                }
                break;
            case 13:
                {
                alt2=3;
                }
                break;
            case 14:
                {
                alt2=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 2, 0, input);

                throw nvae;
            }

            switch (alt2) {
                case 1 :
                    // InternalMyProject.g:285:2: ( ( 'freshProduce' ) )
                    {
                    // InternalMyProject.g:285:2: ( ( 'freshProduce' ) )
                    // InternalMyProject.g:286:3: ( 'freshProduce' )
                    {
                     before(grammarAccess.getSectionTypeAccess().getFreshProduceEnumLiteralDeclaration_0()); 
                    // InternalMyProject.g:287:3: ( 'freshProduce' )
                    // InternalMyProject.g:287:4: 'freshProduce'
                    {
                    match(input,11,FOLLOW_2); 

                    }

                     after(grammarAccess.getSectionTypeAccess().getFreshProduceEnumLiteralDeclaration_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalMyProject.g:291:2: ( ( 'freshVegetablesAndFruits' ) )
                    {
                    // InternalMyProject.g:291:2: ( ( 'freshVegetablesAndFruits' ) )
                    // InternalMyProject.g:292:3: ( 'freshVegetablesAndFruits' )
                    {
                     before(grammarAccess.getSectionTypeAccess().getFreshVegetablesAndFruitsEnumLiteralDeclaration_1()); 
                    // InternalMyProject.g:293:3: ( 'freshVegetablesAndFruits' )
                    // InternalMyProject.g:293:4: 'freshVegetablesAndFruits'
                    {
                    match(input,12,FOLLOW_2); 

                    }

                     after(grammarAccess.getSectionTypeAccess().getFreshVegetablesAndFruitsEnumLiteralDeclaration_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalMyProject.g:297:2: ( ( 'kitchenWare' ) )
                    {
                    // InternalMyProject.g:297:2: ( ( 'kitchenWare' ) )
                    // InternalMyProject.g:298:3: ( 'kitchenWare' )
                    {
                     before(grammarAccess.getSectionTypeAccess().getKitchenWareEnumLiteralDeclaration_2()); 
                    // InternalMyProject.g:299:3: ( 'kitchenWare' )
                    // InternalMyProject.g:299:4: 'kitchenWare'
                    {
                    match(input,13,FOLLOW_2); 

                    }

                     after(grammarAccess.getSectionTypeAccess().getKitchenWareEnumLiteralDeclaration_2()); 

                    }


                    }
                    break;
                case 4 :
                    // InternalMyProject.g:303:2: ( ( 'householdCleaners' ) )
                    {
                    // InternalMyProject.g:303:2: ( ( 'householdCleaners' ) )
                    // InternalMyProject.g:304:3: ( 'householdCleaners' )
                    {
                     before(grammarAccess.getSectionTypeAccess().getHouseholdCleanersEnumLiteralDeclaration_3()); 
                    // InternalMyProject.g:305:3: ( 'householdCleaners' )
                    // InternalMyProject.g:305:4: 'householdCleaners'
                    {
                    match(input,14,FOLLOW_2); 

                    }

                     after(grammarAccess.getSectionTypeAccess().getHouseholdCleanersEnumLiteralDeclaration_3()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SectionType__Alternatives"


    // $ANTLR start "rule__ClothingType__Alternatives"
    // InternalMyProject.g:313:1: rule__ClothingType__Alternatives : ( ( ( 'men' ) ) | ( ( 'women' ) ) | ( ( 'kids' ) ) | ( ( 'shoes' ) ) );
    public final void rule__ClothingType__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:317:1: ( ( ( 'men' ) ) | ( ( 'women' ) ) | ( ( 'kids' ) ) | ( ( 'shoes' ) ) )
            int alt3=4;
            switch ( input.LA(1) ) {
            case 15:
                {
                alt3=1;
                }
                break;
            case 16:
                {
                alt3=2;
                }
                break;
            case 17:
                {
                alt3=3;
                }
                break;
            case 18:
                {
                alt3=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 3, 0, input);

                throw nvae;
            }

            switch (alt3) {
                case 1 :
                    // InternalMyProject.g:318:2: ( ( 'men' ) )
                    {
                    // InternalMyProject.g:318:2: ( ( 'men' ) )
                    // InternalMyProject.g:319:3: ( 'men' )
                    {
                     before(grammarAccess.getClothingTypeAccess().getMenEnumLiteralDeclaration_0()); 
                    // InternalMyProject.g:320:3: ( 'men' )
                    // InternalMyProject.g:320:4: 'men'
                    {
                    match(input,15,FOLLOW_2); 

                    }

                     after(grammarAccess.getClothingTypeAccess().getMenEnumLiteralDeclaration_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalMyProject.g:324:2: ( ( 'women' ) )
                    {
                    // InternalMyProject.g:324:2: ( ( 'women' ) )
                    // InternalMyProject.g:325:3: ( 'women' )
                    {
                     before(grammarAccess.getClothingTypeAccess().getWomenEnumLiteralDeclaration_1()); 
                    // InternalMyProject.g:326:3: ( 'women' )
                    // InternalMyProject.g:326:4: 'women'
                    {
                    match(input,16,FOLLOW_2); 

                    }

                     after(grammarAccess.getClothingTypeAccess().getWomenEnumLiteralDeclaration_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalMyProject.g:330:2: ( ( 'kids' ) )
                    {
                    // InternalMyProject.g:330:2: ( ( 'kids' ) )
                    // InternalMyProject.g:331:3: ( 'kids' )
                    {
                     before(grammarAccess.getClothingTypeAccess().getKidsEnumLiteralDeclaration_2()); 
                    // InternalMyProject.g:332:3: ( 'kids' )
                    // InternalMyProject.g:332:4: 'kids'
                    {
                    match(input,17,FOLLOW_2); 

                    }

                     after(grammarAccess.getClothingTypeAccess().getKidsEnumLiteralDeclaration_2()); 

                    }


                    }
                    break;
                case 4 :
                    // InternalMyProject.g:336:2: ( ( 'shoes' ) )
                    {
                    // InternalMyProject.g:336:2: ( ( 'shoes' ) )
                    // InternalMyProject.g:337:3: ( 'shoes' )
                    {
                     before(grammarAccess.getClothingTypeAccess().getShoesEnumLiteralDeclaration_3()); 
                    // InternalMyProject.g:338:3: ( 'shoes' )
                    // InternalMyProject.g:338:4: 'shoes'
                    {
                    match(input,18,FOLLOW_2); 

                    }

                     after(grammarAccess.getClothingTypeAccess().getShoesEnumLiteralDeclaration_3()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClothingType__Alternatives"


    // $ANTLR start "rule__ShoppingMall__Group__0"
    // InternalMyProject.g:346:1: rule__ShoppingMall__Group__0 : rule__ShoppingMall__Group__0__Impl rule__ShoppingMall__Group__1 ;
    public final void rule__ShoppingMall__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:350:1: ( rule__ShoppingMall__Group__0__Impl rule__ShoppingMall__Group__1 )
            // InternalMyProject.g:351:2: rule__ShoppingMall__Group__0__Impl rule__ShoppingMall__Group__1
            {
            pushFollow(FOLLOW_3);
            rule__ShoppingMall__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ShoppingMall__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShoppingMall__Group__0"


    // $ANTLR start "rule__ShoppingMall__Group__0__Impl"
    // InternalMyProject.g:358:1: rule__ShoppingMall__Group__0__Impl : ( 'ShoppingMall' ) ;
    public final void rule__ShoppingMall__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:362:1: ( ( 'ShoppingMall' ) )
            // InternalMyProject.g:363:1: ( 'ShoppingMall' )
            {
            // InternalMyProject.g:363:1: ( 'ShoppingMall' )
            // InternalMyProject.g:364:2: 'ShoppingMall'
            {
             before(grammarAccess.getShoppingMallAccess().getShoppingMallKeyword_0()); 
            match(input,19,FOLLOW_2); 
             after(grammarAccess.getShoppingMallAccess().getShoppingMallKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShoppingMall__Group__0__Impl"


    // $ANTLR start "rule__ShoppingMall__Group__1"
    // InternalMyProject.g:373:1: rule__ShoppingMall__Group__1 : rule__ShoppingMall__Group__1__Impl rule__ShoppingMall__Group__2 ;
    public final void rule__ShoppingMall__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:377:1: ( rule__ShoppingMall__Group__1__Impl rule__ShoppingMall__Group__2 )
            // InternalMyProject.g:378:2: rule__ShoppingMall__Group__1__Impl rule__ShoppingMall__Group__2
            {
            pushFollow(FOLLOW_4);
            rule__ShoppingMall__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ShoppingMall__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShoppingMall__Group__1"


    // $ANTLR start "rule__ShoppingMall__Group__1__Impl"
    // InternalMyProject.g:385:1: rule__ShoppingMall__Group__1__Impl : ( '{' ) ;
    public final void rule__ShoppingMall__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:389:1: ( ( '{' ) )
            // InternalMyProject.g:390:1: ( '{' )
            {
            // InternalMyProject.g:390:1: ( '{' )
            // InternalMyProject.g:391:2: '{'
            {
             before(grammarAccess.getShoppingMallAccess().getLeftCurlyBracketKeyword_1()); 
            match(input,20,FOLLOW_2); 
             after(grammarAccess.getShoppingMallAccess().getLeftCurlyBracketKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShoppingMall__Group__1__Impl"


    // $ANTLR start "rule__ShoppingMall__Group__2"
    // InternalMyProject.g:400:1: rule__ShoppingMall__Group__2 : rule__ShoppingMall__Group__2__Impl rule__ShoppingMall__Group__3 ;
    public final void rule__ShoppingMall__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:404:1: ( rule__ShoppingMall__Group__2__Impl rule__ShoppingMall__Group__3 )
            // InternalMyProject.g:405:2: rule__ShoppingMall__Group__2__Impl rule__ShoppingMall__Group__3
            {
            pushFollow(FOLLOW_4);
            rule__ShoppingMall__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ShoppingMall__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShoppingMall__Group__2"


    // $ANTLR start "rule__ShoppingMall__Group__2__Impl"
    // InternalMyProject.g:412:1: rule__ShoppingMall__Group__2__Impl : ( ( rule__ShoppingMall__Group_2__0 )? ) ;
    public final void rule__ShoppingMall__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:416:1: ( ( ( rule__ShoppingMall__Group_2__0 )? ) )
            // InternalMyProject.g:417:1: ( ( rule__ShoppingMall__Group_2__0 )? )
            {
            // InternalMyProject.g:417:1: ( ( rule__ShoppingMall__Group_2__0 )? )
            // InternalMyProject.g:418:2: ( rule__ShoppingMall__Group_2__0 )?
            {
             before(grammarAccess.getShoppingMallAccess().getGroup_2()); 
            // InternalMyProject.g:419:2: ( rule__ShoppingMall__Group_2__0 )?
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( (LA4_0==23) ) {
                alt4=1;
            }
            switch (alt4) {
                case 1 :
                    // InternalMyProject.g:419:3: rule__ShoppingMall__Group_2__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__ShoppingMall__Group_2__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getShoppingMallAccess().getGroup_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShoppingMall__Group__2__Impl"


    // $ANTLR start "rule__ShoppingMall__Group__3"
    // InternalMyProject.g:427:1: rule__ShoppingMall__Group__3 : rule__ShoppingMall__Group__3__Impl rule__ShoppingMall__Group__4 ;
    public final void rule__ShoppingMall__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:431:1: ( rule__ShoppingMall__Group__3__Impl rule__ShoppingMall__Group__4 )
            // InternalMyProject.g:432:2: rule__ShoppingMall__Group__3__Impl rule__ShoppingMall__Group__4
            {
            pushFollow(FOLLOW_4);
            rule__ShoppingMall__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ShoppingMall__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShoppingMall__Group__3"


    // $ANTLR start "rule__ShoppingMall__Group__3__Impl"
    // InternalMyProject.g:439:1: rule__ShoppingMall__Group__3__Impl : ( ( rule__ShoppingMall__Group_3__0 )? ) ;
    public final void rule__ShoppingMall__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:443:1: ( ( ( rule__ShoppingMall__Group_3__0 )? ) )
            // InternalMyProject.g:444:1: ( ( rule__ShoppingMall__Group_3__0 )? )
            {
            // InternalMyProject.g:444:1: ( ( rule__ShoppingMall__Group_3__0 )? )
            // InternalMyProject.g:445:2: ( rule__ShoppingMall__Group_3__0 )?
            {
             before(grammarAccess.getShoppingMallAccess().getGroup_3()); 
            // InternalMyProject.g:446:2: ( rule__ShoppingMall__Group_3__0 )?
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0==24) ) {
                alt5=1;
            }
            switch (alt5) {
                case 1 :
                    // InternalMyProject.g:446:3: rule__ShoppingMall__Group_3__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__ShoppingMall__Group_3__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getShoppingMallAccess().getGroup_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShoppingMall__Group__3__Impl"


    // $ANTLR start "rule__ShoppingMall__Group__4"
    // InternalMyProject.g:454:1: rule__ShoppingMall__Group__4 : rule__ShoppingMall__Group__4__Impl rule__ShoppingMall__Group__5 ;
    public final void rule__ShoppingMall__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:458:1: ( rule__ShoppingMall__Group__4__Impl rule__ShoppingMall__Group__5 )
            // InternalMyProject.g:459:2: rule__ShoppingMall__Group__4__Impl rule__ShoppingMall__Group__5
            {
            pushFollow(FOLLOW_4);
            rule__ShoppingMall__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ShoppingMall__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShoppingMall__Group__4"


    // $ANTLR start "rule__ShoppingMall__Group__4__Impl"
    // InternalMyProject.g:466:1: rule__ShoppingMall__Group__4__Impl : ( ( rule__ShoppingMall__Group_4__0 )? ) ;
    public final void rule__ShoppingMall__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:470:1: ( ( ( rule__ShoppingMall__Group_4__0 )? ) )
            // InternalMyProject.g:471:1: ( ( rule__ShoppingMall__Group_4__0 )? )
            {
            // InternalMyProject.g:471:1: ( ( rule__ShoppingMall__Group_4__0 )? )
            // InternalMyProject.g:472:2: ( rule__ShoppingMall__Group_4__0 )?
            {
             before(grammarAccess.getShoppingMallAccess().getGroup_4()); 
            // InternalMyProject.g:473:2: ( rule__ShoppingMall__Group_4__0 )?
            int alt6=2;
            int LA6_0 = input.LA(1);

            if ( (LA6_0==25) ) {
                alt6=1;
            }
            switch (alt6) {
                case 1 :
                    // InternalMyProject.g:473:3: rule__ShoppingMall__Group_4__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__ShoppingMall__Group_4__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getShoppingMallAccess().getGroup_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShoppingMall__Group__4__Impl"


    // $ANTLR start "rule__ShoppingMall__Group__5"
    // InternalMyProject.g:481:1: rule__ShoppingMall__Group__5 : rule__ShoppingMall__Group__5__Impl rule__ShoppingMall__Group__6 ;
    public final void rule__ShoppingMall__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:485:1: ( rule__ShoppingMall__Group__5__Impl rule__ShoppingMall__Group__6 )
            // InternalMyProject.g:486:2: rule__ShoppingMall__Group__5__Impl rule__ShoppingMall__Group__6
            {
            pushFollow(FOLLOW_3);
            rule__ShoppingMall__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ShoppingMall__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShoppingMall__Group__5"


    // $ANTLR start "rule__ShoppingMall__Group__5__Impl"
    // InternalMyProject.g:493:1: rule__ShoppingMall__Group__5__Impl : ( 'shops' ) ;
    public final void rule__ShoppingMall__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:497:1: ( ( 'shops' ) )
            // InternalMyProject.g:498:1: ( 'shops' )
            {
            // InternalMyProject.g:498:1: ( 'shops' )
            // InternalMyProject.g:499:2: 'shops'
            {
             before(grammarAccess.getShoppingMallAccess().getShopsKeyword_5()); 
            match(input,21,FOLLOW_2); 
             after(grammarAccess.getShoppingMallAccess().getShopsKeyword_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShoppingMall__Group__5__Impl"


    // $ANTLR start "rule__ShoppingMall__Group__6"
    // InternalMyProject.g:508:1: rule__ShoppingMall__Group__6 : rule__ShoppingMall__Group__6__Impl rule__ShoppingMall__Group__7 ;
    public final void rule__ShoppingMall__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:512:1: ( rule__ShoppingMall__Group__6__Impl rule__ShoppingMall__Group__7 )
            // InternalMyProject.g:513:2: rule__ShoppingMall__Group__6__Impl rule__ShoppingMall__Group__7
            {
            pushFollow(FOLLOW_5);
            rule__ShoppingMall__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ShoppingMall__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShoppingMall__Group__6"


    // $ANTLR start "rule__ShoppingMall__Group__6__Impl"
    // InternalMyProject.g:520:1: rule__ShoppingMall__Group__6__Impl : ( '{' ) ;
    public final void rule__ShoppingMall__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:524:1: ( ( '{' ) )
            // InternalMyProject.g:525:1: ( '{' )
            {
            // InternalMyProject.g:525:1: ( '{' )
            // InternalMyProject.g:526:2: '{'
            {
             before(grammarAccess.getShoppingMallAccess().getLeftCurlyBracketKeyword_6()); 
            match(input,20,FOLLOW_2); 
             after(grammarAccess.getShoppingMallAccess().getLeftCurlyBracketKeyword_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShoppingMall__Group__6__Impl"


    // $ANTLR start "rule__ShoppingMall__Group__7"
    // InternalMyProject.g:535:1: rule__ShoppingMall__Group__7 : rule__ShoppingMall__Group__7__Impl rule__ShoppingMall__Group__8 ;
    public final void rule__ShoppingMall__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:539:1: ( rule__ShoppingMall__Group__7__Impl rule__ShoppingMall__Group__8 )
            // InternalMyProject.g:540:2: rule__ShoppingMall__Group__7__Impl rule__ShoppingMall__Group__8
            {
            pushFollow(FOLLOW_6);
            rule__ShoppingMall__Group__7__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ShoppingMall__Group__8();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShoppingMall__Group__7"


    // $ANTLR start "rule__ShoppingMall__Group__7__Impl"
    // InternalMyProject.g:547:1: rule__ShoppingMall__Group__7__Impl : ( ( rule__ShoppingMall__ShopsAssignment_7 ) ) ;
    public final void rule__ShoppingMall__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:551:1: ( ( ( rule__ShoppingMall__ShopsAssignment_7 ) ) )
            // InternalMyProject.g:552:1: ( ( rule__ShoppingMall__ShopsAssignment_7 ) )
            {
            // InternalMyProject.g:552:1: ( ( rule__ShoppingMall__ShopsAssignment_7 ) )
            // InternalMyProject.g:553:2: ( rule__ShoppingMall__ShopsAssignment_7 )
            {
             before(grammarAccess.getShoppingMallAccess().getShopsAssignment_7()); 
            // InternalMyProject.g:554:2: ( rule__ShoppingMall__ShopsAssignment_7 )
            // InternalMyProject.g:554:3: rule__ShoppingMall__ShopsAssignment_7
            {
            pushFollow(FOLLOW_2);
            rule__ShoppingMall__ShopsAssignment_7();

            state._fsp--;


            }

             after(grammarAccess.getShoppingMallAccess().getShopsAssignment_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShoppingMall__Group__7__Impl"


    // $ANTLR start "rule__ShoppingMall__Group__8"
    // InternalMyProject.g:562:1: rule__ShoppingMall__Group__8 : rule__ShoppingMall__Group__8__Impl rule__ShoppingMall__Group__9 ;
    public final void rule__ShoppingMall__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:566:1: ( rule__ShoppingMall__Group__8__Impl rule__ShoppingMall__Group__9 )
            // InternalMyProject.g:567:2: rule__ShoppingMall__Group__8__Impl rule__ShoppingMall__Group__9
            {
            pushFollow(FOLLOW_6);
            rule__ShoppingMall__Group__8__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ShoppingMall__Group__9();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShoppingMall__Group__8"


    // $ANTLR start "rule__ShoppingMall__Group__8__Impl"
    // InternalMyProject.g:574:1: rule__ShoppingMall__Group__8__Impl : ( ( rule__ShoppingMall__Group_8__0 )* ) ;
    public final void rule__ShoppingMall__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:578:1: ( ( ( rule__ShoppingMall__Group_8__0 )* ) )
            // InternalMyProject.g:579:1: ( ( rule__ShoppingMall__Group_8__0 )* )
            {
            // InternalMyProject.g:579:1: ( ( rule__ShoppingMall__Group_8__0 )* )
            // InternalMyProject.g:580:2: ( rule__ShoppingMall__Group_8__0 )*
            {
             before(grammarAccess.getShoppingMallAccess().getGroup_8()); 
            // InternalMyProject.g:581:2: ( rule__ShoppingMall__Group_8__0 )*
            loop7:
            do {
                int alt7=2;
                int LA7_0 = input.LA(1);

                if ( (LA7_0==26) ) {
                    alt7=1;
                }


                switch (alt7) {
            	case 1 :
            	    // InternalMyProject.g:581:3: rule__ShoppingMall__Group_8__0
            	    {
            	    pushFollow(FOLLOW_7);
            	    rule__ShoppingMall__Group_8__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop7;
                }
            } while (true);

             after(grammarAccess.getShoppingMallAccess().getGroup_8()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShoppingMall__Group__8__Impl"


    // $ANTLR start "rule__ShoppingMall__Group__9"
    // InternalMyProject.g:589:1: rule__ShoppingMall__Group__9 : rule__ShoppingMall__Group__9__Impl rule__ShoppingMall__Group__10 ;
    public final void rule__ShoppingMall__Group__9() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:593:1: ( rule__ShoppingMall__Group__9__Impl rule__ShoppingMall__Group__10 )
            // InternalMyProject.g:594:2: rule__ShoppingMall__Group__9__Impl rule__ShoppingMall__Group__10
            {
            pushFollow(FOLLOW_8);
            rule__ShoppingMall__Group__9__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ShoppingMall__Group__10();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShoppingMall__Group__9"


    // $ANTLR start "rule__ShoppingMall__Group__9__Impl"
    // InternalMyProject.g:601:1: rule__ShoppingMall__Group__9__Impl : ( '}' ) ;
    public final void rule__ShoppingMall__Group__9__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:605:1: ( ( '}' ) )
            // InternalMyProject.g:606:1: ( '}' )
            {
            // InternalMyProject.g:606:1: ( '}' )
            // InternalMyProject.g:607:2: '}'
            {
             before(grammarAccess.getShoppingMallAccess().getRightCurlyBracketKeyword_9()); 
            match(input,22,FOLLOW_2); 
             after(grammarAccess.getShoppingMallAccess().getRightCurlyBracketKeyword_9()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShoppingMall__Group__9__Impl"


    // $ANTLR start "rule__ShoppingMall__Group__10"
    // InternalMyProject.g:616:1: rule__ShoppingMall__Group__10 : rule__ShoppingMall__Group__10__Impl ;
    public final void rule__ShoppingMall__Group__10() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:620:1: ( rule__ShoppingMall__Group__10__Impl )
            // InternalMyProject.g:621:2: rule__ShoppingMall__Group__10__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ShoppingMall__Group__10__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShoppingMall__Group__10"


    // $ANTLR start "rule__ShoppingMall__Group__10__Impl"
    // InternalMyProject.g:627:1: rule__ShoppingMall__Group__10__Impl : ( '}' ) ;
    public final void rule__ShoppingMall__Group__10__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:631:1: ( ( '}' ) )
            // InternalMyProject.g:632:1: ( '}' )
            {
            // InternalMyProject.g:632:1: ( '}' )
            // InternalMyProject.g:633:2: '}'
            {
             before(grammarAccess.getShoppingMallAccess().getRightCurlyBracketKeyword_10()); 
            match(input,22,FOLLOW_2); 
             after(grammarAccess.getShoppingMallAccess().getRightCurlyBracketKeyword_10()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShoppingMall__Group__10__Impl"


    // $ANTLR start "rule__ShoppingMall__Group_2__0"
    // InternalMyProject.g:643:1: rule__ShoppingMall__Group_2__0 : rule__ShoppingMall__Group_2__0__Impl rule__ShoppingMall__Group_2__1 ;
    public final void rule__ShoppingMall__Group_2__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:647:1: ( rule__ShoppingMall__Group_2__0__Impl rule__ShoppingMall__Group_2__1 )
            // InternalMyProject.g:648:2: rule__ShoppingMall__Group_2__0__Impl rule__ShoppingMall__Group_2__1
            {
            pushFollow(FOLLOW_9);
            rule__ShoppingMall__Group_2__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ShoppingMall__Group_2__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShoppingMall__Group_2__0"


    // $ANTLR start "rule__ShoppingMall__Group_2__0__Impl"
    // InternalMyProject.g:655:1: rule__ShoppingMall__Group_2__0__Impl : ( 'companyName' ) ;
    public final void rule__ShoppingMall__Group_2__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:659:1: ( ( 'companyName' ) )
            // InternalMyProject.g:660:1: ( 'companyName' )
            {
            // InternalMyProject.g:660:1: ( 'companyName' )
            // InternalMyProject.g:661:2: 'companyName'
            {
             before(grammarAccess.getShoppingMallAccess().getCompanyNameKeyword_2_0()); 
            match(input,23,FOLLOW_2); 
             after(grammarAccess.getShoppingMallAccess().getCompanyNameKeyword_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShoppingMall__Group_2__0__Impl"


    // $ANTLR start "rule__ShoppingMall__Group_2__1"
    // InternalMyProject.g:670:1: rule__ShoppingMall__Group_2__1 : rule__ShoppingMall__Group_2__1__Impl ;
    public final void rule__ShoppingMall__Group_2__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:674:1: ( rule__ShoppingMall__Group_2__1__Impl )
            // InternalMyProject.g:675:2: rule__ShoppingMall__Group_2__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ShoppingMall__Group_2__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShoppingMall__Group_2__1"


    // $ANTLR start "rule__ShoppingMall__Group_2__1__Impl"
    // InternalMyProject.g:681:1: rule__ShoppingMall__Group_2__1__Impl : ( ( rule__ShoppingMall__CompanyNameAssignment_2_1 ) ) ;
    public final void rule__ShoppingMall__Group_2__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:685:1: ( ( ( rule__ShoppingMall__CompanyNameAssignment_2_1 ) ) )
            // InternalMyProject.g:686:1: ( ( rule__ShoppingMall__CompanyNameAssignment_2_1 ) )
            {
            // InternalMyProject.g:686:1: ( ( rule__ShoppingMall__CompanyNameAssignment_2_1 ) )
            // InternalMyProject.g:687:2: ( rule__ShoppingMall__CompanyNameAssignment_2_1 )
            {
             before(grammarAccess.getShoppingMallAccess().getCompanyNameAssignment_2_1()); 
            // InternalMyProject.g:688:2: ( rule__ShoppingMall__CompanyNameAssignment_2_1 )
            // InternalMyProject.g:688:3: rule__ShoppingMall__CompanyNameAssignment_2_1
            {
            pushFollow(FOLLOW_2);
            rule__ShoppingMall__CompanyNameAssignment_2_1();

            state._fsp--;


            }

             after(grammarAccess.getShoppingMallAccess().getCompanyNameAssignment_2_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShoppingMall__Group_2__1__Impl"


    // $ANTLR start "rule__ShoppingMall__Group_3__0"
    // InternalMyProject.g:697:1: rule__ShoppingMall__Group_3__0 : rule__ShoppingMall__Group_3__0__Impl rule__ShoppingMall__Group_3__1 ;
    public final void rule__ShoppingMall__Group_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:701:1: ( rule__ShoppingMall__Group_3__0__Impl rule__ShoppingMall__Group_3__1 )
            // InternalMyProject.g:702:2: rule__ShoppingMall__Group_3__0__Impl rule__ShoppingMall__Group_3__1
            {
            pushFollow(FOLLOW_9);
            rule__ShoppingMall__Group_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ShoppingMall__Group_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShoppingMall__Group_3__0"


    // $ANTLR start "rule__ShoppingMall__Group_3__0__Impl"
    // InternalMyProject.g:709:1: rule__ShoppingMall__Group_3__0__Impl : ( 'ceo' ) ;
    public final void rule__ShoppingMall__Group_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:713:1: ( ( 'ceo' ) )
            // InternalMyProject.g:714:1: ( 'ceo' )
            {
            // InternalMyProject.g:714:1: ( 'ceo' )
            // InternalMyProject.g:715:2: 'ceo'
            {
             before(grammarAccess.getShoppingMallAccess().getCeoKeyword_3_0()); 
            match(input,24,FOLLOW_2); 
             after(grammarAccess.getShoppingMallAccess().getCeoKeyword_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShoppingMall__Group_3__0__Impl"


    // $ANTLR start "rule__ShoppingMall__Group_3__1"
    // InternalMyProject.g:724:1: rule__ShoppingMall__Group_3__1 : rule__ShoppingMall__Group_3__1__Impl ;
    public final void rule__ShoppingMall__Group_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:728:1: ( rule__ShoppingMall__Group_3__1__Impl )
            // InternalMyProject.g:729:2: rule__ShoppingMall__Group_3__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ShoppingMall__Group_3__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShoppingMall__Group_3__1"


    // $ANTLR start "rule__ShoppingMall__Group_3__1__Impl"
    // InternalMyProject.g:735:1: rule__ShoppingMall__Group_3__1__Impl : ( ( rule__ShoppingMall__CeoAssignment_3_1 ) ) ;
    public final void rule__ShoppingMall__Group_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:739:1: ( ( ( rule__ShoppingMall__CeoAssignment_3_1 ) ) )
            // InternalMyProject.g:740:1: ( ( rule__ShoppingMall__CeoAssignment_3_1 ) )
            {
            // InternalMyProject.g:740:1: ( ( rule__ShoppingMall__CeoAssignment_3_1 ) )
            // InternalMyProject.g:741:2: ( rule__ShoppingMall__CeoAssignment_3_1 )
            {
             before(grammarAccess.getShoppingMallAccess().getCeoAssignment_3_1()); 
            // InternalMyProject.g:742:2: ( rule__ShoppingMall__CeoAssignment_3_1 )
            // InternalMyProject.g:742:3: rule__ShoppingMall__CeoAssignment_3_1
            {
            pushFollow(FOLLOW_2);
            rule__ShoppingMall__CeoAssignment_3_1();

            state._fsp--;


            }

             after(grammarAccess.getShoppingMallAccess().getCeoAssignment_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShoppingMall__Group_3__1__Impl"


    // $ANTLR start "rule__ShoppingMall__Group_4__0"
    // InternalMyProject.g:751:1: rule__ShoppingMall__Group_4__0 : rule__ShoppingMall__Group_4__0__Impl rule__ShoppingMall__Group_4__1 ;
    public final void rule__ShoppingMall__Group_4__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:755:1: ( rule__ShoppingMall__Group_4__0__Impl rule__ShoppingMall__Group_4__1 )
            // InternalMyProject.g:756:2: rule__ShoppingMall__Group_4__0__Impl rule__ShoppingMall__Group_4__1
            {
            pushFollow(FOLLOW_9);
            rule__ShoppingMall__Group_4__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ShoppingMall__Group_4__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShoppingMall__Group_4__0"


    // $ANTLR start "rule__ShoppingMall__Group_4__0__Impl"
    // InternalMyProject.g:763:1: rule__ShoppingMall__Group_4__0__Impl : ( 'location' ) ;
    public final void rule__ShoppingMall__Group_4__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:767:1: ( ( 'location' ) )
            // InternalMyProject.g:768:1: ( 'location' )
            {
            // InternalMyProject.g:768:1: ( 'location' )
            // InternalMyProject.g:769:2: 'location'
            {
             before(grammarAccess.getShoppingMallAccess().getLocationKeyword_4_0()); 
            match(input,25,FOLLOW_2); 
             after(grammarAccess.getShoppingMallAccess().getLocationKeyword_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShoppingMall__Group_4__0__Impl"


    // $ANTLR start "rule__ShoppingMall__Group_4__1"
    // InternalMyProject.g:778:1: rule__ShoppingMall__Group_4__1 : rule__ShoppingMall__Group_4__1__Impl ;
    public final void rule__ShoppingMall__Group_4__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:782:1: ( rule__ShoppingMall__Group_4__1__Impl )
            // InternalMyProject.g:783:2: rule__ShoppingMall__Group_4__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ShoppingMall__Group_4__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShoppingMall__Group_4__1"


    // $ANTLR start "rule__ShoppingMall__Group_4__1__Impl"
    // InternalMyProject.g:789:1: rule__ShoppingMall__Group_4__1__Impl : ( ( rule__ShoppingMall__LocationAssignment_4_1 ) ) ;
    public final void rule__ShoppingMall__Group_4__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:793:1: ( ( ( rule__ShoppingMall__LocationAssignment_4_1 ) ) )
            // InternalMyProject.g:794:1: ( ( rule__ShoppingMall__LocationAssignment_4_1 ) )
            {
            // InternalMyProject.g:794:1: ( ( rule__ShoppingMall__LocationAssignment_4_1 ) )
            // InternalMyProject.g:795:2: ( rule__ShoppingMall__LocationAssignment_4_1 )
            {
             before(grammarAccess.getShoppingMallAccess().getLocationAssignment_4_1()); 
            // InternalMyProject.g:796:2: ( rule__ShoppingMall__LocationAssignment_4_1 )
            // InternalMyProject.g:796:3: rule__ShoppingMall__LocationAssignment_4_1
            {
            pushFollow(FOLLOW_2);
            rule__ShoppingMall__LocationAssignment_4_1();

            state._fsp--;


            }

             after(grammarAccess.getShoppingMallAccess().getLocationAssignment_4_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShoppingMall__Group_4__1__Impl"


    // $ANTLR start "rule__ShoppingMall__Group_8__0"
    // InternalMyProject.g:805:1: rule__ShoppingMall__Group_8__0 : rule__ShoppingMall__Group_8__0__Impl rule__ShoppingMall__Group_8__1 ;
    public final void rule__ShoppingMall__Group_8__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:809:1: ( rule__ShoppingMall__Group_8__0__Impl rule__ShoppingMall__Group_8__1 )
            // InternalMyProject.g:810:2: rule__ShoppingMall__Group_8__0__Impl rule__ShoppingMall__Group_8__1
            {
            pushFollow(FOLLOW_5);
            rule__ShoppingMall__Group_8__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ShoppingMall__Group_8__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShoppingMall__Group_8__0"


    // $ANTLR start "rule__ShoppingMall__Group_8__0__Impl"
    // InternalMyProject.g:817:1: rule__ShoppingMall__Group_8__0__Impl : ( ',' ) ;
    public final void rule__ShoppingMall__Group_8__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:821:1: ( ( ',' ) )
            // InternalMyProject.g:822:1: ( ',' )
            {
            // InternalMyProject.g:822:1: ( ',' )
            // InternalMyProject.g:823:2: ','
            {
             before(grammarAccess.getShoppingMallAccess().getCommaKeyword_8_0()); 
            match(input,26,FOLLOW_2); 
             after(grammarAccess.getShoppingMallAccess().getCommaKeyword_8_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShoppingMall__Group_8__0__Impl"


    // $ANTLR start "rule__ShoppingMall__Group_8__1"
    // InternalMyProject.g:832:1: rule__ShoppingMall__Group_8__1 : rule__ShoppingMall__Group_8__1__Impl ;
    public final void rule__ShoppingMall__Group_8__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:836:1: ( rule__ShoppingMall__Group_8__1__Impl )
            // InternalMyProject.g:837:2: rule__ShoppingMall__Group_8__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ShoppingMall__Group_8__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShoppingMall__Group_8__1"


    // $ANTLR start "rule__ShoppingMall__Group_8__1__Impl"
    // InternalMyProject.g:843:1: rule__ShoppingMall__Group_8__1__Impl : ( ( rule__ShoppingMall__ShopsAssignment_8_1 ) ) ;
    public final void rule__ShoppingMall__Group_8__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:847:1: ( ( ( rule__ShoppingMall__ShopsAssignment_8_1 ) ) )
            // InternalMyProject.g:848:1: ( ( rule__ShoppingMall__ShopsAssignment_8_1 ) )
            {
            // InternalMyProject.g:848:1: ( ( rule__ShoppingMall__ShopsAssignment_8_1 ) )
            // InternalMyProject.g:849:2: ( rule__ShoppingMall__ShopsAssignment_8_1 )
            {
             before(grammarAccess.getShoppingMallAccess().getShopsAssignment_8_1()); 
            // InternalMyProject.g:850:2: ( rule__ShoppingMall__ShopsAssignment_8_1 )
            // InternalMyProject.g:850:3: rule__ShoppingMall__ShopsAssignment_8_1
            {
            pushFollow(FOLLOW_2);
            rule__ShoppingMall__ShopsAssignment_8_1();

            state._fsp--;


            }

             after(grammarAccess.getShoppingMallAccess().getShopsAssignment_8_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShoppingMall__Group_8__1__Impl"


    // $ANTLR start "rule__Shop__Group__0"
    // InternalMyProject.g:859:1: rule__Shop__Group__0 : rule__Shop__Group__0__Impl rule__Shop__Group__1 ;
    public final void rule__Shop__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:863:1: ( rule__Shop__Group__0__Impl rule__Shop__Group__1 )
            // InternalMyProject.g:864:2: rule__Shop__Group__0__Impl rule__Shop__Group__1
            {
            pushFollow(FOLLOW_3);
            rule__Shop__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Shop__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Shop__Group__0"


    // $ANTLR start "rule__Shop__Group__0__Impl"
    // InternalMyProject.g:871:1: rule__Shop__Group__0__Impl : ( 'Shop' ) ;
    public final void rule__Shop__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:875:1: ( ( 'Shop' ) )
            // InternalMyProject.g:876:1: ( 'Shop' )
            {
            // InternalMyProject.g:876:1: ( 'Shop' )
            // InternalMyProject.g:877:2: 'Shop'
            {
             before(grammarAccess.getShopAccess().getShopKeyword_0()); 
            match(input,27,FOLLOW_2); 
             after(grammarAccess.getShopAccess().getShopKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Shop__Group__0__Impl"


    // $ANTLR start "rule__Shop__Group__1"
    // InternalMyProject.g:886:1: rule__Shop__Group__1 : rule__Shop__Group__1__Impl rule__Shop__Group__2 ;
    public final void rule__Shop__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:890:1: ( rule__Shop__Group__1__Impl rule__Shop__Group__2 )
            // InternalMyProject.g:891:2: rule__Shop__Group__1__Impl rule__Shop__Group__2
            {
            pushFollow(FOLLOW_10);
            rule__Shop__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Shop__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Shop__Group__1"


    // $ANTLR start "rule__Shop__Group__1__Impl"
    // InternalMyProject.g:898:1: rule__Shop__Group__1__Impl : ( '{' ) ;
    public final void rule__Shop__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:902:1: ( ( '{' ) )
            // InternalMyProject.g:903:1: ( '{' )
            {
            // InternalMyProject.g:903:1: ( '{' )
            // InternalMyProject.g:904:2: '{'
            {
             before(grammarAccess.getShopAccess().getLeftCurlyBracketKeyword_1()); 
            match(input,20,FOLLOW_2); 
             after(grammarAccess.getShopAccess().getLeftCurlyBracketKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Shop__Group__1__Impl"


    // $ANTLR start "rule__Shop__Group__2"
    // InternalMyProject.g:913:1: rule__Shop__Group__2 : rule__Shop__Group__2__Impl rule__Shop__Group__3 ;
    public final void rule__Shop__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:917:1: ( rule__Shop__Group__2__Impl rule__Shop__Group__3 )
            // InternalMyProject.g:918:2: rule__Shop__Group__2__Impl rule__Shop__Group__3
            {
            pushFollow(FOLLOW_11);
            rule__Shop__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Shop__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Shop__Group__2"


    // $ANTLR start "rule__Shop__Group__2__Impl"
    // InternalMyProject.g:925:1: rule__Shop__Group__2__Impl : ( 'supermarket' ) ;
    public final void rule__Shop__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:929:1: ( ( 'supermarket' ) )
            // InternalMyProject.g:930:1: ( 'supermarket' )
            {
            // InternalMyProject.g:930:1: ( 'supermarket' )
            // InternalMyProject.g:931:2: 'supermarket'
            {
             before(grammarAccess.getShopAccess().getSupermarketKeyword_2()); 
            match(input,28,FOLLOW_2); 
             after(grammarAccess.getShopAccess().getSupermarketKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Shop__Group__2__Impl"


    // $ANTLR start "rule__Shop__Group__3"
    // InternalMyProject.g:940:1: rule__Shop__Group__3 : rule__Shop__Group__3__Impl rule__Shop__Group__4 ;
    public final void rule__Shop__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:944:1: ( rule__Shop__Group__3__Impl rule__Shop__Group__4 )
            // InternalMyProject.g:945:2: rule__Shop__Group__3__Impl rule__Shop__Group__4
            {
            pushFollow(FOLLOW_12);
            rule__Shop__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Shop__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Shop__Group__3"


    // $ANTLR start "rule__Shop__Group__3__Impl"
    // InternalMyProject.g:952:1: rule__Shop__Group__3__Impl : ( ( rule__Shop__SupermarketAssignment_3 ) ) ;
    public final void rule__Shop__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:956:1: ( ( ( rule__Shop__SupermarketAssignment_3 ) ) )
            // InternalMyProject.g:957:1: ( ( rule__Shop__SupermarketAssignment_3 ) )
            {
            // InternalMyProject.g:957:1: ( ( rule__Shop__SupermarketAssignment_3 ) )
            // InternalMyProject.g:958:2: ( rule__Shop__SupermarketAssignment_3 )
            {
             before(grammarAccess.getShopAccess().getSupermarketAssignment_3()); 
            // InternalMyProject.g:959:2: ( rule__Shop__SupermarketAssignment_3 )
            // InternalMyProject.g:959:3: rule__Shop__SupermarketAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__Shop__SupermarketAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getShopAccess().getSupermarketAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Shop__Group__3__Impl"


    // $ANTLR start "rule__Shop__Group__4"
    // InternalMyProject.g:967:1: rule__Shop__Group__4 : rule__Shop__Group__4__Impl rule__Shop__Group__5 ;
    public final void rule__Shop__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:971:1: ( rule__Shop__Group__4__Impl rule__Shop__Group__5 )
            // InternalMyProject.g:972:2: rule__Shop__Group__4__Impl rule__Shop__Group__5
            {
            pushFollow(FOLLOW_3);
            rule__Shop__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Shop__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Shop__Group__4"


    // $ANTLR start "rule__Shop__Group__4__Impl"
    // InternalMyProject.g:979:1: rule__Shop__Group__4__Impl : ( 'clothingStores' ) ;
    public final void rule__Shop__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:983:1: ( ( 'clothingStores' ) )
            // InternalMyProject.g:984:1: ( 'clothingStores' )
            {
            // InternalMyProject.g:984:1: ( 'clothingStores' )
            // InternalMyProject.g:985:2: 'clothingStores'
            {
             before(grammarAccess.getShopAccess().getClothingStoresKeyword_4()); 
            match(input,29,FOLLOW_2); 
             after(grammarAccess.getShopAccess().getClothingStoresKeyword_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Shop__Group__4__Impl"


    // $ANTLR start "rule__Shop__Group__5"
    // InternalMyProject.g:994:1: rule__Shop__Group__5 : rule__Shop__Group__5__Impl rule__Shop__Group__6 ;
    public final void rule__Shop__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:998:1: ( rule__Shop__Group__5__Impl rule__Shop__Group__6 )
            // InternalMyProject.g:999:2: rule__Shop__Group__5__Impl rule__Shop__Group__6
            {
            pushFollow(FOLLOW_13);
            rule__Shop__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Shop__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Shop__Group__5"


    // $ANTLR start "rule__Shop__Group__5__Impl"
    // InternalMyProject.g:1006:1: rule__Shop__Group__5__Impl : ( '{' ) ;
    public final void rule__Shop__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1010:1: ( ( '{' ) )
            // InternalMyProject.g:1011:1: ( '{' )
            {
            // InternalMyProject.g:1011:1: ( '{' )
            // InternalMyProject.g:1012:2: '{'
            {
             before(grammarAccess.getShopAccess().getLeftCurlyBracketKeyword_5()); 
            match(input,20,FOLLOW_2); 
             after(grammarAccess.getShopAccess().getLeftCurlyBracketKeyword_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Shop__Group__5__Impl"


    // $ANTLR start "rule__Shop__Group__6"
    // InternalMyProject.g:1021:1: rule__Shop__Group__6 : rule__Shop__Group__6__Impl rule__Shop__Group__7 ;
    public final void rule__Shop__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1025:1: ( rule__Shop__Group__6__Impl rule__Shop__Group__7 )
            // InternalMyProject.g:1026:2: rule__Shop__Group__6__Impl rule__Shop__Group__7
            {
            pushFollow(FOLLOW_6);
            rule__Shop__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Shop__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Shop__Group__6"


    // $ANTLR start "rule__Shop__Group__6__Impl"
    // InternalMyProject.g:1033:1: rule__Shop__Group__6__Impl : ( ( rule__Shop__ClothingStoresAssignment_6 ) ) ;
    public final void rule__Shop__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1037:1: ( ( ( rule__Shop__ClothingStoresAssignment_6 ) ) )
            // InternalMyProject.g:1038:1: ( ( rule__Shop__ClothingStoresAssignment_6 ) )
            {
            // InternalMyProject.g:1038:1: ( ( rule__Shop__ClothingStoresAssignment_6 ) )
            // InternalMyProject.g:1039:2: ( rule__Shop__ClothingStoresAssignment_6 )
            {
             before(grammarAccess.getShopAccess().getClothingStoresAssignment_6()); 
            // InternalMyProject.g:1040:2: ( rule__Shop__ClothingStoresAssignment_6 )
            // InternalMyProject.g:1040:3: rule__Shop__ClothingStoresAssignment_6
            {
            pushFollow(FOLLOW_2);
            rule__Shop__ClothingStoresAssignment_6();

            state._fsp--;


            }

             after(grammarAccess.getShopAccess().getClothingStoresAssignment_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Shop__Group__6__Impl"


    // $ANTLR start "rule__Shop__Group__7"
    // InternalMyProject.g:1048:1: rule__Shop__Group__7 : rule__Shop__Group__7__Impl rule__Shop__Group__8 ;
    public final void rule__Shop__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1052:1: ( rule__Shop__Group__7__Impl rule__Shop__Group__8 )
            // InternalMyProject.g:1053:2: rule__Shop__Group__7__Impl rule__Shop__Group__8
            {
            pushFollow(FOLLOW_6);
            rule__Shop__Group__7__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Shop__Group__8();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Shop__Group__7"


    // $ANTLR start "rule__Shop__Group__7__Impl"
    // InternalMyProject.g:1060:1: rule__Shop__Group__7__Impl : ( ( rule__Shop__Group_7__0 )* ) ;
    public final void rule__Shop__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1064:1: ( ( ( rule__Shop__Group_7__0 )* ) )
            // InternalMyProject.g:1065:1: ( ( rule__Shop__Group_7__0 )* )
            {
            // InternalMyProject.g:1065:1: ( ( rule__Shop__Group_7__0 )* )
            // InternalMyProject.g:1066:2: ( rule__Shop__Group_7__0 )*
            {
             before(grammarAccess.getShopAccess().getGroup_7()); 
            // InternalMyProject.g:1067:2: ( rule__Shop__Group_7__0 )*
            loop8:
            do {
                int alt8=2;
                int LA8_0 = input.LA(1);

                if ( (LA8_0==26) ) {
                    alt8=1;
                }


                switch (alt8) {
            	case 1 :
            	    // InternalMyProject.g:1067:3: rule__Shop__Group_7__0
            	    {
            	    pushFollow(FOLLOW_7);
            	    rule__Shop__Group_7__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop8;
                }
            } while (true);

             after(grammarAccess.getShopAccess().getGroup_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Shop__Group__7__Impl"


    // $ANTLR start "rule__Shop__Group__8"
    // InternalMyProject.g:1075:1: rule__Shop__Group__8 : rule__Shop__Group__8__Impl rule__Shop__Group__9 ;
    public final void rule__Shop__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1079:1: ( rule__Shop__Group__8__Impl rule__Shop__Group__9 )
            // InternalMyProject.g:1080:2: rule__Shop__Group__8__Impl rule__Shop__Group__9
            {
            pushFollow(FOLLOW_8);
            rule__Shop__Group__8__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Shop__Group__9();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Shop__Group__8"


    // $ANTLR start "rule__Shop__Group__8__Impl"
    // InternalMyProject.g:1087:1: rule__Shop__Group__8__Impl : ( '}' ) ;
    public final void rule__Shop__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1091:1: ( ( '}' ) )
            // InternalMyProject.g:1092:1: ( '}' )
            {
            // InternalMyProject.g:1092:1: ( '}' )
            // InternalMyProject.g:1093:2: '}'
            {
             before(grammarAccess.getShopAccess().getRightCurlyBracketKeyword_8()); 
            match(input,22,FOLLOW_2); 
             after(grammarAccess.getShopAccess().getRightCurlyBracketKeyword_8()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Shop__Group__8__Impl"


    // $ANTLR start "rule__Shop__Group__9"
    // InternalMyProject.g:1102:1: rule__Shop__Group__9 : rule__Shop__Group__9__Impl ;
    public final void rule__Shop__Group__9() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1106:1: ( rule__Shop__Group__9__Impl )
            // InternalMyProject.g:1107:2: rule__Shop__Group__9__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Shop__Group__9__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Shop__Group__9"


    // $ANTLR start "rule__Shop__Group__9__Impl"
    // InternalMyProject.g:1113:1: rule__Shop__Group__9__Impl : ( '}' ) ;
    public final void rule__Shop__Group__9__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1117:1: ( ( '}' ) )
            // InternalMyProject.g:1118:1: ( '}' )
            {
            // InternalMyProject.g:1118:1: ( '}' )
            // InternalMyProject.g:1119:2: '}'
            {
             before(grammarAccess.getShopAccess().getRightCurlyBracketKeyword_9()); 
            match(input,22,FOLLOW_2); 
             after(grammarAccess.getShopAccess().getRightCurlyBracketKeyword_9()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Shop__Group__9__Impl"


    // $ANTLR start "rule__Shop__Group_7__0"
    // InternalMyProject.g:1129:1: rule__Shop__Group_7__0 : rule__Shop__Group_7__0__Impl rule__Shop__Group_7__1 ;
    public final void rule__Shop__Group_7__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1133:1: ( rule__Shop__Group_7__0__Impl rule__Shop__Group_7__1 )
            // InternalMyProject.g:1134:2: rule__Shop__Group_7__0__Impl rule__Shop__Group_7__1
            {
            pushFollow(FOLLOW_13);
            rule__Shop__Group_7__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Shop__Group_7__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Shop__Group_7__0"


    // $ANTLR start "rule__Shop__Group_7__0__Impl"
    // InternalMyProject.g:1141:1: rule__Shop__Group_7__0__Impl : ( ',' ) ;
    public final void rule__Shop__Group_7__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1145:1: ( ( ',' ) )
            // InternalMyProject.g:1146:1: ( ',' )
            {
            // InternalMyProject.g:1146:1: ( ',' )
            // InternalMyProject.g:1147:2: ','
            {
             before(grammarAccess.getShopAccess().getCommaKeyword_7_0()); 
            match(input,26,FOLLOW_2); 
             after(grammarAccess.getShopAccess().getCommaKeyword_7_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Shop__Group_7__0__Impl"


    // $ANTLR start "rule__Shop__Group_7__1"
    // InternalMyProject.g:1156:1: rule__Shop__Group_7__1 : rule__Shop__Group_7__1__Impl ;
    public final void rule__Shop__Group_7__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1160:1: ( rule__Shop__Group_7__1__Impl )
            // InternalMyProject.g:1161:2: rule__Shop__Group_7__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Shop__Group_7__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Shop__Group_7__1"


    // $ANTLR start "rule__Shop__Group_7__1__Impl"
    // InternalMyProject.g:1167:1: rule__Shop__Group_7__1__Impl : ( ( rule__Shop__ClothingStoresAssignment_7_1 ) ) ;
    public final void rule__Shop__Group_7__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1171:1: ( ( ( rule__Shop__ClothingStoresAssignment_7_1 ) ) )
            // InternalMyProject.g:1172:1: ( ( rule__Shop__ClothingStoresAssignment_7_1 ) )
            {
            // InternalMyProject.g:1172:1: ( ( rule__Shop__ClothingStoresAssignment_7_1 ) )
            // InternalMyProject.g:1173:2: ( rule__Shop__ClothingStoresAssignment_7_1 )
            {
             before(grammarAccess.getShopAccess().getClothingStoresAssignment_7_1()); 
            // InternalMyProject.g:1174:2: ( rule__Shop__ClothingStoresAssignment_7_1 )
            // InternalMyProject.g:1174:3: rule__Shop__ClothingStoresAssignment_7_1
            {
            pushFollow(FOLLOW_2);
            rule__Shop__ClothingStoresAssignment_7_1();

            state._fsp--;


            }

             after(grammarAccess.getShopAccess().getClothingStoresAssignment_7_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Shop__Group_7__1__Impl"


    // $ANTLR start "rule__Supermarket__Group__0"
    // InternalMyProject.g:1183:1: rule__Supermarket__Group__0 : rule__Supermarket__Group__0__Impl rule__Supermarket__Group__1 ;
    public final void rule__Supermarket__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1187:1: ( rule__Supermarket__Group__0__Impl rule__Supermarket__Group__1 )
            // InternalMyProject.g:1188:2: rule__Supermarket__Group__0__Impl rule__Supermarket__Group__1
            {
            pushFollow(FOLLOW_9);
            rule__Supermarket__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Supermarket__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__Group__0"


    // $ANTLR start "rule__Supermarket__Group__0__Impl"
    // InternalMyProject.g:1195:1: rule__Supermarket__Group__0__Impl : ( 'Supermarket' ) ;
    public final void rule__Supermarket__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1199:1: ( ( 'Supermarket' ) )
            // InternalMyProject.g:1200:1: ( 'Supermarket' )
            {
            // InternalMyProject.g:1200:1: ( 'Supermarket' )
            // InternalMyProject.g:1201:2: 'Supermarket'
            {
             before(grammarAccess.getSupermarketAccess().getSupermarketKeyword_0()); 
            match(input,30,FOLLOW_2); 
             after(grammarAccess.getSupermarketAccess().getSupermarketKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__Group__0__Impl"


    // $ANTLR start "rule__Supermarket__Group__1"
    // InternalMyProject.g:1210:1: rule__Supermarket__Group__1 : rule__Supermarket__Group__1__Impl rule__Supermarket__Group__2 ;
    public final void rule__Supermarket__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1214:1: ( rule__Supermarket__Group__1__Impl rule__Supermarket__Group__2 )
            // InternalMyProject.g:1215:2: rule__Supermarket__Group__1__Impl rule__Supermarket__Group__2
            {
            pushFollow(FOLLOW_3);
            rule__Supermarket__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Supermarket__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__Group__1"


    // $ANTLR start "rule__Supermarket__Group__1__Impl"
    // InternalMyProject.g:1222:1: rule__Supermarket__Group__1__Impl : ( ( rule__Supermarket__NameAssignment_1 ) ) ;
    public final void rule__Supermarket__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1226:1: ( ( ( rule__Supermarket__NameAssignment_1 ) ) )
            // InternalMyProject.g:1227:1: ( ( rule__Supermarket__NameAssignment_1 ) )
            {
            // InternalMyProject.g:1227:1: ( ( rule__Supermarket__NameAssignment_1 ) )
            // InternalMyProject.g:1228:2: ( rule__Supermarket__NameAssignment_1 )
            {
             before(grammarAccess.getSupermarketAccess().getNameAssignment_1()); 
            // InternalMyProject.g:1229:2: ( rule__Supermarket__NameAssignment_1 )
            // InternalMyProject.g:1229:3: rule__Supermarket__NameAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Supermarket__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getSupermarketAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__Group__1__Impl"


    // $ANTLR start "rule__Supermarket__Group__2"
    // InternalMyProject.g:1237:1: rule__Supermarket__Group__2 : rule__Supermarket__Group__2__Impl rule__Supermarket__Group__3 ;
    public final void rule__Supermarket__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1241:1: ( rule__Supermarket__Group__2__Impl rule__Supermarket__Group__3 )
            // InternalMyProject.g:1242:2: rule__Supermarket__Group__2__Impl rule__Supermarket__Group__3
            {
            pushFollow(FOLLOW_14);
            rule__Supermarket__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Supermarket__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__Group__2"


    // $ANTLR start "rule__Supermarket__Group__2__Impl"
    // InternalMyProject.g:1249:1: rule__Supermarket__Group__2__Impl : ( '{' ) ;
    public final void rule__Supermarket__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1253:1: ( ( '{' ) )
            // InternalMyProject.g:1254:1: ( '{' )
            {
            // InternalMyProject.g:1254:1: ( '{' )
            // InternalMyProject.g:1255:2: '{'
            {
             before(grammarAccess.getSupermarketAccess().getLeftCurlyBracketKeyword_2()); 
            match(input,20,FOLLOW_2); 
             after(grammarAccess.getSupermarketAccess().getLeftCurlyBracketKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__Group__2__Impl"


    // $ANTLR start "rule__Supermarket__Group__3"
    // InternalMyProject.g:1264:1: rule__Supermarket__Group__3 : rule__Supermarket__Group__3__Impl rule__Supermarket__Group__4 ;
    public final void rule__Supermarket__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1268:1: ( rule__Supermarket__Group__3__Impl rule__Supermarket__Group__4 )
            // InternalMyProject.g:1269:2: rule__Supermarket__Group__3__Impl rule__Supermarket__Group__4
            {
            pushFollow(FOLLOW_14);
            rule__Supermarket__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Supermarket__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__Group__3"


    // $ANTLR start "rule__Supermarket__Group__3__Impl"
    // InternalMyProject.g:1276:1: rule__Supermarket__Group__3__Impl : ( ( rule__Supermarket__Group_3__0 )? ) ;
    public final void rule__Supermarket__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1280:1: ( ( ( rule__Supermarket__Group_3__0 )? ) )
            // InternalMyProject.g:1281:1: ( ( rule__Supermarket__Group_3__0 )? )
            {
            // InternalMyProject.g:1281:1: ( ( rule__Supermarket__Group_3__0 )? )
            // InternalMyProject.g:1282:2: ( rule__Supermarket__Group_3__0 )?
            {
             before(grammarAccess.getSupermarketAccess().getGroup_3()); 
            // InternalMyProject.g:1283:2: ( rule__Supermarket__Group_3__0 )?
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( (LA9_0==32) ) {
                alt9=1;
            }
            switch (alt9) {
                case 1 :
                    // InternalMyProject.g:1283:3: rule__Supermarket__Group_3__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Supermarket__Group_3__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getSupermarketAccess().getGroup_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__Group__3__Impl"


    // $ANTLR start "rule__Supermarket__Group__4"
    // InternalMyProject.g:1291:1: rule__Supermarket__Group__4 : rule__Supermarket__Group__4__Impl rule__Supermarket__Group__5 ;
    public final void rule__Supermarket__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1295:1: ( rule__Supermarket__Group__4__Impl rule__Supermarket__Group__5 )
            // InternalMyProject.g:1296:2: rule__Supermarket__Group__4__Impl rule__Supermarket__Group__5
            {
            pushFollow(FOLLOW_14);
            rule__Supermarket__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Supermarket__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__Group__4"


    // $ANTLR start "rule__Supermarket__Group__4__Impl"
    // InternalMyProject.g:1303:1: rule__Supermarket__Group__4__Impl : ( ( rule__Supermarket__Group_4__0 )? ) ;
    public final void rule__Supermarket__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1307:1: ( ( ( rule__Supermarket__Group_4__0 )? ) )
            // InternalMyProject.g:1308:1: ( ( rule__Supermarket__Group_4__0 )? )
            {
            // InternalMyProject.g:1308:1: ( ( rule__Supermarket__Group_4__0 )? )
            // InternalMyProject.g:1309:2: ( rule__Supermarket__Group_4__0 )?
            {
             before(grammarAccess.getSupermarketAccess().getGroup_4()); 
            // InternalMyProject.g:1310:2: ( rule__Supermarket__Group_4__0 )?
            int alt10=2;
            int LA10_0 = input.LA(1);

            if ( (LA10_0==33) ) {
                alt10=1;
            }
            switch (alt10) {
                case 1 :
                    // InternalMyProject.g:1310:3: rule__Supermarket__Group_4__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Supermarket__Group_4__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getSupermarketAccess().getGroup_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__Group__4__Impl"


    // $ANTLR start "rule__Supermarket__Group__5"
    // InternalMyProject.g:1318:1: rule__Supermarket__Group__5 : rule__Supermarket__Group__5__Impl rule__Supermarket__Group__6 ;
    public final void rule__Supermarket__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1322:1: ( rule__Supermarket__Group__5__Impl rule__Supermarket__Group__6 )
            // InternalMyProject.g:1323:2: rule__Supermarket__Group__5__Impl rule__Supermarket__Group__6
            {
            pushFollow(FOLLOW_14);
            rule__Supermarket__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Supermarket__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__Group__5"


    // $ANTLR start "rule__Supermarket__Group__5__Impl"
    // InternalMyProject.g:1330:1: rule__Supermarket__Group__5__Impl : ( ( rule__Supermarket__Group_5__0 )? ) ;
    public final void rule__Supermarket__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1334:1: ( ( ( rule__Supermarket__Group_5__0 )? ) )
            // InternalMyProject.g:1335:1: ( ( rule__Supermarket__Group_5__0 )? )
            {
            // InternalMyProject.g:1335:1: ( ( rule__Supermarket__Group_5__0 )? )
            // InternalMyProject.g:1336:2: ( rule__Supermarket__Group_5__0 )?
            {
             before(grammarAccess.getSupermarketAccess().getGroup_5()); 
            // InternalMyProject.g:1337:2: ( rule__Supermarket__Group_5__0 )?
            int alt11=2;
            int LA11_0 = input.LA(1);

            if ( (LA11_0==34) ) {
                alt11=1;
            }
            switch (alt11) {
                case 1 :
                    // InternalMyProject.g:1337:3: rule__Supermarket__Group_5__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Supermarket__Group_5__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getSupermarketAccess().getGroup_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__Group__5__Impl"


    // $ANTLR start "rule__Supermarket__Group__6"
    // InternalMyProject.g:1345:1: rule__Supermarket__Group__6 : rule__Supermarket__Group__6__Impl rule__Supermarket__Group__7 ;
    public final void rule__Supermarket__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1349:1: ( rule__Supermarket__Group__6__Impl rule__Supermarket__Group__7 )
            // InternalMyProject.g:1350:2: rule__Supermarket__Group__6__Impl rule__Supermarket__Group__7
            {
            pushFollow(FOLLOW_14);
            rule__Supermarket__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Supermarket__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__Group__6"


    // $ANTLR start "rule__Supermarket__Group__6__Impl"
    // InternalMyProject.g:1357:1: rule__Supermarket__Group__6__Impl : ( ( rule__Supermarket__Group_6__0 )? ) ;
    public final void rule__Supermarket__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1361:1: ( ( ( rule__Supermarket__Group_6__0 )? ) )
            // InternalMyProject.g:1362:1: ( ( rule__Supermarket__Group_6__0 )? )
            {
            // InternalMyProject.g:1362:1: ( ( rule__Supermarket__Group_6__0 )? )
            // InternalMyProject.g:1363:2: ( rule__Supermarket__Group_6__0 )?
            {
             before(grammarAccess.getSupermarketAccess().getGroup_6()); 
            // InternalMyProject.g:1364:2: ( rule__Supermarket__Group_6__0 )?
            int alt12=2;
            int LA12_0 = input.LA(1);

            if ( (LA12_0==35) ) {
                alt12=1;
            }
            switch (alt12) {
                case 1 :
                    // InternalMyProject.g:1364:3: rule__Supermarket__Group_6__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Supermarket__Group_6__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getSupermarketAccess().getGroup_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__Group__6__Impl"


    // $ANTLR start "rule__Supermarket__Group__7"
    // InternalMyProject.g:1372:1: rule__Supermarket__Group__7 : rule__Supermarket__Group__7__Impl rule__Supermarket__Group__8 ;
    public final void rule__Supermarket__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1376:1: ( rule__Supermarket__Group__7__Impl rule__Supermarket__Group__8 )
            // InternalMyProject.g:1377:2: rule__Supermarket__Group__7__Impl rule__Supermarket__Group__8
            {
            pushFollow(FOLLOW_14);
            rule__Supermarket__Group__7__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Supermarket__Group__8();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__Group__7"


    // $ANTLR start "rule__Supermarket__Group__7__Impl"
    // InternalMyProject.g:1384:1: rule__Supermarket__Group__7__Impl : ( ( rule__Supermarket__Group_7__0 )? ) ;
    public final void rule__Supermarket__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1388:1: ( ( ( rule__Supermarket__Group_7__0 )? ) )
            // InternalMyProject.g:1389:1: ( ( rule__Supermarket__Group_7__0 )? )
            {
            // InternalMyProject.g:1389:1: ( ( rule__Supermarket__Group_7__0 )? )
            // InternalMyProject.g:1390:2: ( rule__Supermarket__Group_7__0 )?
            {
             before(grammarAccess.getSupermarketAccess().getGroup_7()); 
            // InternalMyProject.g:1391:2: ( rule__Supermarket__Group_7__0 )?
            int alt13=2;
            int LA13_0 = input.LA(1);

            if ( (LA13_0==36) ) {
                alt13=1;
            }
            switch (alt13) {
                case 1 :
                    // InternalMyProject.g:1391:3: rule__Supermarket__Group_7__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Supermarket__Group_7__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getSupermarketAccess().getGroup_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__Group__7__Impl"


    // $ANTLR start "rule__Supermarket__Group__8"
    // InternalMyProject.g:1399:1: rule__Supermarket__Group__8 : rule__Supermarket__Group__8__Impl rule__Supermarket__Group__9 ;
    public final void rule__Supermarket__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1403:1: ( rule__Supermarket__Group__8__Impl rule__Supermarket__Group__9 )
            // InternalMyProject.g:1404:2: rule__Supermarket__Group__8__Impl rule__Supermarket__Group__9
            {
            pushFollow(FOLLOW_14);
            rule__Supermarket__Group__8__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Supermarket__Group__9();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__Group__8"


    // $ANTLR start "rule__Supermarket__Group__8__Impl"
    // InternalMyProject.g:1411:1: rule__Supermarket__Group__8__Impl : ( ( rule__Supermarket__Group_8__0 )? ) ;
    public final void rule__Supermarket__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1415:1: ( ( ( rule__Supermarket__Group_8__0 )? ) )
            // InternalMyProject.g:1416:1: ( ( rule__Supermarket__Group_8__0 )? )
            {
            // InternalMyProject.g:1416:1: ( ( rule__Supermarket__Group_8__0 )? )
            // InternalMyProject.g:1417:2: ( rule__Supermarket__Group_8__0 )?
            {
             before(grammarAccess.getSupermarketAccess().getGroup_8()); 
            // InternalMyProject.g:1418:2: ( rule__Supermarket__Group_8__0 )?
            int alt14=2;
            int LA14_0 = input.LA(1);

            if ( (LA14_0==37) ) {
                alt14=1;
            }
            switch (alt14) {
                case 1 :
                    // InternalMyProject.g:1418:3: rule__Supermarket__Group_8__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Supermarket__Group_8__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getSupermarketAccess().getGroup_8()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__Group__8__Impl"


    // $ANTLR start "rule__Supermarket__Group__9"
    // InternalMyProject.g:1426:1: rule__Supermarket__Group__9 : rule__Supermarket__Group__9__Impl rule__Supermarket__Group__10 ;
    public final void rule__Supermarket__Group__9() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1430:1: ( rule__Supermarket__Group__9__Impl rule__Supermarket__Group__10 )
            // InternalMyProject.g:1431:2: rule__Supermarket__Group__9__Impl rule__Supermarket__Group__10
            {
            pushFollow(FOLLOW_3);
            rule__Supermarket__Group__9__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Supermarket__Group__10();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__Group__9"


    // $ANTLR start "rule__Supermarket__Group__9__Impl"
    // InternalMyProject.g:1438:1: rule__Supermarket__Group__9__Impl : ( 'sections' ) ;
    public final void rule__Supermarket__Group__9__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1442:1: ( ( 'sections' ) )
            // InternalMyProject.g:1443:1: ( 'sections' )
            {
            // InternalMyProject.g:1443:1: ( 'sections' )
            // InternalMyProject.g:1444:2: 'sections'
            {
             before(grammarAccess.getSupermarketAccess().getSectionsKeyword_9()); 
            match(input,31,FOLLOW_2); 
             after(grammarAccess.getSupermarketAccess().getSectionsKeyword_9()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__Group__9__Impl"


    // $ANTLR start "rule__Supermarket__Group__10"
    // InternalMyProject.g:1453:1: rule__Supermarket__Group__10 : rule__Supermarket__Group__10__Impl rule__Supermarket__Group__11 ;
    public final void rule__Supermarket__Group__10() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1457:1: ( rule__Supermarket__Group__10__Impl rule__Supermarket__Group__11 )
            // InternalMyProject.g:1458:2: rule__Supermarket__Group__10__Impl rule__Supermarket__Group__11
            {
            pushFollow(FOLLOW_15);
            rule__Supermarket__Group__10__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Supermarket__Group__11();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__Group__10"


    // $ANTLR start "rule__Supermarket__Group__10__Impl"
    // InternalMyProject.g:1465:1: rule__Supermarket__Group__10__Impl : ( '{' ) ;
    public final void rule__Supermarket__Group__10__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1469:1: ( ( '{' ) )
            // InternalMyProject.g:1470:1: ( '{' )
            {
            // InternalMyProject.g:1470:1: ( '{' )
            // InternalMyProject.g:1471:2: '{'
            {
             before(grammarAccess.getSupermarketAccess().getLeftCurlyBracketKeyword_10()); 
            match(input,20,FOLLOW_2); 
             after(grammarAccess.getSupermarketAccess().getLeftCurlyBracketKeyword_10()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__Group__10__Impl"


    // $ANTLR start "rule__Supermarket__Group__11"
    // InternalMyProject.g:1480:1: rule__Supermarket__Group__11 : rule__Supermarket__Group__11__Impl rule__Supermarket__Group__12 ;
    public final void rule__Supermarket__Group__11() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1484:1: ( rule__Supermarket__Group__11__Impl rule__Supermarket__Group__12 )
            // InternalMyProject.g:1485:2: rule__Supermarket__Group__11__Impl rule__Supermarket__Group__12
            {
            pushFollow(FOLLOW_6);
            rule__Supermarket__Group__11__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Supermarket__Group__12();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__Group__11"


    // $ANTLR start "rule__Supermarket__Group__11__Impl"
    // InternalMyProject.g:1492:1: rule__Supermarket__Group__11__Impl : ( ( rule__Supermarket__SectionsAssignment_11 ) ) ;
    public final void rule__Supermarket__Group__11__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1496:1: ( ( ( rule__Supermarket__SectionsAssignment_11 ) ) )
            // InternalMyProject.g:1497:1: ( ( rule__Supermarket__SectionsAssignment_11 ) )
            {
            // InternalMyProject.g:1497:1: ( ( rule__Supermarket__SectionsAssignment_11 ) )
            // InternalMyProject.g:1498:2: ( rule__Supermarket__SectionsAssignment_11 )
            {
             before(grammarAccess.getSupermarketAccess().getSectionsAssignment_11()); 
            // InternalMyProject.g:1499:2: ( rule__Supermarket__SectionsAssignment_11 )
            // InternalMyProject.g:1499:3: rule__Supermarket__SectionsAssignment_11
            {
            pushFollow(FOLLOW_2);
            rule__Supermarket__SectionsAssignment_11();

            state._fsp--;


            }

             after(grammarAccess.getSupermarketAccess().getSectionsAssignment_11()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__Group__11__Impl"


    // $ANTLR start "rule__Supermarket__Group__12"
    // InternalMyProject.g:1507:1: rule__Supermarket__Group__12 : rule__Supermarket__Group__12__Impl rule__Supermarket__Group__13 ;
    public final void rule__Supermarket__Group__12() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1511:1: ( rule__Supermarket__Group__12__Impl rule__Supermarket__Group__13 )
            // InternalMyProject.g:1512:2: rule__Supermarket__Group__12__Impl rule__Supermarket__Group__13
            {
            pushFollow(FOLLOW_6);
            rule__Supermarket__Group__12__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Supermarket__Group__13();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__Group__12"


    // $ANTLR start "rule__Supermarket__Group__12__Impl"
    // InternalMyProject.g:1519:1: rule__Supermarket__Group__12__Impl : ( ( rule__Supermarket__Group_12__0 )* ) ;
    public final void rule__Supermarket__Group__12__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1523:1: ( ( ( rule__Supermarket__Group_12__0 )* ) )
            // InternalMyProject.g:1524:1: ( ( rule__Supermarket__Group_12__0 )* )
            {
            // InternalMyProject.g:1524:1: ( ( rule__Supermarket__Group_12__0 )* )
            // InternalMyProject.g:1525:2: ( rule__Supermarket__Group_12__0 )*
            {
             before(grammarAccess.getSupermarketAccess().getGroup_12()); 
            // InternalMyProject.g:1526:2: ( rule__Supermarket__Group_12__0 )*
            loop15:
            do {
                int alt15=2;
                int LA15_0 = input.LA(1);

                if ( (LA15_0==26) ) {
                    alt15=1;
                }


                switch (alt15) {
            	case 1 :
            	    // InternalMyProject.g:1526:3: rule__Supermarket__Group_12__0
            	    {
            	    pushFollow(FOLLOW_7);
            	    rule__Supermarket__Group_12__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop15;
                }
            } while (true);

             after(grammarAccess.getSupermarketAccess().getGroup_12()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__Group__12__Impl"


    // $ANTLR start "rule__Supermarket__Group__13"
    // InternalMyProject.g:1534:1: rule__Supermarket__Group__13 : rule__Supermarket__Group__13__Impl rule__Supermarket__Group__14 ;
    public final void rule__Supermarket__Group__13() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1538:1: ( rule__Supermarket__Group__13__Impl rule__Supermarket__Group__14 )
            // InternalMyProject.g:1539:2: rule__Supermarket__Group__13__Impl rule__Supermarket__Group__14
            {
            pushFollow(FOLLOW_8);
            rule__Supermarket__Group__13__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Supermarket__Group__14();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__Group__13"


    // $ANTLR start "rule__Supermarket__Group__13__Impl"
    // InternalMyProject.g:1546:1: rule__Supermarket__Group__13__Impl : ( '}' ) ;
    public final void rule__Supermarket__Group__13__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1550:1: ( ( '}' ) )
            // InternalMyProject.g:1551:1: ( '}' )
            {
            // InternalMyProject.g:1551:1: ( '}' )
            // InternalMyProject.g:1552:2: '}'
            {
             before(grammarAccess.getSupermarketAccess().getRightCurlyBracketKeyword_13()); 
            match(input,22,FOLLOW_2); 
             after(grammarAccess.getSupermarketAccess().getRightCurlyBracketKeyword_13()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__Group__13__Impl"


    // $ANTLR start "rule__Supermarket__Group__14"
    // InternalMyProject.g:1561:1: rule__Supermarket__Group__14 : rule__Supermarket__Group__14__Impl ;
    public final void rule__Supermarket__Group__14() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1565:1: ( rule__Supermarket__Group__14__Impl )
            // InternalMyProject.g:1566:2: rule__Supermarket__Group__14__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Supermarket__Group__14__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__Group__14"


    // $ANTLR start "rule__Supermarket__Group__14__Impl"
    // InternalMyProject.g:1572:1: rule__Supermarket__Group__14__Impl : ( '}' ) ;
    public final void rule__Supermarket__Group__14__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1576:1: ( ( '}' ) )
            // InternalMyProject.g:1577:1: ( '}' )
            {
            // InternalMyProject.g:1577:1: ( '}' )
            // InternalMyProject.g:1578:2: '}'
            {
             before(grammarAccess.getSupermarketAccess().getRightCurlyBracketKeyword_14()); 
            match(input,22,FOLLOW_2); 
             after(grammarAccess.getSupermarketAccess().getRightCurlyBracketKeyword_14()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__Group__14__Impl"


    // $ANTLR start "rule__Supermarket__Group_3__0"
    // InternalMyProject.g:1588:1: rule__Supermarket__Group_3__0 : rule__Supermarket__Group_3__0__Impl rule__Supermarket__Group_3__1 ;
    public final void rule__Supermarket__Group_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1592:1: ( rule__Supermarket__Group_3__0__Impl rule__Supermarket__Group_3__1 )
            // InternalMyProject.g:1593:2: rule__Supermarket__Group_3__0__Impl rule__Supermarket__Group_3__1
            {
            pushFollow(FOLLOW_9);
            rule__Supermarket__Group_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Supermarket__Group_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__Group_3__0"


    // $ANTLR start "rule__Supermarket__Group_3__0__Impl"
    // InternalMyProject.g:1600:1: rule__Supermarket__Group_3__0__Impl : ( 'supervisorName' ) ;
    public final void rule__Supermarket__Group_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1604:1: ( ( 'supervisorName' ) )
            // InternalMyProject.g:1605:1: ( 'supervisorName' )
            {
            // InternalMyProject.g:1605:1: ( 'supervisorName' )
            // InternalMyProject.g:1606:2: 'supervisorName'
            {
             before(grammarAccess.getSupermarketAccess().getSupervisorNameKeyword_3_0()); 
            match(input,32,FOLLOW_2); 
             after(grammarAccess.getSupermarketAccess().getSupervisorNameKeyword_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__Group_3__0__Impl"


    // $ANTLR start "rule__Supermarket__Group_3__1"
    // InternalMyProject.g:1615:1: rule__Supermarket__Group_3__1 : rule__Supermarket__Group_3__1__Impl ;
    public final void rule__Supermarket__Group_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1619:1: ( rule__Supermarket__Group_3__1__Impl )
            // InternalMyProject.g:1620:2: rule__Supermarket__Group_3__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Supermarket__Group_3__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__Group_3__1"


    // $ANTLR start "rule__Supermarket__Group_3__1__Impl"
    // InternalMyProject.g:1626:1: rule__Supermarket__Group_3__1__Impl : ( ( rule__Supermarket__SupervisorNameAssignment_3_1 ) ) ;
    public final void rule__Supermarket__Group_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1630:1: ( ( ( rule__Supermarket__SupervisorNameAssignment_3_1 ) ) )
            // InternalMyProject.g:1631:1: ( ( rule__Supermarket__SupervisorNameAssignment_3_1 ) )
            {
            // InternalMyProject.g:1631:1: ( ( rule__Supermarket__SupervisorNameAssignment_3_1 ) )
            // InternalMyProject.g:1632:2: ( rule__Supermarket__SupervisorNameAssignment_3_1 )
            {
             before(grammarAccess.getSupermarketAccess().getSupervisorNameAssignment_3_1()); 
            // InternalMyProject.g:1633:2: ( rule__Supermarket__SupervisorNameAssignment_3_1 )
            // InternalMyProject.g:1633:3: rule__Supermarket__SupervisorNameAssignment_3_1
            {
            pushFollow(FOLLOW_2);
            rule__Supermarket__SupervisorNameAssignment_3_1();

            state._fsp--;


            }

             after(grammarAccess.getSupermarketAccess().getSupervisorNameAssignment_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__Group_3__1__Impl"


    // $ANTLR start "rule__Supermarket__Group_4__0"
    // InternalMyProject.g:1642:1: rule__Supermarket__Group_4__0 : rule__Supermarket__Group_4__0__Impl rule__Supermarket__Group_4__1 ;
    public final void rule__Supermarket__Group_4__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1646:1: ( rule__Supermarket__Group_4__0__Impl rule__Supermarket__Group_4__1 )
            // InternalMyProject.g:1647:2: rule__Supermarket__Group_4__0__Impl rule__Supermarket__Group_4__1
            {
            pushFollow(FOLLOW_16);
            rule__Supermarket__Group_4__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Supermarket__Group_4__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__Group_4__0"


    // $ANTLR start "rule__Supermarket__Group_4__0__Impl"
    // InternalMyProject.g:1654:1: rule__Supermarket__Group_4__0__Impl : ( 'employeeAmount' ) ;
    public final void rule__Supermarket__Group_4__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1658:1: ( ( 'employeeAmount' ) )
            // InternalMyProject.g:1659:1: ( 'employeeAmount' )
            {
            // InternalMyProject.g:1659:1: ( 'employeeAmount' )
            // InternalMyProject.g:1660:2: 'employeeAmount'
            {
             before(grammarAccess.getSupermarketAccess().getEmployeeAmountKeyword_4_0()); 
            match(input,33,FOLLOW_2); 
             after(grammarAccess.getSupermarketAccess().getEmployeeAmountKeyword_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__Group_4__0__Impl"


    // $ANTLR start "rule__Supermarket__Group_4__1"
    // InternalMyProject.g:1669:1: rule__Supermarket__Group_4__1 : rule__Supermarket__Group_4__1__Impl ;
    public final void rule__Supermarket__Group_4__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1673:1: ( rule__Supermarket__Group_4__1__Impl )
            // InternalMyProject.g:1674:2: rule__Supermarket__Group_4__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Supermarket__Group_4__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__Group_4__1"


    // $ANTLR start "rule__Supermarket__Group_4__1__Impl"
    // InternalMyProject.g:1680:1: rule__Supermarket__Group_4__1__Impl : ( ( rule__Supermarket__EmployeeAmountAssignment_4_1 ) ) ;
    public final void rule__Supermarket__Group_4__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1684:1: ( ( ( rule__Supermarket__EmployeeAmountAssignment_4_1 ) ) )
            // InternalMyProject.g:1685:1: ( ( rule__Supermarket__EmployeeAmountAssignment_4_1 ) )
            {
            // InternalMyProject.g:1685:1: ( ( rule__Supermarket__EmployeeAmountAssignment_4_1 ) )
            // InternalMyProject.g:1686:2: ( rule__Supermarket__EmployeeAmountAssignment_4_1 )
            {
             before(grammarAccess.getSupermarketAccess().getEmployeeAmountAssignment_4_1()); 
            // InternalMyProject.g:1687:2: ( rule__Supermarket__EmployeeAmountAssignment_4_1 )
            // InternalMyProject.g:1687:3: rule__Supermarket__EmployeeAmountAssignment_4_1
            {
            pushFollow(FOLLOW_2);
            rule__Supermarket__EmployeeAmountAssignment_4_1();

            state._fsp--;


            }

             after(grammarAccess.getSupermarketAccess().getEmployeeAmountAssignment_4_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__Group_4__1__Impl"


    // $ANTLR start "rule__Supermarket__Group_5__0"
    // InternalMyProject.g:1696:1: rule__Supermarket__Group_5__0 : rule__Supermarket__Group_5__0__Impl rule__Supermarket__Group_5__1 ;
    public final void rule__Supermarket__Group_5__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1700:1: ( rule__Supermarket__Group_5__0__Impl rule__Supermarket__Group_5__1 )
            // InternalMyProject.g:1701:2: rule__Supermarket__Group_5__0__Impl rule__Supermarket__Group_5__1
            {
            pushFollow(FOLLOW_16);
            rule__Supermarket__Group_5__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Supermarket__Group_5__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__Group_5__0"


    // $ANTLR start "rule__Supermarket__Group_5__0__Impl"
    // InternalMyProject.g:1708:1: rule__Supermarket__Group_5__0__Impl : ( 'managerAmount' ) ;
    public final void rule__Supermarket__Group_5__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1712:1: ( ( 'managerAmount' ) )
            // InternalMyProject.g:1713:1: ( 'managerAmount' )
            {
            // InternalMyProject.g:1713:1: ( 'managerAmount' )
            // InternalMyProject.g:1714:2: 'managerAmount'
            {
             before(grammarAccess.getSupermarketAccess().getManagerAmountKeyword_5_0()); 
            match(input,34,FOLLOW_2); 
             after(grammarAccess.getSupermarketAccess().getManagerAmountKeyword_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__Group_5__0__Impl"


    // $ANTLR start "rule__Supermarket__Group_5__1"
    // InternalMyProject.g:1723:1: rule__Supermarket__Group_5__1 : rule__Supermarket__Group_5__1__Impl ;
    public final void rule__Supermarket__Group_5__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1727:1: ( rule__Supermarket__Group_5__1__Impl )
            // InternalMyProject.g:1728:2: rule__Supermarket__Group_5__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Supermarket__Group_5__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__Group_5__1"


    // $ANTLR start "rule__Supermarket__Group_5__1__Impl"
    // InternalMyProject.g:1734:1: rule__Supermarket__Group_5__1__Impl : ( ( rule__Supermarket__ManagerAmountAssignment_5_1 ) ) ;
    public final void rule__Supermarket__Group_5__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1738:1: ( ( ( rule__Supermarket__ManagerAmountAssignment_5_1 ) ) )
            // InternalMyProject.g:1739:1: ( ( rule__Supermarket__ManagerAmountAssignment_5_1 ) )
            {
            // InternalMyProject.g:1739:1: ( ( rule__Supermarket__ManagerAmountAssignment_5_1 ) )
            // InternalMyProject.g:1740:2: ( rule__Supermarket__ManagerAmountAssignment_5_1 )
            {
             before(grammarAccess.getSupermarketAccess().getManagerAmountAssignment_5_1()); 
            // InternalMyProject.g:1741:2: ( rule__Supermarket__ManagerAmountAssignment_5_1 )
            // InternalMyProject.g:1741:3: rule__Supermarket__ManagerAmountAssignment_5_1
            {
            pushFollow(FOLLOW_2);
            rule__Supermarket__ManagerAmountAssignment_5_1();

            state._fsp--;


            }

             after(grammarAccess.getSupermarketAccess().getManagerAmountAssignment_5_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__Group_5__1__Impl"


    // $ANTLR start "rule__Supermarket__Group_6__0"
    // InternalMyProject.g:1750:1: rule__Supermarket__Group_6__0 : rule__Supermarket__Group_6__0__Impl rule__Supermarket__Group_6__1 ;
    public final void rule__Supermarket__Group_6__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1754:1: ( rule__Supermarket__Group_6__0__Impl rule__Supermarket__Group_6__1 )
            // InternalMyProject.g:1755:2: rule__Supermarket__Group_6__0__Impl rule__Supermarket__Group_6__1
            {
            pushFollow(FOLLOW_16);
            rule__Supermarket__Group_6__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Supermarket__Group_6__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__Group_6__0"


    // $ANTLR start "rule__Supermarket__Group_6__0__Impl"
    // InternalMyProject.g:1762:1: rule__Supermarket__Group_6__0__Impl : ( 'floorNumber' ) ;
    public final void rule__Supermarket__Group_6__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1766:1: ( ( 'floorNumber' ) )
            // InternalMyProject.g:1767:1: ( 'floorNumber' )
            {
            // InternalMyProject.g:1767:1: ( 'floorNumber' )
            // InternalMyProject.g:1768:2: 'floorNumber'
            {
             before(grammarAccess.getSupermarketAccess().getFloorNumberKeyword_6_0()); 
            match(input,35,FOLLOW_2); 
             after(grammarAccess.getSupermarketAccess().getFloorNumberKeyword_6_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__Group_6__0__Impl"


    // $ANTLR start "rule__Supermarket__Group_6__1"
    // InternalMyProject.g:1777:1: rule__Supermarket__Group_6__1 : rule__Supermarket__Group_6__1__Impl ;
    public final void rule__Supermarket__Group_6__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1781:1: ( rule__Supermarket__Group_6__1__Impl )
            // InternalMyProject.g:1782:2: rule__Supermarket__Group_6__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Supermarket__Group_6__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__Group_6__1"


    // $ANTLR start "rule__Supermarket__Group_6__1__Impl"
    // InternalMyProject.g:1788:1: rule__Supermarket__Group_6__1__Impl : ( ( rule__Supermarket__FloorNumberAssignment_6_1 ) ) ;
    public final void rule__Supermarket__Group_6__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1792:1: ( ( ( rule__Supermarket__FloorNumberAssignment_6_1 ) ) )
            // InternalMyProject.g:1793:1: ( ( rule__Supermarket__FloorNumberAssignment_6_1 ) )
            {
            // InternalMyProject.g:1793:1: ( ( rule__Supermarket__FloorNumberAssignment_6_1 ) )
            // InternalMyProject.g:1794:2: ( rule__Supermarket__FloorNumberAssignment_6_1 )
            {
             before(grammarAccess.getSupermarketAccess().getFloorNumberAssignment_6_1()); 
            // InternalMyProject.g:1795:2: ( rule__Supermarket__FloorNumberAssignment_6_1 )
            // InternalMyProject.g:1795:3: rule__Supermarket__FloorNumberAssignment_6_1
            {
            pushFollow(FOLLOW_2);
            rule__Supermarket__FloorNumberAssignment_6_1();

            state._fsp--;


            }

             after(grammarAccess.getSupermarketAccess().getFloorNumberAssignment_6_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__Group_6__1__Impl"


    // $ANTLR start "rule__Supermarket__Group_7__0"
    // InternalMyProject.g:1804:1: rule__Supermarket__Group_7__0 : rule__Supermarket__Group_7__0__Impl rule__Supermarket__Group_7__1 ;
    public final void rule__Supermarket__Group_7__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1808:1: ( rule__Supermarket__Group_7__0__Impl rule__Supermarket__Group_7__1 )
            // InternalMyProject.g:1809:2: rule__Supermarket__Group_7__0__Impl rule__Supermarket__Group_7__1
            {
            pushFollow(FOLLOW_9);
            rule__Supermarket__Group_7__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Supermarket__Group_7__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__Group_7__0"


    // $ANTLR start "rule__Supermarket__Group_7__0__Impl"
    // InternalMyProject.g:1816:1: rule__Supermarket__Group_7__0__Impl : ( 'openingTime' ) ;
    public final void rule__Supermarket__Group_7__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1820:1: ( ( 'openingTime' ) )
            // InternalMyProject.g:1821:1: ( 'openingTime' )
            {
            // InternalMyProject.g:1821:1: ( 'openingTime' )
            // InternalMyProject.g:1822:2: 'openingTime'
            {
             before(grammarAccess.getSupermarketAccess().getOpeningTimeKeyword_7_0()); 
            match(input,36,FOLLOW_2); 
             after(grammarAccess.getSupermarketAccess().getOpeningTimeKeyword_7_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__Group_7__0__Impl"


    // $ANTLR start "rule__Supermarket__Group_7__1"
    // InternalMyProject.g:1831:1: rule__Supermarket__Group_7__1 : rule__Supermarket__Group_7__1__Impl ;
    public final void rule__Supermarket__Group_7__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1835:1: ( rule__Supermarket__Group_7__1__Impl )
            // InternalMyProject.g:1836:2: rule__Supermarket__Group_7__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Supermarket__Group_7__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__Group_7__1"


    // $ANTLR start "rule__Supermarket__Group_7__1__Impl"
    // InternalMyProject.g:1842:1: rule__Supermarket__Group_7__1__Impl : ( ( rule__Supermarket__OpeningTimeAssignment_7_1 ) ) ;
    public final void rule__Supermarket__Group_7__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1846:1: ( ( ( rule__Supermarket__OpeningTimeAssignment_7_1 ) ) )
            // InternalMyProject.g:1847:1: ( ( rule__Supermarket__OpeningTimeAssignment_7_1 ) )
            {
            // InternalMyProject.g:1847:1: ( ( rule__Supermarket__OpeningTimeAssignment_7_1 ) )
            // InternalMyProject.g:1848:2: ( rule__Supermarket__OpeningTimeAssignment_7_1 )
            {
             before(grammarAccess.getSupermarketAccess().getOpeningTimeAssignment_7_1()); 
            // InternalMyProject.g:1849:2: ( rule__Supermarket__OpeningTimeAssignment_7_1 )
            // InternalMyProject.g:1849:3: rule__Supermarket__OpeningTimeAssignment_7_1
            {
            pushFollow(FOLLOW_2);
            rule__Supermarket__OpeningTimeAssignment_7_1();

            state._fsp--;


            }

             after(grammarAccess.getSupermarketAccess().getOpeningTimeAssignment_7_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__Group_7__1__Impl"


    // $ANTLR start "rule__Supermarket__Group_8__0"
    // InternalMyProject.g:1858:1: rule__Supermarket__Group_8__0 : rule__Supermarket__Group_8__0__Impl rule__Supermarket__Group_8__1 ;
    public final void rule__Supermarket__Group_8__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1862:1: ( rule__Supermarket__Group_8__0__Impl rule__Supermarket__Group_8__1 )
            // InternalMyProject.g:1863:2: rule__Supermarket__Group_8__0__Impl rule__Supermarket__Group_8__1
            {
            pushFollow(FOLLOW_9);
            rule__Supermarket__Group_8__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Supermarket__Group_8__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__Group_8__0"


    // $ANTLR start "rule__Supermarket__Group_8__0__Impl"
    // InternalMyProject.g:1870:1: rule__Supermarket__Group_8__0__Impl : ( 'closingTime' ) ;
    public final void rule__Supermarket__Group_8__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1874:1: ( ( 'closingTime' ) )
            // InternalMyProject.g:1875:1: ( 'closingTime' )
            {
            // InternalMyProject.g:1875:1: ( 'closingTime' )
            // InternalMyProject.g:1876:2: 'closingTime'
            {
             before(grammarAccess.getSupermarketAccess().getClosingTimeKeyword_8_0()); 
            match(input,37,FOLLOW_2); 
             after(grammarAccess.getSupermarketAccess().getClosingTimeKeyword_8_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__Group_8__0__Impl"


    // $ANTLR start "rule__Supermarket__Group_8__1"
    // InternalMyProject.g:1885:1: rule__Supermarket__Group_8__1 : rule__Supermarket__Group_8__1__Impl ;
    public final void rule__Supermarket__Group_8__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1889:1: ( rule__Supermarket__Group_8__1__Impl )
            // InternalMyProject.g:1890:2: rule__Supermarket__Group_8__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Supermarket__Group_8__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__Group_8__1"


    // $ANTLR start "rule__Supermarket__Group_8__1__Impl"
    // InternalMyProject.g:1896:1: rule__Supermarket__Group_8__1__Impl : ( ( rule__Supermarket__ClosingTimeAssignment_8_1 ) ) ;
    public final void rule__Supermarket__Group_8__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1900:1: ( ( ( rule__Supermarket__ClosingTimeAssignment_8_1 ) ) )
            // InternalMyProject.g:1901:1: ( ( rule__Supermarket__ClosingTimeAssignment_8_1 ) )
            {
            // InternalMyProject.g:1901:1: ( ( rule__Supermarket__ClosingTimeAssignment_8_1 ) )
            // InternalMyProject.g:1902:2: ( rule__Supermarket__ClosingTimeAssignment_8_1 )
            {
             before(grammarAccess.getSupermarketAccess().getClosingTimeAssignment_8_1()); 
            // InternalMyProject.g:1903:2: ( rule__Supermarket__ClosingTimeAssignment_8_1 )
            // InternalMyProject.g:1903:3: rule__Supermarket__ClosingTimeAssignment_8_1
            {
            pushFollow(FOLLOW_2);
            rule__Supermarket__ClosingTimeAssignment_8_1();

            state._fsp--;


            }

             after(grammarAccess.getSupermarketAccess().getClosingTimeAssignment_8_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__Group_8__1__Impl"


    // $ANTLR start "rule__Supermarket__Group_12__0"
    // InternalMyProject.g:1912:1: rule__Supermarket__Group_12__0 : rule__Supermarket__Group_12__0__Impl rule__Supermarket__Group_12__1 ;
    public final void rule__Supermarket__Group_12__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1916:1: ( rule__Supermarket__Group_12__0__Impl rule__Supermarket__Group_12__1 )
            // InternalMyProject.g:1917:2: rule__Supermarket__Group_12__0__Impl rule__Supermarket__Group_12__1
            {
            pushFollow(FOLLOW_15);
            rule__Supermarket__Group_12__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Supermarket__Group_12__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__Group_12__0"


    // $ANTLR start "rule__Supermarket__Group_12__0__Impl"
    // InternalMyProject.g:1924:1: rule__Supermarket__Group_12__0__Impl : ( ',' ) ;
    public final void rule__Supermarket__Group_12__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1928:1: ( ( ',' ) )
            // InternalMyProject.g:1929:1: ( ',' )
            {
            // InternalMyProject.g:1929:1: ( ',' )
            // InternalMyProject.g:1930:2: ','
            {
             before(grammarAccess.getSupermarketAccess().getCommaKeyword_12_0()); 
            match(input,26,FOLLOW_2); 
             after(grammarAccess.getSupermarketAccess().getCommaKeyword_12_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__Group_12__0__Impl"


    // $ANTLR start "rule__Supermarket__Group_12__1"
    // InternalMyProject.g:1939:1: rule__Supermarket__Group_12__1 : rule__Supermarket__Group_12__1__Impl ;
    public final void rule__Supermarket__Group_12__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1943:1: ( rule__Supermarket__Group_12__1__Impl )
            // InternalMyProject.g:1944:2: rule__Supermarket__Group_12__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Supermarket__Group_12__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__Group_12__1"


    // $ANTLR start "rule__Supermarket__Group_12__1__Impl"
    // InternalMyProject.g:1950:1: rule__Supermarket__Group_12__1__Impl : ( ( rule__Supermarket__SectionsAssignment_12_1 ) ) ;
    public final void rule__Supermarket__Group_12__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1954:1: ( ( ( rule__Supermarket__SectionsAssignment_12_1 ) ) )
            // InternalMyProject.g:1955:1: ( ( rule__Supermarket__SectionsAssignment_12_1 ) )
            {
            // InternalMyProject.g:1955:1: ( ( rule__Supermarket__SectionsAssignment_12_1 ) )
            // InternalMyProject.g:1956:2: ( rule__Supermarket__SectionsAssignment_12_1 )
            {
             before(grammarAccess.getSupermarketAccess().getSectionsAssignment_12_1()); 
            // InternalMyProject.g:1957:2: ( rule__Supermarket__SectionsAssignment_12_1 )
            // InternalMyProject.g:1957:3: rule__Supermarket__SectionsAssignment_12_1
            {
            pushFollow(FOLLOW_2);
            rule__Supermarket__SectionsAssignment_12_1();

            state._fsp--;


            }

             after(grammarAccess.getSupermarketAccess().getSectionsAssignment_12_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__Group_12__1__Impl"


    // $ANTLR start "rule__ClothingStore__Group__0"
    // InternalMyProject.g:1966:1: rule__ClothingStore__Group__0 : rule__ClothingStore__Group__0__Impl rule__ClothingStore__Group__1 ;
    public final void rule__ClothingStore__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1970:1: ( rule__ClothingStore__Group__0__Impl rule__ClothingStore__Group__1 )
            // InternalMyProject.g:1971:2: rule__ClothingStore__Group__0__Impl rule__ClothingStore__Group__1
            {
            pushFollow(FOLLOW_13);
            rule__ClothingStore__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ClothingStore__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClothingStore__Group__0"


    // $ANTLR start "rule__ClothingStore__Group__0__Impl"
    // InternalMyProject.g:1978:1: rule__ClothingStore__Group__0__Impl : ( () ) ;
    public final void rule__ClothingStore__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1982:1: ( ( () ) )
            // InternalMyProject.g:1983:1: ( () )
            {
            // InternalMyProject.g:1983:1: ( () )
            // InternalMyProject.g:1984:2: ()
            {
             before(grammarAccess.getClothingStoreAccess().getClothingStoreAction_0()); 
            // InternalMyProject.g:1985:2: ()
            // InternalMyProject.g:1985:3: 
            {
            }

             after(grammarAccess.getClothingStoreAccess().getClothingStoreAction_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClothingStore__Group__0__Impl"


    // $ANTLR start "rule__ClothingStore__Group__1"
    // InternalMyProject.g:1993:1: rule__ClothingStore__Group__1 : rule__ClothingStore__Group__1__Impl rule__ClothingStore__Group__2 ;
    public final void rule__ClothingStore__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:1997:1: ( rule__ClothingStore__Group__1__Impl rule__ClothingStore__Group__2 )
            // InternalMyProject.g:1998:2: rule__ClothingStore__Group__1__Impl rule__ClothingStore__Group__2
            {
            pushFollow(FOLLOW_9);
            rule__ClothingStore__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ClothingStore__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClothingStore__Group__1"


    // $ANTLR start "rule__ClothingStore__Group__1__Impl"
    // InternalMyProject.g:2005:1: rule__ClothingStore__Group__1__Impl : ( 'ClothingStore' ) ;
    public final void rule__ClothingStore__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2009:1: ( ( 'ClothingStore' ) )
            // InternalMyProject.g:2010:1: ( 'ClothingStore' )
            {
            // InternalMyProject.g:2010:1: ( 'ClothingStore' )
            // InternalMyProject.g:2011:2: 'ClothingStore'
            {
             before(grammarAccess.getClothingStoreAccess().getClothingStoreKeyword_1()); 
            match(input,38,FOLLOW_2); 
             after(grammarAccess.getClothingStoreAccess().getClothingStoreKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClothingStore__Group__1__Impl"


    // $ANTLR start "rule__ClothingStore__Group__2"
    // InternalMyProject.g:2020:1: rule__ClothingStore__Group__2 : rule__ClothingStore__Group__2__Impl rule__ClothingStore__Group__3 ;
    public final void rule__ClothingStore__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2024:1: ( rule__ClothingStore__Group__2__Impl rule__ClothingStore__Group__3 )
            // InternalMyProject.g:2025:2: rule__ClothingStore__Group__2__Impl rule__ClothingStore__Group__3
            {
            pushFollow(FOLLOW_3);
            rule__ClothingStore__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ClothingStore__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClothingStore__Group__2"


    // $ANTLR start "rule__ClothingStore__Group__2__Impl"
    // InternalMyProject.g:2032:1: rule__ClothingStore__Group__2__Impl : ( ( rule__ClothingStore__NameAssignment_2 ) ) ;
    public final void rule__ClothingStore__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2036:1: ( ( ( rule__ClothingStore__NameAssignment_2 ) ) )
            // InternalMyProject.g:2037:1: ( ( rule__ClothingStore__NameAssignment_2 ) )
            {
            // InternalMyProject.g:2037:1: ( ( rule__ClothingStore__NameAssignment_2 ) )
            // InternalMyProject.g:2038:2: ( rule__ClothingStore__NameAssignment_2 )
            {
             before(grammarAccess.getClothingStoreAccess().getNameAssignment_2()); 
            // InternalMyProject.g:2039:2: ( rule__ClothingStore__NameAssignment_2 )
            // InternalMyProject.g:2039:3: rule__ClothingStore__NameAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__ClothingStore__NameAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getClothingStoreAccess().getNameAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClothingStore__Group__2__Impl"


    // $ANTLR start "rule__ClothingStore__Group__3"
    // InternalMyProject.g:2047:1: rule__ClothingStore__Group__3 : rule__ClothingStore__Group__3__Impl rule__ClothingStore__Group__4 ;
    public final void rule__ClothingStore__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2051:1: ( rule__ClothingStore__Group__3__Impl rule__ClothingStore__Group__4 )
            // InternalMyProject.g:2052:2: rule__ClothingStore__Group__3__Impl rule__ClothingStore__Group__4
            {
            pushFollow(FOLLOW_17);
            rule__ClothingStore__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ClothingStore__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClothingStore__Group__3"


    // $ANTLR start "rule__ClothingStore__Group__3__Impl"
    // InternalMyProject.g:2059:1: rule__ClothingStore__Group__3__Impl : ( '{' ) ;
    public final void rule__ClothingStore__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2063:1: ( ( '{' ) )
            // InternalMyProject.g:2064:1: ( '{' )
            {
            // InternalMyProject.g:2064:1: ( '{' )
            // InternalMyProject.g:2065:2: '{'
            {
             before(grammarAccess.getClothingStoreAccess().getLeftCurlyBracketKeyword_3()); 
            match(input,20,FOLLOW_2); 
             after(grammarAccess.getClothingStoreAccess().getLeftCurlyBracketKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClothingStore__Group__3__Impl"


    // $ANTLR start "rule__ClothingStore__Group__4"
    // InternalMyProject.g:2074:1: rule__ClothingStore__Group__4 : rule__ClothingStore__Group__4__Impl rule__ClothingStore__Group__5 ;
    public final void rule__ClothingStore__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2078:1: ( rule__ClothingStore__Group__4__Impl rule__ClothingStore__Group__5 )
            // InternalMyProject.g:2079:2: rule__ClothingStore__Group__4__Impl rule__ClothingStore__Group__5
            {
            pushFollow(FOLLOW_17);
            rule__ClothingStore__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ClothingStore__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClothingStore__Group__4"


    // $ANTLR start "rule__ClothingStore__Group__4__Impl"
    // InternalMyProject.g:2086:1: rule__ClothingStore__Group__4__Impl : ( ( rule__ClothingStore__Group_4__0 )? ) ;
    public final void rule__ClothingStore__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2090:1: ( ( ( rule__ClothingStore__Group_4__0 )? ) )
            // InternalMyProject.g:2091:1: ( ( rule__ClothingStore__Group_4__0 )? )
            {
            // InternalMyProject.g:2091:1: ( ( rule__ClothingStore__Group_4__0 )? )
            // InternalMyProject.g:2092:2: ( rule__ClothingStore__Group_4__0 )?
            {
             before(grammarAccess.getClothingStoreAccess().getGroup_4()); 
            // InternalMyProject.g:2093:2: ( rule__ClothingStore__Group_4__0 )?
            int alt16=2;
            int LA16_0 = input.LA(1);

            if ( (LA16_0==32) ) {
                alt16=1;
            }
            switch (alt16) {
                case 1 :
                    // InternalMyProject.g:2093:3: rule__ClothingStore__Group_4__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__ClothingStore__Group_4__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getClothingStoreAccess().getGroup_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClothingStore__Group__4__Impl"


    // $ANTLR start "rule__ClothingStore__Group__5"
    // InternalMyProject.g:2101:1: rule__ClothingStore__Group__5 : rule__ClothingStore__Group__5__Impl rule__ClothingStore__Group__6 ;
    public final void rule__ClothingStore__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2105:1: ( rule__ClothingStore__Group__5__Impl rule__ClothingStore__Group__6 )
            // InternalMyProject.g:2106:2: rule__ClothingStore__Group__5__Impl rule__ClothingStore__Group__6
            {
            pushFollow(FOLLOW_17);
            rule__ClothingStore__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ClothingStore__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClothingStore__Group__5"


    // $ANTLR start "rule__ClothingStore__Group__5__Impl"
    // InternalMyProject.g:2113:1: rule__ClothingStore__Group__5__Impl : ( ( rule__ClothingStore__Group_5__0 )? ) ;
    public final void rule__ClothingStore__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2117:1: ( ( ( rule__ClothingStore__Group_5__0 )? ) )
            // InternalMyProject.g:2118:1: ( ( rule__ClothingStore__Group_5__0 )? )
            {
            // InternalMyProject.g:2118:1: ( ( rule__ClothingStore__Group_5__0 )? )
            // InternalMyProject.g:2119:2: ( rule__ClothingStore__Group_5__0 )?
            {
             before(grammarAccess.getClothingStoreAccess().getGroup_5()); 
            // InternalMyProject.g:2120:2: ( rule__ClothingStore__Group_5__0 )?
            int alt17=2;
            int LA17_0 = input.LA(1);

            if ( (LA17_0==33) ) {
                alt17=1;
            }
            switch (alt17) {
                case 1 :
                    // InternalMyProject.g:2120:3: rule__ClothingStore__Group_5__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__ClothingStore__Group_5__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getClothingStoreAccess().getGroup_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClothingStore__Group__5__Impl"


    // $ANTLR start "rule__ClothingStore__Group__6"
    // InternalMyProject.g:2128:1: rule__ClothingStore__Group__6 : rule__ClothingStore__Group__6__Impl rule__ClothingStore__Group__7 ;
    public final void rule__ClothingStore__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2132:1: ( rule__ClothingStore__Group__6__Impl rule__ClothingStore__Group__7 )
            // InternalMyProject.g:2133:2: rule__ClothingStore__Group__6__Impl rule__ClothingStore__Group__7
            {
            pushFollow(FOLLOW_17);
            rule__ClothingStore__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ClothingStore__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClothingStore__Group__6"


    // $ANTLR start "rule__ClothingStore__Group__6__Impl"
    // InternalMyProject.g:2140:1: rule__ClothingStore__Group__6__Impl : ( ( rule__ClothingStore__Group_6__0 )? ) ;
    public final void rule__ClothingStore__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2144:1: ( ( ( rule__ClothingStore__Group_6__0 )? ) )
            // InternalMyProject.g:2145:1: ( ( rule__ClothingStore__Group_6__0 )? )
            {
            // InternalMyProject.g:2145:1: ( ( rule__ClothingStore__Group_6__0 )? )
            // InternalMyProject.g:2146:2: ( rule__ClothingStore__Group_6__0 )?
            {
             before(grammarAccess.getClothingStoreAccess().getGroup_6()); 
            // InternalMyProject.g:2147:2: ( rule__ClothingStore__Group_6__0 )?
            int alt18=2;
            int LA18_0 = input.LA(1);

            if ( (LA18_0==34) ) {
                alt18=1;
            }
            switch (alt18) {
                case 1 :
                    // InternalMyProject.g:2147:3: rule__ClothingStore__Group_6__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__ClothingStore__Group_6__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getClothingStoreAccess().getGroup_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClothingStore__Group__6__Impl"


    // $ANTLR start "rule__ClothingStore__Group__7"
    // InternalMyProject.g:2155:1: rule__ClothingStore__Group__7 : rule__ClothingStore__Group__7__Impl rule__ClothingStore__Group__8 ;
    public final void rule__ClothingStore__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2159:1: ( rule__ClothingStore__Group__7__Impl rule__ClothingStore__Group__8 )
            // InternalMyProject.g:2160:2: rule__ClothingStore__Group__7__Impl rule__ClothingStore__Group__8
            {
            pushFollow(FOLLOW_17);
            rule__ClothingStore__Group__7__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ClothingStore__Group__8();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClothingStore__Group__7"


    // $ANTLR start "rule__ClothingStore__Group__7__Impl"
    // InternalMyProject.g:2167:1: rule__ClothingStore__Group__7__Impl : ( ( rule__ClothingStore__Group_7__0 )? ) ;
    public final void rule__ClothingStore__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2171:1: ( ( ( rule__ClothingStore__Group_7__0 )? ) )
            // InternalMyProject.g:2172:1: ( ( rule__ClothingStore__Group_7__0 )? )
            {
            // InternalMyProject.g:2172:1: ( ( rule__ClothingStore__Group_7__0 )? )
            // InternalMyProject.g:2173:2: ( rule__ClothingStore__Group_7__0 )?
            {
             before(grammarAccess.getClothingStoreAccess().getGroup_7()); 
            // InternalMyProject.g:2174:2: ( rule__ClothingStore__Group_7__0 )?
            int alt19=2;
            int LA19_0 = input.LA(1);

            if ( (LA19_0==35) ) {
                alt19=1;
            }
            switch (alt19) {
                case 1 :
                    // InternalMyProject.g:2174:3: rule__ClothingStore__Group_7__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__ClothingStore__Group_7__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getClothingStoreAccess().getGroup_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClothingStore__Group__7__Impl"


    // $ANTLR start "rule__ClothingStore__Group__8"
    // InternalMyProject.g:2182:1: rule__ClothingStore__Group__8 : rule__ClothingStore__Group__8__Impl rule__ClothingStore__Group__9 ;
    public final void rule__ClothingStore__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2186:1: ( rule__ClothingStore__Group__8__Impl rule__ClothingStore__Group__9 )
            // InternalMyProject.g:2187:2: rule__ClothingStore__Group__8__Impl rule__ClothingStore__Group__9
            {
            pushFollow(FOLLOW_17);
            rule__ClothingStore__Group__8__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ClothingStore__Group__9();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClothingStore__Group__8"


    // $ANTLR start "rule__ClothingStore__Group__8__Impl"
    // InternalMyProject.g:2194:1: rule__ClothingStore__Group__8__Impl : ( ( rule__ClothingStore__Group_8__0 )? ) ;
    public final void rule__ClothingStore__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2198:1: ( ( ( rule__ClothingStore__Group_8__0 )? ) )
            // InternalMyProject.g:2199:1: ( ( rule__ClothingStore__Group_8__0 )? )
            {
            // InternalMyProject.g:2199:1: ( ( rule__ClothingStore__Group_8__0 )? )
            // InternalMyProject.g:2200:2: ( rule__ClothingStore__Group_8__0 )?
            {
             before(grammarAccess.getClothingStoreAccess().getGroup_8()); 
            // InternalMyProject.g:2201:2: ( rule__ClothingStore__Group_8__0 )?
            int alt20=2;
            int LA20_0 = input.LA(1);

            if ( (LA20_0==39) ) {
                alt20=1;
            }
            switch (alt20) {
                case 1 :
                    // InternalMyProject.g:2201:3: rule__ClothingStore__Group_8__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__ClothingStore__Group_8__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getClothingStoreAccess().getGroup_8()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClothingStore__Group__8__Impl"


    // $ANTLR start "rule__ClothingStore__Group__9"
    // InternalMyProject.g:2209:1: rule__ClothingStore__Group__9 : rule__ClothingStore__Group__9__Impl ;
    public final void rule__ClothingStore__Group__9() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2213:1: ( rule__ClothingStore__Group__9__Impl )
            // InternalMyProject.g:2214:2: rule__ClothingStore__Group__9__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ClothingStore__Group__9__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClothingStore__Group__9"


    // $ANTLR start "rule__ClothingStore__Group__9__Impl"
    // InternalMyProject.g:2220:1: rule__ClothingStore__Group__9__Impl : ( '}' ) ;
    public final void rule__ClothingStore__Group__9__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2224:1: ( ( '}' ) )
            // InternalMyProject.g:2225:1: ( '}' )
            {
            // InternalMyProject.g:2225:1: ( '}' )
            // InternalMyProject.g:2226:2: '}'
            {
             before(grammarAccess.getClothingStoreAccess().getRightCurlyBracketKeyword_9()); 
            match(input,22,FOLLOW_2); 
             after(grammarAccess.getClothingStoreAccess().getRightCurlyBracketKeyword_9()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClothingStore__Group__9__Impl"


    // $ANTLR start "rule__ClothingStore__Group_4__0"
    // InternalMyProject.g:2236:1: rule__ClothingStore__Group_4__0 : rule__ClothingStore__Group_4__0__Impl rule__ClothingStore__Group_4__1 ;
    public final void rule__ClothingStore__Group_4__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2240:1: ( rule__ClothingStore__Group_4__0__Impl rule__ClothingStore__Group_4__1 )
            // InternalMyProject.g:2241:2: rule__ClothingStore__Group_4__0__Impl rule__ClothingStore__Group_4__1
            {
            pushFollow(FOLLOW_9);
            rule__ClothingStore__Group_4__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ClothingStore__Group_4__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClothingStore__Group_4__0"


    // $ANTLR start "rule__ClothingStore__Group_4__0__Impl"
    // InternalMyProject.g:2248:1: rule__ClothingStore__Group_4__0__Impl : ( 'supervisorName' ) ;
    public final void rule__ClothingStore__Group_4__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2252:1: ( ( 'supervisorName' ) )
            // InternalMyProject.g:2253:1: ( 'supervisorName' )
            {
            // InternalMyProject.g:2253:1: ( 'supervisorName' )
            // InternalMyProject.g:2254:2: 'supervisorName'
            {
             before(grammarAccess.getClothingStoreAccess().getSupervisorNameKeyword_4_0()); 
            match(input,32,FOLLOW_2); 
             after(grammarAccess.getClothingStoreAccess().getSupervisorNameKeyword_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClothingStore__Group_4__0__Impl"


    // $ANTLR start "rule__ClothingStore__Group_4__1"
    // InternalMyProject.g:2263:1: rule__ClothingStore__Group_4__1 : rule__ClothingStore__Group_4__1__Impl ;
    public final void rule__ClothingStore__Group_4__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2267:1: ( rule__ClothingStore__Group_4__1__Impl )
            // InternalMyProject.g:2268:2: rule__ClothingStore__Group_4__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ClothingStore__Group_4__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClothingStore__Group_4__1"


    // $ANTLR start "rule__ClothingStore__Group_4__1__Impl"
    // InternalMyProject.g:2274:1: rule__ClothingStore__Group_4__1__Impl : ( ( rule__ClothingStore__SupervisorNameAssignment_4_1 ) ) ;
    public final void rule__ClothingStore__Group_4__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2278:1: ( ( ( rule__ClothingStore__SupervisorNameAssignment_4_1 ) ) )
            // InternalMyProject.g:2279:1: ( ( rule__ClothingStore__SupervisorNameAssignment_4_1 ) )
            {
            // InternalMyProject.g:2279:1: ( ( rule__ClothingStore__SupervisorNameAssignment_4_1 ) )
            // InternalMyProject.g:2280:2: ( rule__ClothingStore__SupervisorNameAssignment_4_1 )
            {
             before(grammarAccess.getClothingStoreAccess().getSupervisorNameAssignment_4_1()); 
            // InternalMyProject.g:2281:2: ( rule__ClothingStore__SupervisorNameAssignment_4_1 )
            // InternalMyProject.g:2281:3: rule__ClothingStore__SupervisorNameAssignment_4_1
            {
            pushFollow(FOLLOW_2);
            rule__ClothingStore__SupervisorNameAssignment_4_1();

            state._fsp--;


            }

             after(grammarAccess.getClothingStoreAccess().getSupervisorNameAssignment_4_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClothingStore__Group_4__1__Impl"


    // $ANTLR start "rule__ClothingStore__Group_5__0"
    // InternalMyProject.g:2290:1: rule__ClothingStore__Group_5__0 : rule__ClothingStore__Group_5__0__Impl rule__ClothingStore__Group_5__1 ;
    public final void rule__ClothingStore__Group_5__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2294:1: ( rule__ClothingStore__Group_5__0__Impl rule__ClothingStore__Group_5__1 )
            // InternalMyProject.g:2295:2: rule__ClothingStore__Group_5__0__Impl rule__ClothingStore__Group_5__1
            {
            pushFollow(FOLLOW_16);
            rule__ClothingStore__Group_5__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ClothingStore__Group_5__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClothingStore__Group_5__0"


    // $ANTLR start "rule__ClothingStore__Group_5__0__Impl"
    // InternalMyProject.g:2302:1: rule__ClothingStore__Group_5__0__Impl : ( 'employeeAmount' ) ;
    public final void rule__ClothingStore__Group_5__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2306:1: ( ( 'employeeAmount' ) )
            // InternalMyProject.g:2307:1: ( 'employeeAmount' )
            {
            // InternalMyProject.g:2307:1: ( 'employeeAmount' )
            // InternalMyProject.g:2308:2: 'employeeAmount'
            {
             before(grammarAccess.getClothingStoreAccess().getEmployeeAmountKeyword_5_0()); 
            match(input,33,FOLLOW_2); 
             after(grammarAccess.getClothingStoreAccess().getEmployeeAmountKeyword_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClothingStore__Group_5__0__Impl"


    // $ANTLR start "rule__ClothingStore__Group_5__1"
    // InternalMyProject.g:2317:1: rule__ClothingStore__Group_5__1 : rule__ClothingStore__Group_5__1__Impl ;
    public final void rule__ClothingStore__Group_5__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2321:1: ( rule__ClothingStore__Group_5__1__Impl )
            // InternalMyProject.g:2322:2: rule__ClothingStore__Group_5__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ClothingStore__Group_5__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClothingStore__Group_5__1"


    // $ANTLR start "rule__ClothingStore__Group_5__1__Impl"
    // InternalMyProject.g:2328:1: rule__ClothingStore__Group_5__1__Impl : ( ( rule__ClothingStore__EmployeeAmountAssignment_5_1 ) ) ;
    public final void rule__ClothingStore__Group_5__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2332:1: ( ( ( rule__ClothingStore__EmployeeAmountAssignment_5_1 ) ) )
            // InternalMyProject.g:2333:1: ( ( rule__ClothingStore__EmployeeAmountAssignment_5_1 ) )
            {
            // InternalMyProject.g:2333:1: ( ( rule__ClothingStore__EmployeeAmountAssignment_5_1 ) )
            // InternalMyProject.g:2334:2: ( rule__ClothingStore__EmployeeAmountAssignment_5_1 )
            {
             before(grammarAccess.getClothingStoreAccess().getEmployeeAmountAssignment_5_1()); 
            // InternalMyProject.g:2335:2: ( rule__ClothingStore__EmployeeAmountAssignment_5_1 )
            // InternalMyProject.g:2335:3: rule__ClothingStore__EmployeeAmountAssignment_5_1
            {
            pushFollow(FOLLOW_2);
            rule__ClothingStore__EmployeeAmountAssignment_5_1();

            state._fsp--;


            }

             after(grammarAccess.getClothingStoreAccess().getEmployeeAmountAssignment_5_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClothingStore__Group_5__1__Impl"


    // $ANTLR start "rule__ClothingStore__Group_6__0"
    // InternalMyProject.g:2344:1: rule__ClothingStore__Group_6__0 : rule__ClothingStore__Group_6__0__Impl rule__ClothingStore__Group_6__1 ;
    public final void rule__ClothingStore__Group_6__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2348:1: ( rule__ClothingStore__Group_6__0__Impl rule__ClothingStore__Group_6__1 )
            // InternalMyProject.g:2349:2: rule__ClothingStore__Group_6__0__Impl rule__ClothingStore__Group_6__1
            {
            pushFollow(FOLLOW_16);
            rule__ClothingStore__Group_6__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ClothingStore__Group_6__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClothingStore__Group_6__0"


    // $ANTLR start "rule__ClothingStore__Group_6__0__Impl"
    // InternalMyProject.g:2356:1: rule__ClothingStore__Group_6__0__Impl : ( 'managerAmount' ) ;
    public final void rule__ClothingStore__Group_6__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2360:1: ( ( 'managerAmount' ) )
            // InternalMyProject.g:2361:1: ( 'managerAmount' )
            {
            // InternalMyProject.g:2361:1: ( 'managerAmount' )
            // InternalMyProject.g:2362:2: 'managerAmount'
            {
             before(grammarAccess.getClothingStoreAccess().getManagerAmountKeyword_6_0()); 
            match(input,34,FOLLOW_2); 
             after(grammarAccess.getClothingStoreAccess().getManagerAmountKeyword_6_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClothingStore__Group_6__0__Impl"


    // $ANTLR start "rule__ClothingStore__Group_6__1"
    // InternalMyProject.g:2371:1: rule__ClothingStore__Group_6__1 : rule__ClothingStore__Group_6__1__Impl ;
    public final void rule__ClothingStore__Group_6__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2375:1: ( rule__ClothingStore__Group_6__1__Impl )
            // InternalMyProject.g:2376:2: rule__ClothingStore__Group_6__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ClothingStore__Group_6__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClothingStore__Group_6__1"


    // $ANTLR start "rule__ClothingStore__Group_6__1__Impl"
    // InternalMyProject.g:2382:1: rule__ClothingStore__Group_6__1__Impl : ( ( rule__ClothingStore__ManagerAmountAssignment_6_1 ) ) ;
    public final void rule__ClothingStore__Group_6__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2386:1: ( ( ( rule__ClothingStore__ManagerAmountAssignment_6_1 ) ) )
            // InternalMyProject.g:2387:1: ( ( rule__ClothingStore__ManagerAmountAssignment_6_1 ) )
            {
            // InternalMyProject.g:2387:1: ( ( rule__ClothingStore__ManagerAmountAssignment_6_1 ) )
            // InternalMyProject.g:2388:2: ( rule__ClothingStore__ManagerAmountAssignment_6_1 )
            {
             before(grammarAccess.getClothingStoreAccess().getManagerAmountAssignment_6_1()); 
            // InternalMyProject.g:2389:2: ( rule__ClothingStore__ManagerAmountAssignment_6_1 )
            // InternalMyProject.g:2389:3: rule__ClothingStore__ManagerAmountAssignment_6_1
            {
            pushFollow(FOLLOW_2);
            rule__ClothingStore__ManagerAmountAssignment_6_1();

            state._fsp--;


            }

             after(grammarAccess.getClothingStoreAccess().getManagerAmountAssignment_6_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClothingStore__Group_6__1__Impl"


    // $ANTLR start "rule__ClothingStore__Group_7__0"
    // InternalMyProject.g:2398:1: rule__ClothingStore__Group_7__0 : rule__ClothingStore__Group_7__0__Impl rule__ClothingStore__Group_7__1 ;
    public final void rule__ClothingStore__Group_7__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2402:1: ( rule__ClothingStore__Group_7__0__Impl rule__ClothingStore__Group_7__1 )
            // InternalMyProject.g:2403:2: rule__ClothingStore__Group_7__0__Impl rule__ClothingStore__Group_7__1
            {
            pushFollow(FOLLOW_16);
            rule__ClothingStore__Group_7__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ClothingStore__Group_7__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClothingStore__Group_7__0"


    // $ANTLR start "rule__ClothingStore__Group_7__0__Impl"
    // InternalMyProject.g:2410:1: rule__ClothingStore__Group_7__0__Impl : ( 'floorNumber' ) ;
    public final void rule__ClothingStore__Group_7__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2414:1: ( ( 'floorNumber' ) )
            // InternalMyProject.g:2415:1: ( 'floorNumber' )
            {
            // InternalMyProject.g:2415:1: ( 'floorNumber' )
            // InternalMyProject.g:2416:2: 'floorNumber'
            {
             before(grammarAccess.getClothingStoreAccess().getFloorNumberKeyword_7_0()); 
            match(input,35,FOLLOW_2); 
             after(grammarAccess.getClothingStoreAccess().getFloorNumberKeyword_7_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClothingStore__Group_7__0__Impl"


    // $ANTLR start "rule__ClothingStore__Group_7__1"
    // InternalMyProject.g:2425:1: rule__ClothingStore__Group_7__1 : rule__ClothingStore__Group_7__1__Impl ;
    public final void rule__ClothingStore__Group_7__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2429:1: ( rule__ClothingStore__Group_7__1__Impl )
            // InternalMyProject.g:2430:2: rule__ClothingStore__Group_7__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ClothingStore__Group_7__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClothingStore__Group_7__1"


    // $ANTLR start "rule__ClothingStore__Group_7__1__Impl"
    // InternalMyProject.g:2436:1: rule__ClothingStore__Group_7__1__Impl : ( ( rule__ClothingStore__FloorNumberAssignment_7_1 ) ) ;
    public final void rule__ClothingStore__Group_7__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2440:1: ( ( ( rule__ClothingStore__FloorNumberAssignment_7_1 ) ) )
            // InternalMyProject.g:2441:1: ( ( rule__ClothingStore__FloorNumberAssignment_7_1 ) )
            {
            // InternalMyProject.g:2441:1: ( ( rule__ClothingStore__FloorNumberAssignment_7_1 ) )
            // InternalMyProject.g:2442:2: ( rule__ClothingStore__FloorNumberAssignment_7_1 )
            {
             before(grammarAccess.getClothingStoreAccess().getFloorNumberAssignment_7_1()); 
            // InternalMyProject.g:2443:2: ( rule__ClothingStore__FloorNumberAssignment_7_1 )
            // InternalMyProject.g:2443:3: rule__ClothingStore__FloorNumberAssignment_7_1
            {
            pushFollow(FOLLOW_2);
            rule__ClothingStore__FloorNumberAssignment_7_1();

            state._fsp--;


            }

             after(grammarAccess.getClothingStoreAccess().getFloorNumberAssignment_7_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClothingStore__Group_7__1__Impl"


    // $ANTLR start "rule__ClothingStore__Group_8__0"
    // InternalMyProject.g:2452:1: rule__ClothingStore__Group_8__0 : rule__ClothingStore__Group_8__0__Impl rule__ClothingStore__Group_8__1 ;
    public final void rule__ClothingStore__Group_8__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2456:1: ( rule__ClothingStore__Group_8__0__Impl rule__ClothingStore__Group_8__1 )
            // InternalMyProject.g:2457:2: rule__ClothingStore__Group_8__0__Impl rule__ClothingStore__Group_8__1
            {
            pushFollow(FOLLOW_18);
            rule__ClothingStore__Group_8__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ClothingStore__Group_8__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClothingStore__Group_8__0"


    // $ANTLR start "rule__ClothingStore__Group_8__0__Impl"
    // InternalMyProject.g:2464:1: rule__ClothingStore__Group_8__0__Impl : ( 'type' ) ;
    public final void rule__ClothingStore__Group_8__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2468:1: ( ( 'type' ) )
            // InternalMyProject.g:2469:1: ( 'type' )
            {
            // InternalMyProject.g:2469:1: ( 'type' )
            // InternalMyProject.g:2470:2: 'type'
            {
             before(grammarAccess.getClothingStoreAccess().getTypeKeyword_8_0()); 
            match(input,39,FOLLOW_2); 
             after(grammarAccess.getClothingStoreAccess().getTypeKeyword_8_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClothingStore__Group_8__0__Impl"


    // $ANTLR start "rule__ClothingStore__Group_8__1"
    // InternalMyProject.g:2479:1: rule__ClothingStore__Group_8__1 : rule__ClothingStore__Group_8__1__Impl ;
    public final void rule__ClothingStore__Group_8__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2483:1: ( rule__ClothingStore__Group_8__1__Impl )
            // InternalMyProject.g:2484:2: rule__ClothingStore__Group_8__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ClothingStore__Group_8__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClothingStore__Group_8__1"


    // $ANTLR start "rule__ClothingStore__Group_8__1__Impl"
    // InternalMyProject.g:2490:1: rule__ClothingStore__Group_8__1__Impl : ( ( rule__ClothingStore__TypeAssignment_8_1 ) ) ;
    public final void rule__ClothingStore__Group_8__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2494:1: ( ( ( rule__ClothingStore__TypeAssignment_8_1 ) ) )
            // InternalMyProject.g:2495:1: ( ( rule__ClothingStore__TypeAssignment_8_1 ) )
            {
            // InternalMyProject.g:2495:1: ( ( rule__ClothingStore__TypeAssignment_8_1 ) )
            // InternalMyProject.g:2496:2: ( rule__ClothingStore__TypeAssignment_8_1 )
            {
             before(grammarAccess.getClothingStoreAccess().getTypeAssignment_8_1()); 
            // InternalMyProject.g:2497:2: ( rule__ClothingStore__TypeAssignment_8_1 )
            // InternalMyProject.g:2497:3: rule__ClothingStore__TypeAssignment_8_1
            {
            pushFollow(FOLLOW_2);
            rule__ClothingStore__TypeAssignment_8_1();

            state._fsp--;


            }

             after(grammarAccess.getClothingStoreAccess().getTypeAssignment_8_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClothingStore__Group_8__1__Impl"


    // $ANTLR start "rule__EInt__Group__0"
    // InternalMyProject.g:2506:1: rule__EInt__Group__0 : rule__EInt__Group__0__Impl rule__EInt__Group__1 ;
    public final void rule__EInt__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2510:1: ( rule__EInt__Group__0__Impl rule__EInt__Group__1 )
            // InternalMyProject.g:2511:2: rule__EInt__Group__0__Impl rule__EInt__Group__1
            {
            pushFollow(FOLLOW_16);
            rule__EInt__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__EInt__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EInt__Group__0"


    // $ANTLR start "rule__EInt__Group__0__Impl"
    // InternalMyProject.g:2518:1: rule__EInt__Group__0__Impl : ( ( '-' )? ) ;
    public final void rule__EInt__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2522:1: ( ( ( '-' )? ) )
            // InternalMyProject.g:2523:1: ( ( '-' )? )
            {
            // InternalMyProject.g:2523:1: ( ( '-' )? )
            // InternalMyProject.g:2524:2: ( '-' )?
            {
             before(grammarAccess.getEIntAccess().getHyphenMinusKeyword_0()); 
            // InternalMyProject.g:2525:2: ( '-' )?
            int alt21=2;
            int LA21_0 = input.LA(1);

            if ( (LA21_0==40) ) {
                alt21=1;
            }
            switch (alt21) {
                case 1 :
                    // InternalMyProject.g:2525:3: '-'
                    {
                    match(input,40,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getEIntAccess().getHyphenMinusKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EInt__Group__0__Impl"


    // $ANTLR start "rule__EInt__Group__1"
    // InternalMyProject.g:2533:1: rule__EInt__Group__1 : rule__EInt__Group__1__Impl ;
    public final void rule__EInt__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2537:1: ( rule__EInt__Group__1__Impl )
            // InternalMyProject.g:2538:2: rule__EInt__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__EInt__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EInt__Group__1"


    // $ANTLR start "rule__EInt__Group__1__Impl"
    // InternalMyProject.g:2544:1: rule__EInt__Group__1__Impl : ( RULE_INT ) ;
    public final void rule__EInt__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2548:1: ( ( RULE_INT ) )
            // InternalMyProject.g:2549:1: ( RULE_INT )
            {
            // InternalMyProject.g:2549:1: ( RULE_INT )
            // InternalMyProject.g:2550:2: RULE_INT
            {
             before(grammarAccess.getEIntAccess().getINTTerminalRuleCall_1()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getEIntAccess().getINTTerminalRuleCall_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EInt__Group__1__Impl"


    // $ANTLR start "rule__Section__Group__0"
    // InternalMyProject.g:2560:1: rule__Section__Group__0 : rule__Section__Group__0__Impl rule__Section__Group__1 ;
    public final void rule__Section__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2564:1: ( rule__Section__Group__0__Impl rule__Section__Group__1 )
            // InternalMyProject.g:2565:2: rule__Section__Group__0__Impl rule__Section__Group__1
            {
            pushFollow(FOLLOW_15);
            rule__Section__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Section__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Section__Group__0"


    // $ANTLR start "rule__Section__Group__0__Impl"
    // InternalMyProject.g:2572:1: rule__Section__Group__0__Impl : ( () ) ;
    public final void rule__Section__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2576:1: ( ( () ) )
            // InternalMyProject.g:2577:1: ( () )
            {
            // InternalMyProject.g:2577:1: ( () )
            // InternalMyProject.g:2578:2: ()
            {
             before(grammarAccess.getSectionAccess().getSectionAction_0()); 
            // InternalMyProject.g:2579:2: ()
            // InternalMyProject.g:2579:3: 
            {
            }

             after(grammarAccess.getSectionAccess().getSectionAction_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Section__Group__0__Impl"


    // $ANTLR start "rule__Section__Group__1"
    // InternalMyProject.g:2587:1: rule__Section__Group__1 : rule__Section__Group__1__Impl rule__Section__Group__2 ;
    public final void rule__Section__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2591:1: ( rule__Section__Group__1__Impl rule__Section__Group__2 )
            // InternalMyProject.g:2592:2: rule__Section__Group__1__Impl rule__Section__Group__2
            {
            pushFollow(FOLLOW_3);
            rule__Section__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Section__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Section__Group__1"


    // $ANTLR start "rule__Section__Group__1__Impl"
    // InternalMyProject.g:2599:1: rule__Section__Group__1__Impl : ( 'Section' ) ;
    public final void rule__Section__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2603:1: ( ( 'Section' ) )
            // InternalMyProject.g:2604:1: ( 'Section' )
            {
            // InternalMyProject.g:2604:1: ( 'Section' )
            // InternalMyProject.g:2605:2: 'Section'
            {
             before(grammarAccess.getSectionAccess().getSectionKeyword_1()); 
            match(input,41,FOLLOW_2); 
             after(grammarAccess.getSectionAccess().getSectionKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Section__Group__1__Impl"


    // $ANTLR start "rule__Section__Group__2"
    // InternalMyProject.g:2614:1: rule__Section__Group__2 : rule__Section__Group__2__Impl rule__Section__Group__3 ;
    public final void rule__Section__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2618:1: ( rule__Section__Group__2__Impl rule__Section__Group__3 )
            // InternalMyProject.g:2619:2: rule__Section__Group__2__Impl rule__Section__Group__3
            {
            pushFollow(FOLLOW_19);
            rule__Section__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Section__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Section__Group__2"


    // $ANTLR start "rule__Section__Group__2__Impl"
    // InternalMyProject.g:2626:1: rule__Section__Group__2__Impl : ( '{' ) ;
    public final void rule__Section__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2630:1: ( ( '{' ) )
            // InternalMyProject.g:2631:1: ( '{' )
            {
            // InternalMyProject.g:2631:1: ( '{' )
            // InternalMyProject.g:2632:2: '{'
            {
             before(grammarAccess.getSectionAccess().getLeftCurlyBracketKeyword_2()); 
            match(input,20,FOLLOW_2); 
             after(grammarAccess.getSectionAccess().getLeftCurlyBracketKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Section__Group__2__Impl"


    // $ANTLR start "rule__Section__Group__3"
    // InternalMyProject.g:2641:1: rule__Section__Group__3 : rule__Section__Group__3__Impl rule__Section__Group__4 ;
    public final void rule__Section__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2645:1: ( rule__Section__Group__3__Impl rule__Section__Group__4 )
            // InternalMyProject.g:2646:2: rule__Section__Group__3__Impl rule__Section__Group__4
            {
            pushFollow(FOLLOW_19);
            rule__Section__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Section__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Section__Group__3"


    // $ANTLR start "rule__Section__Group__3__Impl"
    // InternalMyProject.g:2653:1: rule__Section__Group__3__Impl : ( ( rule__Section__Group_3__0 )? ) ;
    public final void rule__Section__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2657:1: ( ( ( rule__Section__Group_3__0 )? ) )
            // InternalMyProject.g:2658:1: ( ( rule__Section__Group_3__0 )? )
            {
            // InternalMyProject.g:2658:1: ( ( rule__Section__Group_3__0 )? )
            // InternalMyProject.g:2659:2: ( rule__Section__Group_3__0 )?
            {
             before(grammarAccess.getSectionAccess().getGroup_3()); 
            // InternalMyProject.g:2660:2: ( rule__Section__Group_3__0 )?
            int alt22=2;
            int LA22_0 = input.LA(1);

            if ( (LA22_0==31) ) {
                alt22=1;
            }
            switch (alt22) {
                case 1 :
                    // InternalMyProject.g:2660:3: rule__Section__Group_3__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Section__Group_3__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getSectionAccess().getGroup_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Section__Group__3__Impl"


    // $ANTLR start "rule__Section__Group__4"
    // InternalMyProject.g:2668:1: rule__Section__Group__4 : rule__Section__Group__4__Impl ;
    public final void rule__Section__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2672:1: ( rule__Section__Group__4__Impl )
            // InternalMyProject.g:2673:2: rule__Section__Group__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Section__Group__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Section__Group__4"


    // $ANTLR start "rule__Section__Group__4__Impl"
    // InternalMyProject.g:2679:1: rule__Section__Group__4__Impl : ( '}' ) ;
    public final void rule__Section__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2683:1: ( ( '}' ) )
            // InternalMyProject.g:2684:1: ( '}' )
            {
            // InternalMyProject.g:2684:1: ( '}' )
            // InternalMyProject.g:2685:2: '}'
            {
             before(grammarAccess.getSectionAccess().getRightCurlyBracketKeyword_4()); 
            match(input,22,FOLLOW_2); 
             after(grammarAccess.getSectionAccess().getRightCurlyBracketKeyword_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Section__Group__4__Impl"


    // $ANTLR start "rule__Section__Group_3__0"
    // InternalMyProject.g:2695:1: rule__Section__Group_3__0 : rule__Section__Group_3__0__Impl rule__Section__Group_3__1 ;
    public final void rule__Section__Group_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2699:1: ( rule__Section__Group_3__0__Impl rule__Section__Group_3__1 )
            // InternalMyProject.g:2700:2: rule__Section__Group_3__0__Impl rule__Section__Group_3__1
            {
            pushFollow(FOLLOW_20);
            rule__Section__Group_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Section__Group_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Section__Group_3__0"


    // $ANTLR start "rule__Section__Group_3__0__Impl"
    // InternalMyProject.g:2707:1: rule__Section__Group_3__0__Impl : ( 'sections' ) ;
    public final void rule__Section__Group_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2711:1: ( ( 'sections' ) )
            // InternalMyProject.g:2712:1: ( 'sections' )
            {
            // InternalMyProject.g:2712:1: ( 'sections' )
            // InternalMyProject.g:2713:2: 'sections'
            {
             before(grammarAccess.getSectionAccess().getSectionsKeyword_3_0()); 
            match(input,31,FOLLOW_2); 
             after(grammarAccess.getSectionAccess().getSectionsKeyword_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Section__Group_3__0__Impl"


    // $ANTLR start "rule__Section__Group_3__1"
    // InternalMyProject.g:2722:1: rule__Section__Group_3__1 : rule__Section__Group_3__1__Impl ;
    public final void rule__Section__Group_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2726:1: ( rule__Section__Group_3__1__Impl )
            // InternalMyProject.g:2727:2: rule__Section__Group_3__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Section__Group_3__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Section__Group_3__1"


    // $ANTLR start "rule__Section__Group_3__1__Impl"
    // InternalMyProject.g:2733:1: rule__Section__Group_3__1__Impl : ( ( rule__Section__SectionsAssignment_3_1 ) ) ;
    public final void rule__Section__Group_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2737:1: ( ( ( rule__Section__SectionsAssignment_3_1 ) ) )
            // InternalMyProject.g:2738:1: ( ( rule__Section__SectionsAssignment_3_1 ) )
            {
            // InternalMyProject.g:2738:1: ( ( rule__Section__SectionsAssignment_3_1 ) )
            // InternalMyProject.g:2739:2: ( rule__Section__SectionsAssignment_3_1 )
            {
             before(grammarAccess.getSectionAccess().getSectionsAssignment_3_1()); 
            // InternalMyProject.g:2740:2: ( rule__Section__SectionsAssignment_3_1 )
            // InternalMyProject.g:2740:3: rule__Section__SectionsAssignment_3_1
            {
            pushFollow(FOLLOW_2);
            rule__Section__SectionsAssignment_3_1();

            state._fsp--;


            }

             after(grammarAccess.getSectionAccess().getSectionsAssignment_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Section__Group_3__1__Impl"


    // $ANTLR start "rule__ShoppingMall__CompanyNameAssignment_2_1"
    // InternalMyProject.g:2749:1: rule__ShoppingMall__CompanyNameAssignment_2_1 : ( ruleEString ) ;
    public final void rule__ShoppingMall__CompanyNameAssignment_2_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2753:1: ( ( ruleEString ) )
            // InternalMyProject.g:2754:2: ( ruleEString )
            {
            // InternalMyProject.g:2754:2: ( ruleEString )
            // InternalMyProject.g:2755:3: ruleEString
            {
             before(grammarAccess.getShoppingMallAccess().getCompanyNameEStringParserRuleCall_2_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getShoppingMallAccess().getCompanyNameEStringParserRuleCall_2_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShoppingMall__CompanyNameAssignment_2_1"


    // $ANTLR start "rule__ShoppingMall__CeoAssignment_3_1"
    // InternalMyProject.g:2764:1: rule__ShoppingMall__CeoAssignment_3_1 : ( ruleEString ) ;
    public final void rule__ShoppingMall__CeoAssignment_3_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2768:1: ( ( ruleEString ) )
            // InternalMyProject.g:2769:2: ( ruleEString )
            {
            // InternalMyProject.g:2769:2: ( ruleEString )
            // InternalMyProject.g:2770:3: ruleEString
            {
             before(grammarAccess.getShoppingMallAccess().getCeoEStringParserRuleCall_3_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getShoppingMallAccess().getCeoEStringParserRuleCall_3_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShoppingMall__CeoAssignment_3_1"


    // $ANTLR start "rule__ShoppingMall__LocationAssignment_4_1"
    // InternalMyProject.g:2779:1: rule__ShoppingMall__LocationAssignment_4_1 : ( ruleEString ) ;
    public final void rule__ShoppingMall__LocationAssignment_4_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2783:1: ( ( ruleEString ) )
            // InternalMyProject.g:2784:2: ( ruleEString )
            {
            // InternalMyProject.g:2784:2: ( ruleEString )
            // InternalMyProject.g:2785:3: ruleEString
            {
             before(grammarAccess.getShoppingMallAccess().getLocationEStringParserRuleCall_4_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getShoppingMallAccess().getLocationEStringParserRuleCall_4_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShoppingMall__LocationAssignment_4_1"


    // $ANTLR start "rule__ShoppingMall__ShopsAssignment_7"
    // InternalMyProject.g:2794:1: rule__ShoppingMall__ShopsAssignment_7 : ( ruleShop ) ;
    public final void rule__ShoppingMall__ShopsAssignment_7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2798:1: ( ( ruleShop ) )
            // InternalMyProject.g:2799:2: ( ruleShop )
            {
            // InternalMyProject.g:2799:2: ( ruleShop )
            // InternalMyProject.g:2800:3: ruleShop
            {
             before(grammarAccess.getShoppingMallAccess().getShopsShopParserRuleCall_7_0()); 
            pushFollow(FOLLOW_2);
            ruleShop();

            state._fsp--;

             after(grammarAccess.getShoppingMallAccess().getShopsShopParserRuleCall_7_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShoppingMall__ShopsAssignment_7"


    // $ANTLR start "rule__ShoppingMall__ShopsAssignment_8_1"
    // InternalMyProject.g:2809:1: rule__ShoppingMall__ShopsAssignment_8_1 : ( ruleShop ) ;
    public final void rule__ShoppingMall__ShopsAssignment_8_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2813:1: ( ( ruleShop ) )
            // InternalMyProject.g:2814:2: ( ruleShop )
            {
            // InternalMyProject.g:2814:2: ( ruleShop )
            // InternalMyProject.g:2815:3: ruleShop
            {
             before(grammarAccess.getShoppingMallAccess().getShopsShopParserRuleCall_8_1_0()); 
            pushFollow(FOLLOW_2);
            ruleShop();

            state._fsp--;

             after(grammarAccess.getShoppingMallAccess().getShopsShopParserRuleCall_8_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShoppingMall__ShopsAssignment_8_1"


    // $ANTLR start "rule__Shop__SupermarketAssignment_3"
    // InternalMyProject.g:2824:1: rule__Shop__SupermarketAssignment_3 : ( ruleSupermarket ) ;
    public final void rule__Shop__SupermarketAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2828:1: ( ( ruleSupermarket ) )
            // InternalMyProject.g:2829:2: ( ruleSupermarket )
            {
            // InternalMyProject.g:2829:2: ( ruleSupermarket )
            // InternalMyProject.g:2830:3: ruleSupermarket
            {
             before(grammarAccess.getShopAccess().getSupermarketSupermarketParserRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            ruleSupermarket();

            state._fsp--;

             after(grammarAccess.getShopAccess().getSupermarketSupermarketParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Shop__SupermarketAssignment_3"


    // $ANTLR start "rule__Shop__ClothingStoresAssignment_6"
    // InternalMyProject.g:2839:1: rule__Shop__ClothingStoresAssignment_6 : ( ruleClothingStore ) ;
    public final void rule__Shop__ClothingStoresAssignment_6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2843:1: ( ( ruleClothingStore ) )
            // InternalMyProject.g:2844:2: ( ruleClothingStore )
            {
            // InternalMyProject.g:2844:2: ( ruleClothingStore )
            // InternalMyProject.g:2845:3: ruleClothingStore
            {
             before(grammarAccess.getShopAccess().getClothingStoresClothingStoreParserRuleCall_6_0()); 
            pushFollow(FOLLOW_2);
            ruleClothingStore();

            state._fsp--;

             after(grammarAccess.getShopAccess().getClothingStoresClothingStoreParserRuleCall_6_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Shop__ClothingStoresAssignment_6"


    // $ANTLR start "rule__Shop__ClothingStoresAssignment_7_1"
    // InternalMyProject.g:2854:1: rule__Shop__ClothingStoresAssignment_7_1 : ( ruleClothingStore ) ;
    public final void rule__Shop__ClothingStoresAssignment_7_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2858:1: ( ( ruleClothingStore ) )
            // InternalMyProject.g:2859:2: ( ruleClothingStore )
            {
            // InternalMyProject.g:2859:2: ( ruleClothingStore )
            // InternalMyProject.g:2860:3: ruleClothingStore
            {
             before(grammarAccess.getShopAccess().getClothingStoresClothingStoreParserRuleCall_7_1_0()); 
            pushFollow(FOLLOW_2);
            ruleClothingStore();

            state._fsp--;

             after(grammarAccess.getShopAccess().getClothingStoresClothingStoreParserRuleCall_7_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Shop__ClothingStoresAssignment_7_1"


    // $ANTLR start "rule__Supermarket__NameAssignment_1"
    // InternalMyProject.g:2869:1: rule__Supermarket__NameAssignment_1 : ( ruleEString ) ;
    public final void rule__Supermarket__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2873:1: ( ( ruleEString ) )
            // InternalMyProject.g:2874:2: ( ruleEString )
            {
            // InternalMyProject.g:2874:2: ( ruleEString )
            // InternalMyProject.g:2875:3: ruleEString
            {
             before(grammarAccess.getSupermarketAccess().getNameEStringParserRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getSupermarketAccess().getNameEStringParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__NameAssignment_1"


    // $ANTLR start "rule__Supermarket__SupervisorNameAssignment_3_1"
    // InternalMyProject.g:2884:1: rule__Supermarket__SupervisorNameAssignment_3_1 : ( ruleEString ) ;
    public final void rule__Supermarket__SupervisorNameAssignment_3_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2888:1: ( ( ruleEString ) )
            // InternalMyProject.g:2889:2: ( ruleEString )
            {
            // InternalMyProject.g:2889:2: ( ruleEString )
            // InternalMyProject.g:2890:3: ruleEString
            {
             before(grammarAccess.getSupermarketAccess().getSupervisorNameEStringParserRuleCall_3_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getSupermarketAccess().getSupervisorNameEStringParserRuleCall_3_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__SupervisorNameAssignment_3_1"


    // $ANTLR start "rule__Supermarket__EmployeeAmountAssignment_4_1"
    // InternalMyProject.g:2899:1: rule__Supermarket__EmployeeAmountAssignment_4_1 : ( ruleEInt ) ;
    public final void rule__Supermarket__EmployeeAmountAssignment_4_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2903:1: ( ( ruleEInt ) )
            // InternalMyProject.g:2904:2: ( ruleEInt )
            {
            // InternalMyProject.g:2904:2: ( ruleEInt )
            // InternalMyProject.g:2905:3: ruleEInt
            {
             before(grammarAccess.getSupermarketAccess().getEmployeeAmountEIntParserRuleCall_4_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEInt();

            state._fsp--;

             after(grammarAccess.getSupermarketAccess().getEmployeeAmountEIntParserRuleCall_4_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__EmployeeAmountAssignment_4_1"


    // $ANTLR start "rule__Supermarket__ManagerAmountAssignment_5_1"
    // InternalMyProject.g:2914:1: rule__Supermarket__ManagerAmountAssignment_5_1 : ( ruleEInt ) ;
    public final void rule__Supermarket__ManagerAmountAssignment_5_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2918:1: ( ( ruleEInt ) )
            // InternalMyProject.g:2919:2: ( ruleEInt )
            {
            // InternalMyProject.g:2919:2: ( ruleEInt )
            // InternalMyProject.g:2920:3: ruleEInt
            {
             before(grammarAccess.getSupermarketAccess().getManagerAmountEIntParserRuleCall_5_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEInt();

            state._fsp--;

             after(grammarAccess.getSupermarketAccess().getManagerAmountEIntParserRuleCall_5_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__ManagerAmountAssignment_5_1"


    // $ANTLR start "rule__Supermarket__FloorNumberAssignment_6_1"
    // InternalMyProject.g:2929:1: rule__Supermarket__FloorNumberAssignment_6_1 : ( ruleEInt ) ;
    public final void rule__Supermarket__FloorNumberAssignment_6_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2933:1: ( ( ruleEInt ) )
            // InternalMyProject.g:2934:2: ( ruleEInt )
            {
            // InternalMyProject.g:2934:2: ( ruleEInt )
            // InternalMyProject.g:2935:3: ruleEInt
            {
             before(grammarAccess.getSupermarketAccess().getFloorNumberEIntParserRuleCall_6_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEInt();

            state._fsp--;

             after(grammarAccess.getSupermarketAccess().getFloorNumberEIntParserRuleCall_6_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__FloorNumberAssignment_6_1"


    // $ANTLR start "rule__Supermarket__OpeningTimeAssignment_7_1"
    // InternalMyProject.g:2944:1: rule__Supermarket__OpeningTimeAssignment_7_1 : ( ruleEString ) ;
    public final void rule__Supermarket__OpeningTimeAssignment_7_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2948:1: ( ( ruleEString ) )
            // InternalMyProject.g:2949:2: ( ruleEString )
            {
            // InternalMyProject.g:2949:2: ( ruleEString )
            // InternalMyProject.g:2950:3: ruleEString
            {
             before(grammarAccess.getSupermarketAccess().getOpeningTimeEStringParserRuleCall_7_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getSupermarketAccess().getOpeningTimeEStringParserRuleCall_7_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__OpeningTimeAssignment_7_1"


    // $ANTLR start "rule__Supermarket__ClosingTimeAssignment_8_1"
    // InternalMyProject.g:2959:1: rule__Supermarket__ClosingTimeAssignment_8_1 : ( ruleEString ) ;
    public final void rule__Supermarket__ClosingTimeAssignment_8_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2963:1: ( ( ruleEString ) )
            // InternalMyProject.g:2964:2: ( ruleEString )
            {
            // InternalMyProject.g:2964:2: ( ruleEString )
            // InternalMyProject.g:2965:3: ruleEString
            {
             before(grammarAccess.getSupermarketAccess().getClosingTimeEStringParserRuleCall_8_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getSupermarketAccess().getClosingTimeEStringParserRuleCall_8_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__ClosingTimeAssignment_8_1"


    // $ANTLR start "rule__Supermarket__SectionsAssignment_11"
    // InternalMyProject.g:2974:1: rule__Supermarket__SectionsAssignment_11 : ( ruleSection ) ;
    public final void rule__Supermarket__SectionsAssignment_11() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2978:1: ( ( ruleSection ) )
            // InternalMyProject.g:2979:2: ( ruleSection )
            {
            // InternalMyProject.g:2979:2: ( ruleSection )
            // InternalMyProject.g:2980:3: ruleSection
            {
             before(grammarAccess.getSupermarketAccess().getSectionsSectionParserRuleCall_11_0()); 
            pushFollow(FOLLOW_2);
            ruleSection();

            state._fsp--;

             after(grammarAccess.getSupermarketAccess().getSectionsSectionParserRuleCall_11_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__SectionsAssignment_11"


    // $ANTLR start "rule__Supermarket__SectionsAssignment_12_1"
    // InternalMyProject.g:2989:1: rule__Supermarket__SectionsAssignment_12_1 : ( ruleSection ) ;
    public final void rule__Supermarket__SectionsAssignment_12_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:2993:1: ( ( ruleSection ) )
            // InternalMyProject.g:2994:2: ( ruleSection )
            {
            // InternalMyProject.g:2994:2: ( ruleSection )
            // InternalMyProject.g:2995:3: ruleSection
            {
             before(grammarAccess.getSupermarketAccess().getSectionsSectionParserRuleCall_12_1_0()); 
            pushFollow(FOLLOW_2);
            ruleSection();

            state._fsp--;

             after(grammarAccess.getSupermarketAccess().getSectionsSectionParserRuleCall_12_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Supermarket__SectionsAssignment_12_1"


    // $ANTLR start "rule__ClothingStore__NameAssignment_2"
    // InternalMyProject.g:3004:1: rule__ClothingStore__NameAssignment_2 : ( ruleEString ) ;
    public final void rule__ClothingStore__NameAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:3008:1: ( ( ruleEString ) )
            // InternalMyProject.g:3009:2: ( ruleEString )
            {
            // InternalMyProject.g:3009:2: ( ruleEString )
            // InternalMyProject.g:3010:3: ruleEString
            {
             before(grammarAccess.getClothingStoreAccess().getNameEStringParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getClothingStoreAccess().getNameEStringParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClothingStore__NameAssignment_2"


    // $ANTLR start "rule__ClothingStore__SupervisorNameAssignment_4_1"
    // InternalMyProject.g:3019:1: rule__ClothingStore__SupervisorNameAssignment_4_1 : ( ruleEString ) ;
    public final void rule__ClothingStore__SupervisorNameAssignment_4_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:3023:1: ( ( ruleEString ) )
            // InternalMyProject.g:3024:2: ( ruleEString )
            {
            // InternalMyProject.g:3024:2: ( ruleEString )
            // InternalMyProject.g:3025:3: ruleEString
            {
             before(grammarAccess.getClothingStoreAccess().getSupervisorNameEStringParserRuleCall_4_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getClothingStoreAccess().getSupervisorNameEStringParserRuleCall_4_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClothingStore__SupervisorNameAssignment_4_1"


    // $ANTLR start "rule__ClothingStore__EmployeeAmountAssignment_5_1"
    // InternalMyProject.g:3034:1: rule__ClothingStore__EmployeeAmountAssignment_5_1 : ( ruleEInt ) ;
    public final void rule__ClothingStore__EmployeeAmountAssignment_5_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:3038:1: ( ( ruleEInt ) )
            // InternalMyProject.g:3039:2: ( ruleEInt )
            {
            // InternalMyProject.g:3039:2: ( ruleEInt )
            // InternalMyProject.g:3040:3: ruleEInt
            {
             before(grammarAccess.getClothingStoreAccess().getEmployeeAmountEIntParserRuleCall_5_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEInt();

            state._fsp--;

             after(grammarAccess.getClothingStoreAccess().getEmployeeAmountEIntParserRuleCall_5_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClothingStore__EmployeeAmountAssignment_5_1"


    // $ANTLR start "rule__ClothingStore__ManagerAmountAssignment_6_1"
    // InternalMyProject.g:3049:1: rule__ClothingStore__ManagerAmountAssignment_6_1 : ( ruleEInt ) ;
    public final void rule__ClothingStore__ManagerAmountAssignment_6_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:3053:1: ( ( ruleEInt ) )
            // InternalMyProject.g:3054:2: ( ruleEInt )
            {
            // InternalMyProject.g:3054:2: ( ruleEInt )
            // InternalMyProject.g:3055:3: ruleEInt
            {
             before(grammarAccess.getClothingStoreAccess().getManagerAmountEIntParserRuleCall_6_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEInt();

            state._fsp--;

             after(grammarAccess.getClothingStoreAccess().getManagerAmountEIntParserRuleCall_6_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClothingStore__ManagerAmountAssignment_6_1"


    // $ANTLR start "rule__ClothingStore__FloorNumberAssignment_7_1"
    // InternalMyProject.g:3064:1: rule__ClothingStore__FloorNumberAssignment_7_1 : ( ruleEInt ) ;
    public final void rule__ClothingStore__FloorNumberAssignment_7_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:3068:1: ( ( ruleEInt ) )
            // InternalMyProject.g:3069:2: ( ruleEInt )
            {
            // InternalMyProject.g:3069:2: ( ruleEInt )
            // InternalMyProject.g:3070:3: ruleEInt
            {
             before(grammarAccess.getClothingStoreAccess().getFloorNumberEIntParserRuleCall_7_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEInt();

            state._fsp--;

             after(grammarAccess.getClothingStoreAccess().getFloorNumberEIntParserRuleCall_7_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClothingStore__FloorNumberAssignment_7_1"


    // $ANTLR start "rule__ClothingStore__TypeAssignment_8_1"
    // InternalMyProject.g:3079:1: rule__ClothingStore__TypeAssignment_8_1 : ( ruleclothingType ) ;
    public final void rule__ClothingStore__TypeAssignment_8_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:3083:1: ( ( ruleclothingType ) )
            // InternalMyProject.g:3084:2: ( ruleclothingType )
            {
            // InternalMyProject.g:3084:2: ( ruleclothingType )
            // InternalMyProject.g:3085:3: ruleclothingType
            {
             before(grammarAccess.getClothingStoreAccess().getTypeClothingTypeEnumRuleCall_8_1_0()); 
            pushFollow(FOLLOW_2);
            ruleclothingType();

            state._fsp--;

             after(grammarAccess.getClothingStoreAccess().getTypeClothingTypeEnumRuleCall_8_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClothingStore__TypeAssignment_8_1"


    // $ANTLR start "rule__Section__SectionsAssignment_3_1"
    // InternalMyProject.g:3094:1: rule__Section__SectionsAssignment_3_1 : ( rulesectionType ) ;
    public final void rule__Section__SectionsAssignment_3_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyProject.g:3098:1: ( ( rulesectionType ) )
            // InternalMyProject.g:3099:2: ( rulesectionType )
            {
            // InternalMyProject.g:3099:2: ( rulesectionType )
            // InternalMyProject.g:3100:3: rulesectionType
            {
             before(grammarAccess.getSectionAccess().getSectionsSectionTypeEnumRuleCall_3_1_0()); 
            pushFollow(FOLLOW_2);
            rulesectionType();

            state._fsp--;

             after(grammarAccess.getSectionAccess().getSectionsSectionTypeEnumRuleCall_3_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Section__SectionsAssignment_3_1"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000003A00000L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000008000000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000004400000L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000004000002L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000400000L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000000030L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000010000000L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000040000000L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000020000000L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000004000000000L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000003F80000000L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000020000000000L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000010000000040L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000008F00400000L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000000000078000L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x0000000080400000L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0000000000007800L});

}