/**
 */
package mdea4;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Department</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link mdea4.Department#getCinema <em>Cinema</em>}</li>
 *   <li>{@link mdea4.Department#getClothingstore <em>Clothingstore</em>}</li>
 *   <li>{@link mdea4.Department#getFoodcourt <em>Foodcourt</em>}</li>
 * </ul>
 *
 * @see mdea4.Mdea4Package#getDepartment()
 * @model
 * @generated
 */
public interface Department extends EObject {
	/**
	 * Returns the value of the '<em><b>Cinema</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Cinema</em>' containment reference.
	 * @see #setCinema(Cinema)
	 * @see mdea4.Mdea4Package#getDepartment_Cinema()
	 * @model containment="true" required="true"
	 * @generated
	 */
	Cinema getCinema();

	/**
	 * Sets the value of the '{@link mdea4.Department#getCinema <em>Cinema</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Cinema</em>' containment reference.
	 * @see #getCinema()
	 * @generated
	 */
	void setCinema(Cinema value);

	/**
	 * Returns the value of the '<em><b>Clothingstore</b></em>' containment reference list.
	 * The list contents are of type {@link mdea4.ClothingStore}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Clothingstore</em>' containment reference list.
	 * @see mdea4.Mdea4Package#getDepartment_Clothingstore()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<ClothingStore> getClothingstore();

	/**
	 * Returns the value of the '<em><b>Foodcourt</b></em>' containment reference list.
	 * The list contents are of type {@link mdea4.Foodcourt}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Foodcourt</em>' containment reference list.
	 * @see mdea4.Mdea4Package#getDepartment_Foodcourt()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Foodcourt> getFoodcourt();

} // Department
