/**
 */
package mdea4;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Restaurant</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link mdea4.Restaurant#getType <em>Type</em>}</li>
 * </ul>
 *
 * @see mdea4.Mdea4Package#getRestaurant()
 * @model
 * @generated
 */
public interface Restaurant extends EObject {
	/**
	 * Returns the value of the '<em><b>Type</b></em>' attribute.
	 * The literals are from the enumeration {@link mdea4.foodType}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' attribute.
	 * @see mdea4.foodType
	 * @see #setType(foodType)
	 * @see mdea4.Mdea4Package#getRestaurant_Type()
	 * @model
	 * @generated
	 */
	foodType getType();

	/**
	 * Sets the value of the '{@link mdea4.Restaurant#getType <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' attribute.
	 * @see mdea4.foodType
	 * @see #getType()
	 * @generated
	 */
	void setType(foodType value);

} // Restaurant
