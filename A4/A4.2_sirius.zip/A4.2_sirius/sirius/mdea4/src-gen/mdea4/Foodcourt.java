/**
 */
package mdea4;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Foodcourt</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link mdea4.Foodcourt#getFloor <em>Floor</em>}</li>
 *   <li>{@link mdea4.Foodcourt#getRestaurants <em>Restaurants</em>}</li>
 * </ul>
 *
 * @see mdea4.Mdea4Package#getFoodcourt()
 * @model
 * @generated
 */
public interface Foodcourt extends AbstractDepartment {
	/**
	 * Returns the value of the '<em><b>Floor</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Floor</em>' attribute.
	 * @see #setFloor(int)
	 * @see mdea4.Mdea4Package#getFoodcourt_Floor()
	 * @model
	 * @generated
	 */
	int getFloor();

	/**
	 * Sets the value of the '{@link mdea4.Foodcourt#getFloor <em>Floor</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Floor</em>' attribute.
	 * @see #getFloor()
	 * @generated
	 */
	void setFloor(int value);

	/**
	 * Returns the value of the '<em><b>Restaurants</b></em>' containment reference list.
	 * The list contents are of type {@link mdea4.Restaurant}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Restaurants</em>' containment reference list.
	 * @see mdea4.Mdea4Package#getFoodcourt_Restaurants()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Restaurant> getRestaurants();

} // Foodcourt
