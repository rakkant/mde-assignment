/**
 */
package mdea4.impl;

import mdea4.Cinema;
import mdea4.Mdea4Package;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Cinema</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link mdea4.impl.CinemaImpl#getFloor <em>Floor</em>}</li>
 *   <li>{@link mdea4.impl.CinemaImpl#getTheaterAMount <em>Theater AMount</em>}</li>
 * </ul>
 *
 * @generated
 */
public class CinemaImpl extends AbstractDepartmentImpl implements Cinema {
	/**
	 * The default value of the '{@link #getFloor() <em>Floor</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFloor()
	 * @generated
	 * @ordered
	 */
	protected static final int FLOOR_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getFloor() <em>Floor</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFloor()
	 * @generated
	 * @ordered
	 */
	protected int floor = FLOOR_EDEFAULT;

	/**
	 * The default value of the '{@link #getTheaterAMount() <em>Theater AMount</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTheaterAMount()
	 * @generated
	 * @ordered
	 */
	protected static final int THEATER_AMOUNT_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getTheaterAMount() <em>Theater AMount</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTheaterAMount()
	 * @generated
	 * @ordered
	 */
	protected int theaterAMount = THEATER_AMOUNT_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected CinemaImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Mdea4Package.Literals.CINEMA;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getFloor() {
		return floor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setFloor(int newFloor) {
		int oldFloor = floor;
		floor = newFloor;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Mdea4Package.CINEMA__FLOOR, oldFloor, floor));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getTheaterAMount() {
		return theaterAMount;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTheaterAMount(int newTheaterAMount) {
		int oldTheaterAMount = theaterAMount;
		theaterAMount = newTheaterAMount;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Mdea4Package.CINEMA__THEATER_AMOUNT, oldTheaterAMount,
					theaterAMount));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Mdea4Package.CINEMA__FLOOR:
			return getFloor();
		case Mdea4Package.CINEMA__THEATER_AMOUNT:
			return getTheaterAMount();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Mdea4Package.CINEMA__FLOOR:
			setFloor((Integer) newValue);
			return;
		case Mdea4Package.CINEMA__THEATER_AMOUNT:
			setTheaterAMount((Integer) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Mdea4Package.CINEMA__FLOOR:
			setFloor(FLOOR_EDEFAULT);
			return;
		case Mdea4Package.CINEMA__THEATER_AMOUNT:
			setTheaterAMount(THEATER_AMOUNT_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Mdea4Package.CINEMA__FLOOR:
			return floor != FLOOR_EDEFAULT;
		case Mdea4Package.CINEMA__THEATER_AMOUNT:
			return theaterAMount != THEATER_AMOUNT_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (floor: ");
		result.append(floor);
		result.append(", theaterAMount: ");
		result.append(theaterAMount);
		result.append(')');
		return result.toString();
	}

} //CinemaImpl
