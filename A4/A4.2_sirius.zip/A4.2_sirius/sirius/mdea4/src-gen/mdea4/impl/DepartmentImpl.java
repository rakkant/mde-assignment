/**
 */
package mdea4.impl;

import java.util.Collection;

import mdea4.Cinema;
import mdea4.ClothingStore;
import mdea4.Department;
import mdea4.Foodcourt;
import mdea4.Mdea4Package;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Department</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link mdea4.impl.DepartmentImpl#getCinema <em>Cinema</em>}</li>
 *   <li>{@link mdea4.impl.DepartmentImpl#getClothingstore <em>Clothingstore</em>}</li>
 *   <li>{@link mdea4.impl.DepartmentImpl#getFoodcourt <em>Foodcourt</em>}</li>
 * </ul>
 *
 * @generated
 */
public class DepartmentImpl extends MinimalEObjectImpl.Container implements Department {
	/**
	 * The cached value of the '{@link #getCinema() <em>Cinema</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCinema()
	 * @generated
	 * @ordered
	 */
	protected Cinema cinema;

	/**
	 * The cached value of the '{@link #getClothingstore() <em>Clothingstore</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getClothingstore()
	 * @generated
	 * @ordered
	 */
	protected EList<ClothingStore> clothingstore;

	/**
	 * The cached value of the '{@link #getFoodcourt() <em>Foodcourt</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFoodcourt()
	 * @generated
	 * @ordered
	 */
	protected EList<Foodcourt> foodcourt;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DepartmentImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Mdea4Package.Literals.DEPARTMENT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Cinema getCinema() {
		return cinema;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetCinema(Cinema newCinema, NotificationChain msgs) {
		Cinema oldCinema = cinema;
		cinema = newCinema;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					Mdea4Package.DEPARTMENT__CINEMA, oldCinema, newCinema);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCinema(Cinema newCinema) {
		if (newCinema != cinema) {
			NotificationChain msgs = null;
			if (cinema != null)
				msgs = ((InternalEObject) cinema).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - Mdea4Package.DEPARTMENT__CINEMA, null, msgs);
			if (newCinema != null)
				msgs = ((InternalEObject) newCinema).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - Mdea4Package.DEPARTMENT__CINEMA, null, msgs);
			msgs = basicSetCinema(newCinema, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Mdea4Package.DEPARTMENT__CINEMA, newCinema,
					newCinema));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<ClothingStore> getClothingstore() {
		if (clothingstore == null) {
			clothingstore = new EObjectContainmentEList<ClothingStore>(ClothingStore.class, this,
					Mdea4Package.DEPARTMENT__CLOTHINGSTORE);
		}
		return clothingstore;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Foodcourt> getFoodcourt() {
		if (foodcourt == null) {
			foodcourt = new EObjectContainmentEList<Foodcourt>(Foodcourt.class, this,
					Mdea4Package.DEPARTMENT__FOODCOURT);
		}
		return foodcourt;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Mdea4Package.DEPARTMENT__CINEMA:
			return basicSetCinema(null, msgs);
		case Mdea4Package.DEPARTMENT__CLOTHINGSTORE:
			return ((InternalEList<?>) getClothingstore()).basicRemove(otherEnd, msgs);
		case Mdea4Package.DEPARTMENT__FOODCOURT:
			return ((InternalEList<?>) getFoodcourt()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Mdea4Package.DEPARTMENT__CINEMA:
			return getCinema();
		case Mdea4Package.DEPARTMENT__CLOTHINGSTORE:
			return getClothingstore();
		case Mdea4Package.DEPARTMENT__FOODCOURT:
			return getFoodcourt();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Mdea4Package.DEPARTMENT__CINEMA:
			setCinema((Cinema) newValue);
			return;
		case Mdea4Package.DEPARTMENT__CLOTHINGSTORE:
			getClothingstore().clear();
			getClothingstore().addAll((Collection<? extends ClothingStore>) newValue);
			return;
		case Mdea4Package.DEPARTMENT__FOODCOURT:
			getFoodcourt().clear();
			getFoodcourt().addAll((Collection<? extends Foodcourt>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Mdea4Package.DEPARTMENT__CINEMA:
			setCinema((Cinema) null);
			return;
		case Mdea4Package.DEPARTMENT__CLOTHINGSTORE:
			getClothingstore().clear();
			return;
		case Mdea4Package.DEPARTMENT__FOODCOURT:
			getFoodcourt().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Mdea4Package.DEPARTMENT__CINEMA:
			return cinema != null;
		case Mdea4Package.DEPARTMENT__CLOTHINGSTORE:
			return clothingstore != null && !clothingstore.isEmpty();
		case Mdea4Package.DEPARTMENT__FOODCOURT:
			return foodcourt != null && !foodcourt.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //DepartmentImpl
