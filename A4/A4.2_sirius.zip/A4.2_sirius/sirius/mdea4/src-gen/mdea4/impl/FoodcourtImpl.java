/**
 */
package mdea4.impl;

import java.util.Collection;

import mdea4.Foodcourt;
import mdea4.Mdea4Package;
import mdea4.Restaurant;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Foodcourt</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link mdea4.impl.FoodcourtImpl#getFloor <em>Floor</em>}</li>
 *   <li>{@link mdea4.impl.FoodcourtImpl#getRestaurants <em>Restaurants</em>}</li>
 * </ul>
 *
 * @generated
 */
public class FoodcourtImpl extends AbstractDepartmentImpl implements Foodcourt {
	/**
	 * The default value of the '{@link #getFloor() <em>Floor</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFloor()
	 * @generated
	 * @ordered
	 */
	protected static final int FLOOR_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getFloor() <em>Floor</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFloor()
	 * @generated
	 * @ordered
	 */
	protected int floor = FLOOR_EDEFAULT;

	/**
	 * The cached value of the '{@link #getRestaurants() <em>Restaurants</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRestaurants()
	 * @generated
	 * @ordered
	 */
	protected EList<Restaurant> restaurants;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected FoodcourtImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Mdea4Package.Literals.FOODCOURT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getFloor() {
		return floor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setFloor(int newFloor) {
		int oldFloor = floor;
		floor = newFloor;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Mdea4Package.FOODCOURT__FLOOR, oldFloor, floor));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Restaurant> getRestaurants() {
		if (restaurants == null) {
			restaurants = new EObjectContainmentEList<Restaurant>(Restaurant.class, this,
					Mdea4Package.FOODCOURT__RESTAURANTS);
		}
		return restaurants;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Mdea4Package.FOODCOURT__RESTAURANTS:
			return ((InternalEList<?>) getRestaurants()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Mdea4Package.FOODCOURT__FLOOR:
			return getFloor();
		case Mdea4Package.FOODCOURT__RESTAURANTS:
			return getRestaurants();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Mdea4Package.FOODCOURT__FLOOR:
			setFloor((Integer) newValue);
			return;
		case Mdea4Package.FOODCOURT__RESTAURANTS:
			getRestaurants().clear();
			getRestaurants().addAll((Collection<? extends Restaurant>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Mdea4Package.FOODCOURT__FLOOR:
			setFloor(FLOOR_EDEFAULT);
			return;
		case Mdea4Package.FOODCOURT__RESTAURANTS:
			getRestaurants().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Mdea4Package.FOODCOURT__FLOOR:
			return floor != FLOOR_EDEFAULT;
		case Mdea4Package.FOODCOURT__RESTAURANTS:
			return restaurants != null && !restaurants.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (floor: ");
		result.append(floor);
		result.append(')');
		return result.toString();
	}

} //FoodcourtImpl
