/**
 */
package mdea4.impl;

import mdea4.AbstractDepartment;
import mdea4.Cinema;
import mdea4.ClothingStore;
import mdea4.Department;
import mdea4.DepartmentStore;
import mdea4.Foodcourt;
import mdea4.Mdea4Factory;
import mdea4.Mdea4Package;
import mdea4.Restaurant;
import mdea4.clothingsType;
import mdea4.foodType;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class Mdea4PackageImpl extends EPackageImpl implements Mdea4Package {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass departmentStoreEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass departmentEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass cinemaEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass clothingStoreEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass foodcourtEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass restaurantEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass abstractDepartmentEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum foodTypeEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum clothingsTypeEEnum = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see mdea4.Mdea4Package#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private Mdea4PackageImpl() {
		super(eNS_URI, Mdea4Factory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 *
	 * <p>This method is used to initialize {@link Mdea4Package#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static Mdea4Package init() {
		if (isInited)
			return (Mdea4Package) EPackage.Registry.INSTANCE.getEPackage(Mdea4Package.eNS_URI);

		// Obtain or create and register package
		Object registeredMdea4Package = EPackage.Registry.INSTANCE.get(eNS_URI);
		Mdea4PackageImpl theMdea4Package = registeredMdea4Package instanceof Mdea4PackageImpl
				? (Mdea4PackageImpl) registeredMdea4Package
				: new Mdea4PackageImpl();

		isInited = true;

		// Create package meta-data objects
		theMdea4Package.createPackageContents();

		// Initialize created meta-data
		theMdea4Package.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theMdea4Package.freeze();

		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(Mdea4Package.eNS_URI, theMdea4Package);
		return theMdea4Package;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDepartmentStore() {
		return departmentStoreEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDepartmentStore_Owner() {
		return (EAttribute) departmentStoreEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDepartmentStore_Name() {
		return (EAttribute) departmentStoreEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDepartmentStore_Location() {
		return (EAttribute) departmentStoreEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDepartmentStore_Departments() {
		return (EReference) departmentStoreEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDepartment() {
		return departmentEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDepartment_Cinema() {
		return (EReference) departmentEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDepartment_Clothingstore() {
		return (EReference) departmentEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDepartment_Foodcourt() {
		return (EReference) departmentEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCinema() {
		return cinemaEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCinema_Floor() {
		return (EAttribute) cinemaEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCinema_TheaterAMount() {
		return (EAttribute) cinemaEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getClothingStore() {
		return clothingStoreEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getClothingStore_Floor() {
		return (EAttribute) clothingStoreEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getClothingStore_Type() {
		return (EAttribute) clothingStoreEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getFoodcourt() {
		return foodcourtEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getFoodcourt_Floor() {
		return (EAttribute) foodcourtEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getFoodcourt_Restaurants() {
		return (EReference) foodcourtEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getRestaurant() {
		return restaurantEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getRestaurant_Type() {
		return (EAttribute) restaurantEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAbstractDepartment() {
		return abstractDepartmentEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAbstractDepartment_Name() {
		return (EAttribute) abstractDepartmentEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAbstractDepartment_ManagerAmount() {
		return (EAttribute) abstractDepartmentEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAbstractDepartment_EmployeeAmount() {
		return (EAttribute) abstractDepartmentEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAbstractDepartment_Capacity() {
		return (EAttribute) abstractDepartmentEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getfoodType() {
		return foodTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getclothingsType() {
		return clothingsTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Mdea4Factory getMdea4Factory() {
		return (Mdea4Factory) getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated)
			return;
		isCreated = true;

		// Create classes and their features
		departmentStoreEClass = createEClass(DEPARTMENT_STORE);
		createEAttribute(departmentStoreEClass, DEPARTMENT_STORE__OWNER);
		createEAttribute(departmentStoreEClass, DEPARTMENT_STORE__NAME);
		createEAttribute(departmentStoreEClass, DEPARTMENT_STORE__LOCATION);
		createEReference(departmentStoreEClass, DEPARTMENT_STORE__DEPARTMENTS);

		departmentEClass = createEClass(DEPARTMENT);
		createEReference(departmentEClass, DEPARTMENT__CINEMA);
		createEReference(departmentEClass, DEPARTMENT__CLOTHINGSTORE);
		createEReference(departmentEClass, DEPARTMENT__FOODCOURT);

		cinemaEClass = createEClass(CINEMA);
		createEAttribute(cinemaEClass, CINEMA__FLOOR);
		createEAttribute(cinemaEClass, CINEMA__THEATER_AMOUNT);

		clothingStoreEClass = createEClass(CLOTHING_STORE);
		createEAttribute(clothingStoreEClass, CLOTHING_STORE__FLOOR);
		createEAttribute(clothingStoreEClass, CLOTHING_STORE__TYPE);

		foodcourtEClass = createEClass(FOODCOURT);
		createEAttribute(foodcourtEClass, FOODCOURT__FLOOR);
		createEReference(foodcourtEClass, FOODCOURT__RESTAURANTS);

		restaurantEClass = createEClass(RESTAURANT);
		createEAttribute(restaurantEClass, RESTAURANT__TYPE);

		abstractDepartmentEClass = createEClass(ABSTRACT_DEPARTMENT);
		createEAttribute(abstractDepartmentEClass, ABSTRACT_DEPARTMENT__NAME);
		createEAttribute(abstractDepartmentEClass, ABSTRACT_DEPARTMENT__MANAGER_AMOUNT);
		createEAttribute(abstractDepartmentEClass, ABSTRACT_DEPARTMENT__EMPLOYEE_AMOUNT);
		createEAttribute(abstractDepartmentEClass, ABSTRACT_DEPARTMENT__CAPACITY);

		// Create enums
		foodTypeEEnum = createEEnum(FOOD_TYPE);
		clothingsTypeEEnum = createEEnum(CLOTHINGS_TYPE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized)
			return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		cinemaEClass.getESuperTypes().add(this.getAbstractDepartment());
		clothingStoreEClass.getESuperTypes().add(this.getAbstractDepartment());
		foodcourtEClass.getESuperTypes().add(this.getAbstractDepartment());

		// Initialize classes, features, and operations; add parameters
		initEClass(departmentStoreEClass, DepartmentStore.class, "DepartmentStore", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getDepartmentStore_Owner(), ecorePackage.getEString(), "owner", null, 1, 1,
				DepartmentStore.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getDepartmentStore_Name(), ecorePackage.getEString(), "name", null, 1, 1, DepartmentStore.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getDepartmentStore_Location(), ecorePackage.getEString(), "location", null, 1, 1,
				DepartmentStore.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEReference(getDepartmentStore_Departments(), this.getDepartment(), null, "departments", null, 1, -1,
				DepartmentStore.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(departmentEClass, Department.class, "Department", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getDepartment_Cinema(), this.getCinema(), null, "cinema", null, 1, 1, Department.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDepartment_Clothingstore(), this.getClothingStore(), null, "clothingstore", null, 1, -1,
				Department.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDepartment_Foodcourt(), this.getFoodcourt(), null, "foodcourt", null, 1, -1, Department.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(cinemaEClass, Cinema.class, "Cinema", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getCinema_Floor(), ecorePackage.getEInt(), "floor", null, 0, 1, Cinema.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCinema_TheaterAMount(), ecorePackage.getEInt(), "theaterAMount", null, 0, 1, Cinema.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(clothingStoreEClass, ClothingStore.class, "ClothingStore", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getClothingStore_Floor(), ecorePackage.getEInt(), "floor", null, 0, 1, ClothingStore.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getClothingStore_Type(), this.getclothingsType(), "type", null, 0, 1, ClothingStore.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(foodcourtEClass, Foodcourt.class, "Foodcourt", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getFoodcourt_Floor(), ecorePackage.getEInt(), "floor", null, 0, 1, Foodcourt.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getFoodcourt_Restaurants(), this.getRestaurant(), null, "restaurants", null, 1, -1,
				Foodcourt.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(restaurantEClass, Restaurant.class, "Restaurant", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getRestaurant_Type(), this.getfoodType(), "type", null, 0, 1, Restaurant.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(abstractDepartmentEClass, AbstractDepartment.class, "AbstractDepartment", IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getAbstractDepartment_Name(), ecorePackage.getEString(), "name", null, 0, 1,
				AbstractDepartment.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getAbstractDepartment_ManagerAmount(), ecorePackage.getEInt(), "managerAmount", null, 0, 1,
				AbstractDepartment.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getAbstractDepartment_EmployeeAmount(), ecorePackage.getEInt(), "employeeAmount", null, 0, 1,
				AbstractDepartment.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getAbstractDepartment_Capacity(), ecorePackage.getEInt(), "capacity", null, 0, 1,
				AbstractDepartment.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);

		// Initialize enums and add enum literals
		initEEnum(foodTypeEEnum, foodType.class, "foodType");
		addEEnumLiteral(foodTypeEEnum, foodType.JAPANESE);
		addEEnumLiteral(foodTypeEEnum, foodType.CAFE);
		addEEnumLiteral(foodTypeEEnum, foodType.FASTFOOD);
		addEEnumLiteral(foodTypeEEnum, foodType.ITALIAN);

		initEEnum(clothingsTypeEEnum, clothingsType.class, "clothingsType");
		addEEnumLiteral(clothingsTypeEEnum, clothingsType.WOMEN);
		addEEnumLiteral(clothingsTypeEEnum, clothingsType.MEN);
		addEEnumLiteral(clothingsTypeEEnum, clothingsType.KIDS);

		// Create resource
		createResource(eNS_URI);
	}

} //Mdea4PackageImpl
