/**
 */
package mdea4;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Abstract Department</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link mdea4.AbstractDepartment#getName <em>Name</em>}</li>
 *   <li>{@link mdea4.AbstractDepartment#getManagerAmount <em>Manager Amount</em>}</li>
 *   <li>{@link mdea4.AbstractDepartment#getEmployeeAmount <em>Employee Amount</em>}</li>
 *   <li>{@link mdea4.AbstractDepartment#getCapacity <em>Capacity</em>}</li>
 * </ul>
 *
 * @see mdea4.Mdea4Package#getAbstractDepartment()
 * @model abstract="true"
 * @generated
 */
public interface AbstractDepartment extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see mdea4.Mdea4Package#getAbstractDepartment_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link mdea4.AbstractDepartment#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Manager Amount</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Manager Amount</em>' attribute.
	 * @see #setManagerAmount(int)
	 * @see mdea4.Mdea4Package#getAbstractDepartment_ManagerAmount()
	 * @model
	 * @generated
	 */
	int getManagerAmount();

	/**
	 * Sets the value of the '{@link mdea4.AbstractDepartment#getManagerAmount <em>Manager Amount</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Manager Amount</em>' attribute.
	 * @see #getManagerAmount()
	 * @generated
	 */
	void setManagerAmount(int value);

	/**
	 * Returns the value of the '<em><b>Employee Amount</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Employee Amount</em>' attribute.
	 * @see #setEmployeeAmount(int)
	 * @see mdea4.Mdea4Package#getAbstractDepartment_EmployeeAmount()
	 * @model
	 * @generated
	 */
	int getEmployeeAmount();

	/**
	 * Sets the value of the '{@link mdea4.AbstractDepartment#getEmployeeAmount <em>Employee Amount</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Employee Amount</em>' attribute.
	 * @see #getEmployeeAmount()
	 * @generated
	 */
	void setEmployeeAmount(int value);

	/**
	 * Returns the value of the '<em><b>Capacity</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Capacity</em>' attribute.
	 * @see #setCapacity(int)
	 * @see mdea4.Mdea4Package#getAbstractDepartment_Capacity()
	 * @model
	 * @generated
	 */
	int getCapacity();

	/**
	 * Sets the value of the '{@link mdea4.AbstractDepartment#getCapacity <em>Capacity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Capacity</em>' attribute.
	 * @see #getCapacity()
	 * @generated
	 */
	void setCapacity(int value);

} // AbstractDepartment
