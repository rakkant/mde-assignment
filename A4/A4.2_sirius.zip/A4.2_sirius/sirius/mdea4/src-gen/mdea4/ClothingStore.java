/**
 */
package mdea4;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Clothing Store</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link mdea4.ClothingStore#getFloor <em>Floor</em>}</li>
 *   <li>{@link mdea4.ClothingStore#getType <em>Type</em>}</li>
 * </ul>
 *
 * @see mdea4.Mdea4Package#getClothingStore()
 * @model
 * @generated
 */
public interface ClothingStore extends AbstractDepartment {
	/**
	 * Returns the value of the '<em><b>Floor</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Floor</em>' attribute.
	 * @see #setFloor(int)
	 * @see mdea4.Mdea4Package#getClothingStore_Floor()
	 * @model
	 * @generated
	 */
	int getFloor();

	/**
	 * Sets the value of the '{@link mdea4.ClothingStore#getFloor <em>Floor</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Floor</em>' attribute.
	 * @see #getFloor()
	 * @generated
	 */
	void setFloor(int value);

	/**
	 * Returns the value of the '<em><b>Type</b></em>' attribute.
	 * The literals are from the enumeration {@link mdea4.clothingsType}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' attribute.
	 * @see mdea4.clothingsType
	 * @see #setType(clothingsType)
	 * @see mdea4.Mdea4Package#getClothingStore_Type()
	 * @model
	 * @generated
	 */
	clothingsType getType();

	/**
	 * Sets the value of the '{@link mdea4.ClothingStore#getType <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' attribute.
	 * @see mdea4.clothingsType
	 * @see #getType()
	 * @generated
	 */
	void setType(clothingsType value);

} // ClothingStore
