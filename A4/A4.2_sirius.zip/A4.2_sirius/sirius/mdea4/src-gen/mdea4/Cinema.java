/**
 */
package mdea4;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Cinema</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link mdea4.Cinema#getFloor <em>Floor</em>}</li>
 *   <li>{@link mdea4.Cinema#getTheaterAMount <em>Theater AMount</em>}</li>
 * </ul>
 *
 * @see mdea4.Mdea4Package#getCinema()
 * @model
 * @generated
 */
public interface Cinema extends AbstractDepartment {
	/**
	 * Returns the value of the '<em><b>Floor</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Floor</em>' attribute.
	 * @see #setFloor(int)
	 * @see mdea4.Mdea4Package#getCinema_Floor()
	 * @model
	 * @generated
	 */
	int getFloor();

	/**
	 * Sets the value of the '{@link mdea4.Cinema#getFloor <em>Floor</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Floor</em>' attribute.
	 * @see #getFloor()
	 * @generated
	 */
	void setFloor(int value);

	/**
	 * Returns the value of the '<em><b>Theater AMount</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Theater AMount</em>' attribute.
	 * @see #setTheaterAMount(int)
	 * @see mdea4.Mdea4Package#getCinema_TheaterAMount()
	 * @model
	 * @generated
	 */
	int getTheaterAMount();

	/**
	 * Sets the value of the '{@link mdea4.Cinema#getTheaterAMount <em>Theater AMount</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Theater AMount</em>' attribute.
	 * @see #getTheaterAMount()
	 * @generated
	 */
	void setTheaterAMount(int value);

} // Cinema
