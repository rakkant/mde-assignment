/**
 */
package mdea4;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see mdea4.Mdea4Factory
 * @model kind="package"
 * @generated
 */
public interface Mdea4Package extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "mdea4";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.example.org/mdea4";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "mdea4";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	Mdea4Package eINSTANCE = mdea4.impl.Mdea4PackageImpl.init();

	/**
	 * The meta object id for the '{@link mdea4.impl.DepartmentStoreImpl <em>Department Store</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mdea4.impl.DepartmentStoreImpl
	 * @see mdea4.impl.Mdea4PackageImpl#getDepartmentStore()
	 * @generated
	 */
	int DEPARTMENT_STORE = 0;

	/**
	 * The feature id for the '<em><b>Owner</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPARTMENT_STORE__OWNER = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPARTMENT_STORE__NAME = 1;

	/**
	 * The feature id for the '<em><b>Location</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPARTMENT_STORE__LOCATION = 2;

	/**
	 * The feature id for the '<em><b>Departments</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPARTMENT_STORE__DEPARTMENTS = 3;

	/**
	 * The number of structural features of the '<em>Department Store</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPARTMENT_STORE_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>Department Store</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPARTMENT_STORE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link mdea4.impl.DepartmentImpl <em>Department</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mdea4.impl.DepartmentImpl
	 * @see mdea4.impl.Mdea4PackageImpl#getDepartment()
	 * @generated
	 */
	int DEPARTMENT = 1;

	/**
	 * The feature id for the '<em><b>Cinema</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPARTMENT__CINEMA = 0;

	/**
	 * The feature id for the '<em><b>Clothingstore</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPARTMENT__CLOTHINGSTORE = 1;

	/**
	 * The feature id for the '<em><b>Foodcourt</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPARTMENT__FOODCOURT = 2;

	/**
	 * The number of structural features of the '<em>Department</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPARTMENT_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Department</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPARTMENT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link mdea4.impl.AbstractDepartmentImpl <em>Abstract Department</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mdea4.impl.AbstractDepartmentImpl
	 * @see mdea4.impl.Mdea4PackageImpl#getAbstractDepartment()
	 * @generated
	 */
	int ABSTRACT_DEPARTMENT = 6;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_DEPARTMENT__NAME = 0;

	/**
	 * The feature id for the '<em><b>Manager Amount</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_DEPARTMENT__MANAGER_AMOUNT = 1;

	/**
	 * The feature id for the '<em><b>Employee Amount</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_DEPARTMENT__EMPLOYEE_AMOUNT = 2;

	/**
	 * The feature id for the '<em><b>Capacity</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_DEPARTMENT__CAPACITY = 3;

	/**
	 * The number of structural features of the '<em>Abstract Department</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_DEPARTMENT_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>Abstract Department</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_DEPARTMENT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link mdea4.impl.CinemaImpl <em>Cinema</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mdea4.impl.CinemaImpl
	 * @see mdea4.impl.Mdea4PackageImpl#getCinema()
	 * @generated
	 */
	int CINEMA = 2;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CINEMA__NAME = ABSTRACT_DEPARTMENT__NAME;

	/**
	 * The feature id for the '<em><b>Manager Amount</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CINEMA__MANAGER_AMOUNT = ABSTRACT_DEPARTMENT__MANAGER_AMOUNT;

	/**
	 * The feature id for the '<em><b>Employee Amount</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CINEMA__EMPLOYEE_AMOUNT = ABSTRACT_DEPARTMENT__EMPLOYEE_AMOUNT;

	/**
	 * The feature id for the '<em><b>Capacity</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CINEMA__CAPACITY = ABSTRACT_DEPARTMENT__CAPACITY;

	/**
	 * The feature id for the '<em><b>Floor</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CINEMA__FLOOR = ABSTRACT_DEPARTMENT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Theater AMount</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CINEMA__THEATER_AMOUNT = ABSTRACT_DEPARTMENT_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Cinema</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CINEMA_FEATURE_COUNT = ABSTRACT_DEPARTMENT_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Cinema</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CINEMA_OPERATION_COUNT = ABSTRACT_DEPARTMENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link mdea4.impl.ClothingStoreImpl <em>Clothing Store</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mdea4.impl.ClothingStoreImpl
	 * @see mdea4.impl.Mdea4PackageImpl#getClothingStore()
	 * @generated
	 */
	int CLOTHING_STORE = 3;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOTHING_STORE__NAME = ABSTRACT_DEPARTMENT__NAME;

	/**
	 * The feature id for the '<em><b>Manager Amount</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOTHING_STORE__MANAGER_AMOUNT = ABSTRACT_DEPARTMENT__MANAGER_AMOUNT;

	/**
	 * The feature id for the '<em><b>Employee Amount</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOTHING_STORE__EMPLOYEE_AMOUNT = ABSTRACT_DEPARTMENT__EMPLOYEE_AMOUNT;

	/**
	 * The feature id for the '<em><b>Capacity</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOTHING_STORE__CAPACITY = ABSTRACT_DEPARTMENT__CAPACITY;

	/**
	 * The feature id for the '<em><b>Floor</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOTHING_STORE__FLOOR = ABSTRACT_DEPARTMENT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOTHING_STORE__TYPE = ABSTRACT_DEPARTMENT_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Clothing Store</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOTHING_STORE_FEATURE_COUNT = ABSTRACT_DEPARTMENT_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Clothing Store</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOTHING_STORE_OPERATION_COUNT = ABSTRACT_DEPARTMENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link mdea4.impl.FoodcourtImpl <em>Foodcourt</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mdea4.impl.FoodcourtImpl
	 * @see mdea4.impl.Mdea4PackageImpl#getFoodcourt()
	 * @generated
	 */
	int FOODCOURT = 4;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FOODCOURT__NAME = ABSTRACT_DEPARTMENT__NAME;

	/**
	 * The feature id for the '<em><b>Manager Amount</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FOODCOURT__MANAGER_AMOUNT = ABSTRACT_DEPARTMENT__MANAGER_AMOUNT;

	/**
	 * The feature id for the '<em><b>Employee Amount</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FOODCOURT__EMPLOYEE_AMOUNT = ABSTRACT_DEPARTMENT__EMPLOYEE_AMOUNT;

	/**
	 * The feature id for the '<em><b>Capacity</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FOODCOURT__CAPACITY = ABSTRACT_DEPARTMENT__CAPACITY;

	/**
	 * The feature id for the '<em><b>Floor</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FOODCOURT__FLOOR = ABSTRACT_DEPARTMENT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Restaurants</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FOODCOURT__RESTAURANTS = ABSTRACT_DEPARTMENT_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Foodcourt</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FOODCOURT_FEATURE_COUNT = ABSTRACT_DEPARTMENT_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Foodcourt</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FOODCOURT_OPERATION_COUNT = ABSTRACT_DEPARTMENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link mdea4.impl.RestaurantImpl <em>Restaurant</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mdea4.impl.RestaurantImpl
	 * @see mdea4.impl.Mdea4PackageImpl#getRestaurant()
	 * @generated
	 */
	int RESTAURANT = 5;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RESTAURANT__TYPE = 0;

	/**
	 * The number of structural features of the '<em>Restaurant</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RESTAURANT_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Restaurant</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RESTAURANT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link mdea4.foodType <em>food Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mdea4.foodType
	 * @see mdea4.impl.Mdea4PackageImpl#getfoodType()
	 * @generated
	 */
	int FOOD_TYPE = 7;

	/**
	 * The meta object id for the '{@link mdea4.clothingsType <em>clothings Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mdea4.clothingsType
	 * @see mdea4.impl.Mdea4PackageImpl#getclothingsType()
	 * @generated
	 */
	int CLOTHINGS_TYPE = 8;

	/**
	 * Returns the meta object for class '{@link mdea4.DepartmentStore <em>Department Store</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Department Store</em>'.
	 * @see mdea4.DepartmentStore
	 * @generated
	 */
	EClass getDepartmentStore();

	/**
	 * Returns the meta object for the attribute '{@link mdea4.DepartmentStore#getOwner <em>Owner</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Owner</em>'.
	 * @see mdea4.DepartmentStore#getOwner()
	 * @see #getDepartmentStore()
	 * @generated
	 */
	EAttribute getDepartmentStore_Owner();

	/**
	 * Returns the meta object for the attribute '{@link mdea4.DepartmentStore#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see mdea4.DepartmentStore#getName()
	 * @see #getDepartmentStore()
	 * @generated
	 */
	EAttribute getDepartmentStore_Name();

	/**
	 * Returns the meta object for the attribute '{@link mdea4.DepartmentStore#getLocation <em>Location</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Location</em>'.
	 * @see mdea4.DepartmentStore#getLocation()
	 * @see #getDepartmentStore()
	 * @generated
	 */
	EAttribute getDepartmentStore_Location();

	/**
	 * Returns the meta object for the containment reference list '{@link mdea4.DepartmentStore#getDepartments <em>Departments</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Departments</em>'.
	 * @see mdea4.DepartmentStore#getDepartments()
	 * @see #getDepartmentStore()
	 * @generated
	 */
	EReference getDepartmentStore_Departments();

	/**
	 * Returns the meta object for class '{@link mdea4.Department <em>Department</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Department</em>'.
	 * @see mdea4.Department
	 * @generated
	 */
	EClass getDepartment();

	/**
	 * Returns the meta object for the containment reference '{@link mdea4.Department#getCinema <em>Cinema</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Cinema</em>'.
	 * @see mdea4.Department#getCinema()
	 * @see #getDepartment()
	 * @generated
	 */
	EReference getDepartment_Cinema();

	/**
	 * Returns the meta object for the containment reference list '{@link mdea4.Department#getClothingstore <em>Clothingstore</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Clothingstore</em>'.
	 * @see mdea4.Department#getClothingstore()
	 * @see #getDepartment()
	 * @generated
	 */
	EReference getDepartment_Clothingstore();

	/**
	 * Returns the meta object for the containment reference list '{@link mdea4.Department#getFoodcourt <em>Foodcourt</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Foodcourt</em>'.
	 * @see mdea4.Department#getFoodcourt()
	 * @see #getDepartment()
	 * @generated
	 */
	EReference getDepartment_Foodcourt();

	/**
	 * Returns the meta object for class '{@link mdea4.Cinema <em>Cinema</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Cinema</em>'.
	 * @see mdea4.Cinema
	 * @generated
	 */
	EClass getCinema();

	/**
	 * Returns the meta object for the attribute '{@link mdea4.Cinema#getFloor <em>Floor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Floor</em>'.
	 * @see mdea4.Cinema#getFloor()
	 * @see #getCinema()
	 * @generated
	 */
	EAttribute getCinema_Floor();

	/**
	 * Returns the meta object for the attribute '{@link mdea4.Cinema#getTheaterAMount <em>Theater AMount</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Theater AMount</em>'.
	 * @see mdea4.Cinema#getTheaterAMount()
	 * @see #getCinema()
	 * @generated
	 */
	EAttribute getCinema_TheaterAMount();

	/**
	 * Returns the meta object for class '{@link mdea4.ClothingStore <em>Clothing Store</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Clothing Store</em>'.
	 * @see mdea4.ClothingStore
	 * @generated
	 */
	EClass getClothingStore();

	/**
	 * Returns the meta object for the attribute '{@link mdea4.ClothingStore#getFloor <em>Floor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Floor</em>'.
	 * @see mdea4.ClothingStore#getFloor()
	 * @see #getClothingStore()
	 * @generated
	 */
	EAttribute getClothingStore_Floor();

	/**
	 * Returns the meta object for the attribute '{@link mdea4.ClothingStore#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see mdea4.ClothingStore#getType()
	 * @see #getClothingStore()
	 * @generated
	 */
	EAttribute getClothingStore_Type();

	/**
	 * Returns the meta object for class '{@link mdea4.Foodcourt <em>Foodcourt</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Foodcourt</em>'.
	 * @see mdea4.Foodcourt
	 * @generated
	 */
	EClass getFoodcourt();

	/**
	 * Returns the meta object for the attribute '{@link mdea4.Foodcourt#getFloor <em>Floor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Floor</em>'.
	 * @see mdea4.Foodcourt#getFloor()
	 * @see #getFoodcourt()
	 * @generated
	 */
	EAttribute getFoodcourt_Floor();

	/**
	 * Returns the meta object for the containment reference list '{@link mdea4.Foodcourt#getRestaurants <em>Restaurants</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Restaurants</em>'.
	 * @see mdea4.Foodcourt#getRestaurants()
	 * @see #getFoodcourt()
	 * @generated
	 */
	EReference getFoodcourt_Restaurants();

	/**
	 * Returns the meta object for class '{@link mdea4.Restaurant <em>Restaurant</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Restaurant</em>'.
	 * @see mdea4.Restaurant
	 * @generated
	 */
	EClass getRestaurant();

	/**
	 * Returns the meta object for the attribute '{@link mdea4.Restaurant#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see mdea4.Restaurant#getType()
	 * @see #getRestaurant()
	 * @generated
	 */
	EAttribute getRestaurant_Type();

	/**
	 * Returns the meta object for class '{@link mdea4.AbstractDepartment <em>Abstract Department</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Abstract Department</em>'.
	 * @see mdea4.AbstractDepartment
	 * @generated
	 */
	EClass getAbstractDepartment();

	/**
	 * Returns the meta object for the attribute '{@link mdea4.AbstractDepartment#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see mdea4.AbstractDepartment#getName()
	 * @see #getAbstractDepartment()
	 * @generated
	 */
	EAttribute getAbstractDepartment_Name();

	/**
	 * Returns the meta object for the attribute '{@link mdea4.AbstractDepartment#getManagerAmount <em>Manager Amount</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Manager Amount</em>'.
	 * @see mdea4.AbstractDepartment#getManagerAmount()
	 * @see #getAbstractDepartment()
	 * @generated
	 */
	EAttribute getAbstractDepartment_ManagerAmount();

	/**
	 * Returns the meta object for the attribute '{@link mdea4.AbstractDepartment#getEmployeeAmount <em>Employee Amount</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Employee Amount</em>'.
	 * @see mdea4.AbstractDepartment#getEmployeeAmount()
	 * @see #getAbstractDepartment()
	 * @generated
	 */
	EAttribute getAbstractDepartment_EmployeeAmount();

	/**
	 * Returns the meta object for the attribute '{@link mdea4.AbstractDepartment#getCapacity <em>Capacity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Capacity</em>'.
	 * @see mdea4.AbstractDepartment#getCapacity()
	 * @see #getAbstractDepartment()
	 * @generated
	 */
	EAttribute getAbstractDepartment_Capacity();

	/**
	 * Returns the meta object for enum '{@link mdea4.foodType <em>food Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>food Type</em>'.
	 * @see mdea4.foodType
	 * @generated
	 */
	EEnum getfoodType();

	/**
	 * Returns the meta object for enum '{@link mdea4.clothingsType <em>clothings Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>clothings Type</em>'.
	 * @see mdea4.clothingsType
	 * @generated
	 */
	EEnum getclothingsType();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	Mdea4Factory getMdea4Factory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link mdea4.impl.DepartmentStoreImpl <em>Department Store</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mdea4.impl.DepartmentStoreImpl
		 * @see mdea4.impl.Mdea4PackageImpl#getDepartmentStore()
		 * @generated
		 */
		EClass DEPARTMENT_STORE = eINSTANCE.getDepartmentStore();

		/**
		 * The meta object literal for the '<em><b>Owner</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DEPARTMENT_STORE__OWNER = eINSTANCE.getDepartmentStore_Owner();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DEPARTMENT_STORE__NAME = eINSTANCE.getDepartmentStore_Name();

		/**
		 * The meta object literal for the '<em><b>Location</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DEPARTMENT_STORE__LOCATION = eINSTANCE.getDepartmentStore_Location();

		/**
		 * The meta object literal for the '<em><b>Departments</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DEPARTMENT_STORE__DEPARTMENTS = eINSTANCE.getDepartmentStore_Departments();

		/**
		 * The meta object literal for the '{@link mdea4.impl.DepartmentImpl <em>Department</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mdea4.impl.DepartmentImpl
		 * @see mdea4.impl.Mdea4PackageImpl#getDepartment()
		 * @generated
		 */
		EClass DEPARTMENT = eINSTANCE.getDepartment();

		/**
		 * The meta object literal for the '<em><b>Cinema</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DEPARTMENT__CINEMA = eINSTANCE.getDepartment_Cinema();

		/**
		 * The meta object literal for the '<em><b>Clothingstore</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DEPARTMENT__CLOTHINGSTORE = eINSTANCE.getDepartment_Clothingstore();

		/**
		 * The meta object literal for the '<em><b>Foodcourt</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DEPARTMENT__FOODCOURT = eINSTANCE.getDepartment_Foodcourt();

		/**
		 * The meta object literal for the '{@link mdea4.impl.CinemaImpl <em>Cinema</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mdea4.impl.CinemaImpl
		 * @see mdea4.impl.Mdea4PackageImpl#getCinema()
		 * @generated
		 */
		EClass CINEMA = eINSTANCE.getCinema();

		/**
		 * The meta object literal for the '<em><b>Floor</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CINEMA__FLOOR = eINSTANCE.getCinema_Floor();

		/**
		 * The meta object literal for the '<em><b>Theater AMount</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CINEMA__THEATER_AMOUNT = eINSTANCE.getCinema_TheaterAMount();

		/**
		 * The meta object literal for the '{@link mdea4.impl.ClothingStoreImpl <em>Clothing Store</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mdea4.impl.ClothingStoreImpl
		 * @see mdea4.impl.Mdea4PackageImpl#getClothingStore()
		 * @generated
		 */
		EClass CLOTHING_STORE = eINSTANCE.getClothingStore();

		/**
		 * The meta object literal for the '<em><b>Floor</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CLOTHING_STORE__FLOOR = eINSTANCE.getClothingStore_Floor();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CLOTHING_STORE__TYPE = eINSTANCE.getClothingStore_Type();

		/**
		 * The meta object literal for the '{@link mdea4.impl.FoodcourtImpl <em>Foodcourt</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mdea4.impl.FoodcourtImpl
		 * @see mdea4.impl.Mdea4PackageImpl#getFoodcourt()
		 * @generated
		 */
		EClass FOODCOURT = eINSTANCE.getFoodcourt();

		/**
		 * The meta object literal for the '<em><b>Floor</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FOODCOURT__FLOOR = eINSTANCE.getFoodcourt_Floor();

		/**
		 * The meta object literal for the '<em><b>Restaurants</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FOODCOURT__RESTAURANTS = eINSTANCE.getFoodcourt_Restaurants();

		/**
		 * The meta object literal for the '{@link mdea4.impl.RestaurantImpl <em>Restaurant</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mdea4.impl.RestaurantImpl
		 * @see mdea4.impl.Mdea4PackageImpl#getRestaurant()
		 * @generated
		 */
		EClass RESTAURANT = eINSTANCE.getRestaurant();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute RESTAURANT__TYPE = eINSTANCE.getRestaurant_Type();

		/**
		 * The meta object literal for the '{@link mdea4.impl.AbstractDepartmentImpl <em>Abstract Department</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mdea4.impl.AbstractDepartmentImpl
		 * @see mdea4.impl.Mdea4PackageImpl#getAbstractDepartment()
		 * @generated
		 */
		EClass ABSTRACT_DEPARTMENT = eINSTANCE.getAbstractDepartment();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ABSTRACT_DEPARTMENT__NAME = eINSTANCE.getAbstractDepartment_Name();

		/**
		 * The meta object literal for the '<em><b>Manager Amount</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ABSTRACT_DEPARTMENT__MANAGER_AMOUNT = eINSTANCE.getAbstractDepartment_ManagerAmount();

		/**
		 * The meta object literal for the '<em><b>Employee Amount</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ABSTRACT_DEPARTMENT__EMPLOYEE_AMOUNT = eINSTANCE.getAbstractDepartment_EmployeeAmount();

		/**
		 * The meta object literal for the '<em><b>Capacity</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ABSTRACT_DEPARTMENT__CAPACITY = eINSTANCE.getAbstractDepartment_Capacity();

		/**
		 * The meta object literal for the '{@link mdea4.foodType <em>food Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mdea4.foodType
		 * @see mdea4.impl.Mdea4PackageImpl#getfoodType()
		 * @generated
		 */
		EEnum FOOD_TYPE = eINSTANCE.getfoodType();

		/**
		 * The meta object literal for the '{@link mdea4.clothingsType <em>clothings Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mdea4.clothingsType
		 * @see mdea4.impl.Mdea4PackageImpl#getclothingsType()
		 * @generated
		 */
		EEnum CLOTHINGS_TYPE = eINSTANCE.getclothingsType();

	}

} //Mdea4Package
